"""Tests for Lab 8. Run with:  python tests/test_lab08.py   (or: pytest tests/)

Runs offline. The French portfolio parsers are checked on files in the
library's layouts, drawdown statistics on a known series, the JKP reader on
a file in its layout, missing international files are handled, and the full
lab runs on simulated data.
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fintest.data import find_table, parse_french_tables  # noqa: E402

BM_HEADER = ",<= 0,Lo 30,Med 40,Hi 30,Lo 20,Qnt 2,Qnt 3,Qnt 4,Hi 20,Lo 10,Dec 2,Dec 3,Dec 4,Dec 5,Dec 6,Dec 7,Dec 8,Dec 9,Hi 10"
BM_SAMPLE = (
    "This file was created by CMPT_BEME_RETS using the 202508 CRSP database.\n\n"
    "  Value Weight Returns -- Monthly\n" + BM_HEADER + "\n"
    "192607," + ",".join(["-99.99", "1.00", "2.00", "4.00"] + ["0.5"] * 15) + "\n"
    "192608," + ",".join(["-99.99", "2.00", "2.00", "1.00"] + ["0.5"] * 15) + "\n\n"
    "  Equal Weight Returns -- Monthly\n" + BM_HEADER + "\n"
    "192607," + ",".join(["-99.99"] + ["9.00"] * 18) + "\n"
)
SIX_SAMPLE = (
    "  Average Value Weighted Returns -- Monthly\n"
    ",SMALL LoBM,ME1 BM2,SMALL HiBM,BIG LoBM,ME2 BM2,BIG HiBM\n"
    "192607,1.0,2.0,3.0,0.5,1.0,2.5\n\n"
    "  Average Equal Weighted Returns -- Monthly\n"
    ",SMALL LoBM,ME1 BM2,SMALL HiBM,BIG LoBM,ME2 BM2,BIG HiBM\n"
    "192607,9,9,9,9,9,9\n"
)


def test_value_spreads_from_french_layouts():
    import lab08

    t = find_table(parse_french_tables(BM_SAMPLE), "value", "weight")
    hl = lab08.hi_minus_lo(t)
    assert np.allclose(hl.to_numpy(), [0.03, -0.01])
    six = find_table(parse_french_tables(SIX_SAMPLE), "value", "weight")
    assert abs((six.iloc[:, 5] - six.iloc[:, 3]).iloc[0] - 0.02) < 1e-12  # BIG HiBM - BIG LoBM
    assert abs((six.iloc[:, 2] - six.iloc[:, 0]).iloc[0] - 0.02) < 1e-12  # SMALL HiBM - SMALL LoBM


def test_drawdown_stats_on_known_series():
    import lab08

    r = pd.Series([0.1, -0.5, 0.2, 0.2, 1.0, 0.0] + [0.0] * 120,
                  index=pd.period_range("2000-01", periods=126, freq="M"))
    d = lab08.drawdown_stats(r)
    assert abs(d["max_drawdown"] + 0.5) < 1e-12
    assert d["longest_underwater_months"] == 3  # months 2-4 below the peak after month 1
    assert d["longest_underwater_start"] == "2000-02"


def test_bootstrap_and_tilt_scaling():
    import lab08

    us = lab08.simulated_us()
    d = lab08.part_d(us, tolerance=0.1, n_boot=300, seed=1)
    t = d["tilts"].set_index("tilt")
    assert abs(t.loc[0.5, "bad_case_10y_full"] - 0.5 * d["p5_full"]) < 1e-12
    assert 0 < d["w_max"] < 5 and np.isfinite(d["boot_full"]).all()


def test_jkp_reader():
    import lab08

    csv = "location,name,freq,weighting,direction,n_stocks,date,ret\n" + "\n".join(
        f"{c},{n},monthly,vw_cap,1,100,{d},{r}" for c, n, d, r in [
            ("usa", "be_me", "2000-01-31", 0.01), ("usa", "be_me", "2000-02-29", 0.02),
            ("jpn", "be_me", "2000-01-31", 0.03), ("usa", "ret_12_1", "2000-01-31", 0.5)])
    with tempfile.TemporaryDirectory() as tmp:
        f = Path(tmp) / "jkp.csv"
        f.write_text(csv)
        w = lab08.load_jkp(f)
    assert list(w.columns) == ["jpn", "usa"] and abs(w.loc["2000-02", "usa"] - 0.02) < 1e-12


def test_missing_region_files_are_reported_not_fatal():
    import lab08

    with tempfile.TemporaryDirectory() as tmp:
        files = {k: str(Path(tmp) / "nope.zip") for k in lab08.REGIONS}
        r = lab08.load_regions("french", files)
    assert r["regions"] == {} and len(r["missing"]) == len(lab08.REGIONS)


def test_full_lab_runs_on_simulated_data():
    import lab08

    with tempfile.TemporaryDirectory() as tmp:
        summary = lab08.main(["--source", "sim", "--n-boot", "300", "--out", tmp])
        out = Path(tmp)
        assert len(list(out.glob("fig8_*.png"))) == 6
        report = (out / "lab08_report.md").read_text()
        assert "Simulated data" in report and "Your verdict" in report
        assert summary["break_diff_annual"] < 0  # the simulation builds in a post-2007 decline


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print(f"ok  {name}")
