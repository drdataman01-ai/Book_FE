"""Lab 8: Is Value Still Worth Waiting For?

Chapter 8 of *Financial Engineering and the Evidence: Active Learning by Verifying Famous Claims*.

CLAIM ON TRIAL
  "Cheap stocks earn higher returns than expensive ones."

WHAT THE LAB DOES
  Part A  Replication. The HML value factor from 1926: average return,
          t-statistic, Sharpe ratio and CAPM alpha, in four eras including
          the original Fama-French sample and the years since 2007.
  Part B  Stress tests. Other measures of cheapness (earnings, cash flow,
          dividends), value among large and small stocks, and the effect
          of trading costs.
  Part C  Other markets. Value in Europe, Japan, Asia Pacific and North
          America since 1990 (Kenneth French's international factors), and
          optionally in many countries with the Jensen-Kelly-Pedersen data.
  Part D  Living with value. Drawdowns, the longest time under water, and a
          bootstrap of ten-year outcomes used to size a value tilt an
          investor could hold.

DATA
  Kenneth R. French Data Library (monthly): Fama/French 3 Factors; 6
  Portfolios Formed on Size and Book-to-Market (2 x 3); Portfolios Formed
  on Book-to-Market, Earnings/Price, Cashflow/Price and Dividend Yield;
  international 3-factor files. Optional: a Jensen-Kelly-Pedersen
  country-factor CSV.

USAGE
  python lab08.py
  python lab08.py --source sim             # fake data, to test the code

OUTPUT
  report/lab08_report.md, six figures (PNG), CSV tables and summary.json.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

from fintest import plots
from fintest.data import DataUnavailable, find_table, load_french_factors, load_french_tables
from fintest.inference import stationary_bootstrap_indices
from fintest.stats import ols_newey_west

ROOT = Path(__file__).resolve().parent
ERAS = [("1926–1963", "1926-07", "1963-06"), ("1963–1990: Fama–French sample", "1963-07", "1990-12"),
        ("1991–2006", "1991-01", "2006-12"), ("2007–today", "2007-01", None)]
MEASURES = {"bm": "Book-to-market", "ep": "Earnings-to-price", "cfp": "Cash flow-to-price", "dp": "Dividend yield"}
REGIONS = {"north_america_ff3": "North America", "europe_ff3": "Europe", "japan_ff3": "Japan",
           "asia_pacific_ex_japan_ff3": "Asia Pacific ex Japan", "developed_ex_us_ff3": "Developed ex US"}
NMV_VALUE_TURNOVER = 0.0291  # Novy-Marx and Velikov (2016), Table 3


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------


def _col(df, *names):
    cols = {c.strip().lower().replace(" ", ""): c for c in df.columns}
    for n in names:
        k = n.lower().replace(" ", "")
        if k in cols:
            return df[cols[k]]
    raise KeyError(f"none of {names} in {list(df.columns)}")


def hi_minus_lo(table: pd.DataFrame) -> pd.Series:
    """Top 30% minus bottom 30% from a univariate French portfolio file (value-weighted table)."""
    return _col(table, "Hi 30") - _col(table, "Lo 30")


def load_us(source: str, files: dict, sim_seed: int = 0) -> dict:
    if source == "sim":
        return simulated_us(seed=sim_seed)
    ff3 = load_french_factors("ff3_monthly", path=files.get("ff3"))
    six = find_table(load_french_tables("size_bm_6", path=files.get("six")), "value", "weight")
    out = {"hml": _col(ff3, "HML"), "mkt": _col(ff3, "Mkt-RF"), "rf": _col(ff3, "RF"),
           "hml_big": six.iloc[:, 5] - six.iloc[:, 3], "hml_small": six.iloc[:, 2] - six.iloc[:, 0]}
    for key in MEASURES:
        t = load_french_tables(f"{key}_portfolios", path=files.get(key))
        out[f"hl_{key}"] = hi_minus_lo(find_table(t, "value", "weight"))
    out["simulated"] = False
    return out


def load_regions(source: str, files: dict, sim_seed: int = 0) -> dict:
    if source == "sim":
        return simulated_regions(seed=sim_seed)
    out, missing = {}, []
    for key, label in REGIONS.items():
        try:
            df = load_french_factors(key, path=files.get(key))
            out[label] = pd.DataFrame({"hml": _col(df, "HML"), "mkt": _col(df, "Mkt-RF")}).dropna()
        except (DataUnavailable, KeyError, ValueError) as err:
            missing.append(f"{label}: {str(err).splitlines()[0]}")
    return {"regions": out, "missing": missing}


def load_jkp(path) -> pd.DataFrame:
    """Value factor returns by country from a Jensen-Kelly-Pedersen CSV (columns: location, name, date, ret).

    Keeps the book-to-market factor (name 'be_me'); returns a wide table of monthly returns, one column per
    country.
    """
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]
    need = {"location", "name", "date", "ret"}
    if not need <= set(df.columns):
        raise DataUnavailable(f"JKP file needs columns {sorted(need)}; found {list(df.columns)}")
    df = df[df["name"].str.lower() == "be_me"].copy()
    df["date"] = pd.to_datetime(df["date"]).dt.to_period("M")
    wide = df.pivot_table(index="date", columns="location", values="ret", aggfunc="mean")
    return wide.sort_index()


def simulated_us(n_months: int = 1188, seed: int = 0, start: str = "1926-07") -> dict:
    """Fake U.S. factor data with a value premium that shrinks after 2007. FOR TESTING CODE ONLY."""
    rng = np.random.default_rng(seed)
    idx = pd.period_range(start, periods=n_months, freq="M", name="date")
    post = np.asarray(idx >= pd.Period("2007-01", "M"))
    t5 = lambda k=1: rng.standard_t(5, (n_months, k)) / math.sqrt(5 / 3)  # noqa: E731
    mkt = 0.0065 + 0.053 * t5()[:, 0]
    common = t5()[:, 0]
    mu = np.where(post, -0.001, 0.004)
    hml = mu + 0.03 * common
    s = lambda scale, m: pd.Series(m + scale * (0.8 * common + 0.6 * t5()[:, 0]), index=idx)  # noqa: E731
    out = {"hml": pd.Series(hml, index=idx), "mkt": pd.Series(mkt, index=idx), "rf": pd.Series(0.0028, index=idx),
           "hml_big": s(0.03, np.where(post, -0.002, 0.0025)), "hml_small": s(0.032, np.where(post, 0.0, 0.0055))}
    for k, m in (("bm", 0.0035), ("ep", 0.004), ("cfp", 0.0038), ("dp", 0.002)):
        out[f"hl_{k}"] = s(0.04, np.where(post, m - 0.004, m))
    out["simulated"] = True
    return out


def simulated_regions(seed: int = 0) -> dict:
    rng = np.random.default_rng(seed + 1)
    idx = pd.period_range("1990-07", "2025-06", freq="M", name="date")
    n = len(idx)
    regions = {}
    for k, label in enumerate(REGIONS.values()):
        m = [0.003, 0.004, 0.004, 0.005, 0.0035][k]
        regions[label] = pd.DataFrame({"hml": m + 0.03 * rng.standard_normal(n),
                                       "mkt": 0.005 + 0.05 * rng.standard_normal(n)}, index=idx)
    return {"regions": regions, "missing": []}


def _slice(s: pd.Series, start, end):
    return s.loc[pd.Period(start, "M") if start else None:pd.Period(end, "M") if end else None].dropna()


def _stats(r: pd.Series, mkt: pd.Series | None = None) -> dict:
    x = r.dropna().to_numpy()
    m, sd = x.mean(), x.std(ddof=1)
    out = {"mean_annual": 12 * m, "t": m / (sd / math.sqrt(len(x))), "sharpe": m / sd * math.sqrt(12),
           "vol_annual": sd * math.sqrt(12), "months": len(x), "start": str(r.dropna().index[0]),
           "end": str(r.dropna().index[-1])}
    if mkt is not None:
        j = pd.concat([r, mkt], axis=1).dropna()
        reg = ols_newey_west(j.iloc[:, 0].to_numpy(), j.iloc[:, 1].to_numpy())
        out["capm_alpha_annual"] = 12 * float(reg["coef"][0, 0])
        out["capm_alpha_t"] = float(reg["t"][0, 0])
        out["market_beta"] = float(reg["coef"][1, 0])
    return out


# ---------------------------------------------------------------------------
# Part A: replication
# ---------------------------------------------------------------------------


def part_a(us: dict) -> dict:
    hml, mkt = us["hml"], us["mkt"]
    rows = [{"era": "Full sample", **_stats(hml, mkt)}]
    for label, s, e in ERAS:
        rows.append({"era": label, **_stats(_slice(hml, s, e), mkt)})
    pre, post = _slice(hml, None, "2006-12"), _slice(hml, "2007-01", None)
    diff = post.mean() - pre.mean()
    se = math.sqrt(post.var(ddof=1) / len(post) + pre.var(ddof=1) / len(pre))
    return {"table": pd.DataFrame(rows), "break_diff_annual": 12 * diff, "break_t": diff / se}


# ---------------------------------------------------------------------------
# Part B: stress tests
# ---------------------------------------------------------------------------


def part_b(us: dict, costs=(0.002, 0.005)) -> dict:
    series = {"HML (Fama–French)": us["hml"], "Value among large stocks": us["hml_big"],
              "Value among small stocks": us["hml_small"]}
    series |= {f"{MEASURES[k]} (top 30% − bottom 30%)": us[f"hl_{k}"] for k in MEASURES}
    rows = []
    for name, s in series.items():
        for label, a, b in (("Full sample", None, None), ("To 2006", None, "2006-12"), ("2007–today", "2007-01", None)):
            st = _stats(_slice(s, a, b))
            rows.append({"series": name, "period": label, **st})
    cost_rows = []
    g = us["hml"].dropna()
    for c in costs:
        net = g - 4 * NMV_VALUE_TURNOVER * c
        cost_rows.append({"one_way_cost": c, "gross_mean_annual": 12 * g.mean(), "net_mean_annual": 12 * net.mean(),
                          "net_t": _stats(net)["t"]})
    return {"table": pd.DataFrame(rows), "costs": pd.DataFrame(cost_rows)}


# ---------------------------------------------------------------------------
# Part C: other markets
# ---------------------------------------------------------------------------


def part_c(regions: dict, us: dict, jkp: pd.DataFrame | None = None) -> dict:
    rows = []
    first = min(df.index[0] for df in regions["regions"].values()) if regions["regions"] else pd.Period("1990-07", "M")
    us_hml = _slice(us["hml"], str(first), None)
    for label, s in [("United States (same period)", us_hml)] + [(k, v["hml"]) for k, v in regions["regions"].items()]:
        for plabel, a, b in (("Full period", None, None), ("To 2006", None, "2006-12"), ("2007–today", "2007-01", None)):
            ss = _slice(s, a, b)
            if len(ss) < 36:
                continue
            rows.append({"market": label, "period": plabel, **_stats(ss)})
    out = {"table": pd.DataFrame(rows), "missing": regions["missing"]}
    if jkp is not None:
        jr = []
        for country in jkp.columns:
            s = jkp[country].dropna()
            if len(s) >= 120:
                st = _stats(s)
                jr.append({"country": country, "mean_annual": st["mean_annual"], "t": st["t"], "months": st["months"],
                           "start": st["start"]})
        out["jkp"] = pd.DataFrame(jr).sort_values("mean_annual", ascending=False)
    return out


# ---------------------------------------------------------------------------
# Part D: living with value
# ---------------------------------------------------------------------------


def drawdown_stats(r: pd.Series) -> dict:
    x = r.dropna()
    wealth = (1 + x).cumprod()
    peak = wealth.cummax()
    dd = wealth / peak - 1
    under = dd < 0
    longest, cur, start_best, cur_start = 0, 0, None, None
    for i, u in enumerate(under.to_numpy()):
        if u:
            if cur == 0:
                cur_start = i
            cur += 1
            if cur > longest:
                longest, start_best = cur, cur_start
        else:
            cur = 0
    roll10 = (np.log1p(x).rolling(120).sum() / 10).dropna()
    return {"max_drawdown": float(dd.min()), "max_drawdown_date": str(dd.idxmin()),
            "longest_underwater_months": int(longest),
            "longest_underwater_start": str(x.index[start_best]) if start_best is not None else "",
            "worst_10y_annual": float(np.expm1(roll10.min())), "worst_10y_end": str(roll10.idxmin()),
            "share_10y_negative": float((roll10 < 0).mean()), "drawdown": dd, "roll10": roll10}


def bootstrap_10y(r: pd.Series, n_boot: int = 5000, block: float = 24, seed: int = 0) -> np.ndarray:
    """Distribution of 10-year cumulative returns from a stationary bootstrap of monthly returns."""
    x = r.dropna().to_numpy()
    rng = np.random.default_rng(seed)
    out = np.empty(n_boot)
    for b in range(n_boot):
        idx = stationary_bootstrap_indices(len(x), block, rng)[:120]
        out[b] = np.prod(1 + x[idx]) - 1
    return out


def part_d(us: dict, tolerance: float = 0.10, n_boot: int = 5000, seed: int = 0) -> dict:
    hml = us["hml"].dropna()
    dds = drawdown_stats(hml)
    boot_full = bootstrap_10y(hml, n_boot, seed=seed)
    boot_recent = bootstrap_10y(_slice(hml, "1991-01", None), n_boot, seed=seed + 1)
    p5_full, p5_recent = np.quantile(boot_full, 0.05), np.quantile(boot_recent, 0.05)
    tilts = []
    for w in (0.1, 0.25, 0.5, 1.0):
        tilts.append({"tilt": w, "tracking_error_annual": w * hml.std(ddof=1) * math.sqrt(12),
                      "p_trail_10y_full": float((boot_full < 0).mean()),
                      "bad_case_10y_full": w * p5_full, "bad_case_10y_recent": w * p5_recent,
                      "worst_realized_10y": w * float(np.expm1(dds["roll10"].min() * 10))})
    w_max = tolerance / abs(min(p5_full, p5_recent)) if min(p5_full, p5_recent) < 0 else float("inf")
    return {"drawdowns": dds, "boot_full": boot_full, "boot_recent": boot_recent, "p5_full": float(p5_full),
            "p5_recent": float(p5_recent), "tilts": pd.DataFrame(tilts), "w_max": float(w_max),
            "tolerance": tolerance}


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------


def _sub(sim: bool, text: str) -> str:
    return text + ("  ·  SIMULATED DATA: tests the code only" if sim else "")


def fig_cumulative(us, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 5.0)
    h = us["hml"].dropna()
    w = (1 + h).cumprod()
    dates = h.index.to_timestamp()
    shades = [plots.GRID, plots.SURFACE]
    for k, (label, s, e) in enumerate(ERAS):
        a = pd.Period(s, "M").to_timestamp()
        b = pd.Period(e, "M").to_timestamp() if e else dates[-1]
        ax.axvspan(a, b, color=plots.INK_3, alpha=0.06 if k % 2 == 0 else 0.0, linewidth=0)
        ax.text(a + (b - a) / 2, 1.0, label.split(":")[0], ha="center", va="bottom", fontsize=8.5, color=plots.INK_2,
                transform=ax.get_xaxis_transform())
    ax.plot(dates, w, color=plots.BLUE, linewidth=1.8)
    ax.set_yscale("log")
    ax.set_ylabel("Growth of $1 in HML (log scale)")
    plots.titles(fig, "Lab Figure 8.1  A century of value: long gains, long droughts",
                 _sub(sim, f"Fama–French HML, {h.index[0]} to {h.index[-1]} · long cheap stocks, short expensive "
                           "ones, rebalanced each June"))
    plots.finish(fig, out / "fig8_1_cumulative.png")
    plt.close(fig)


def fig_eras(a, out, sim):
    fig, ax, plt = plots.new_figure(8.5, 4.4)
    t = a["table"].iloc[::-1].reset_index(drop=True)
    y = np.arange(len(t))
    se = t["mean_annual"] / t["t"]
    ax.errorbar(t["mean_annual"], y, xerr=1.96 * se, fmt="o", color=plots.BLUE, ecolor=plots.INK_3, capsize=4,
                markersize=7)
    for yi, (_, r) in zip(y, t.iterrows()):
        ax.text(r.mean_annual, yi + 0.22, f"{r.mean_annual:+.1%} (t = {r.t:.1f})", ha="center", fontsize=8.5,
                color=plots.INK)
    ax.axvline(0, color=plots.INK_3, linewidth=1)
    ax.set_yticks(y, t["era"], fontsize=9, color=plots.INK)
    plots.percent_axis(ax, "x")
    ax.set_ylim(-0.6, len(t) - 0.4)
    ax.grid(axis="y", visible=False)
    ax.grid(axis="x", color=plots.GRID, linewidth=0.8)
    ax.set_xlabel("Average HML return per year, with 95% interval")
    plots.titles(fig, "Lab Figure 8.2  The value premium by era",
                 _sub(sim, f"Difference after 2007 versus before: {a['break_diff_annual']:+.1%} a year "
                           f"(t = {a['break_t']:.1f})"))
    plots.finish(fig, out / "fig8_2_eras.png")
    plt.close(fig)


def fig_robustness(b, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 5.0)
    t = b["table"]
    names = list(dict.fromkeys(t["series"]))
    y = np.arange(len(names))[::-1]
    styles = {"Full sample": ("o", plots.INK), "To 2006": ("s", plots.BLUE), "2007–today": ("D", plots.RED)}
    for per, (mk, col) in styles.items():
        g = t[t.period == per].set_index("series").loc[names]
        ax.scatter(g["mean_annual"], y, marker=mk, color=col, s=45, label=per, zorder=3, edgecolor=plots.SURFACE)
    ax.axvline(0, color=plots.INK_3, linewidth=1)
    ax.set_yticks(y, names, fontsize=9, color=plots.INK)
    plots.percent_axis(ax, "x")
    ax.grid(axis="y", visible=False)
    ax.grid(axis="x", color=plots.GRID, linewidth=0.8)
    ax.legend(frameon=True, facecolor=plots.SURFACE, edgecolor=plots.GRID, fontsize=8.5, loc="lower center",
              ncol=3)
    ax.set_xlabel("Average long-short return per year")
    plots.titles(fig, "Lab Figure 8.3  Different measures of cheapness, large and small stocks",
                 _sub(sim, "Value-weighted portfolios from the Kenneth French library · E/P and CF/P begin in 1951"))
    plots.finish(fig, out / "fig8_3_robustness.png")
    plt.close(fig)


def fig_international(c, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 4.8)
    t = c["table"]
    markets = list(dict.fromkeys(t["market"]))
    y = np.arange(len(markets))[::-1]
    for per, (off, col) in {"To 2006": (0.17, plots.BLUE), "2007–today": (-0.17, plots.RED)}.items():
        g = t[t.period == per].set_index("market").reindex(markets)
        ax.barh(y + off, g["mean_annual"], height=0.32, color=col, label=per)
    ax.axvline(0, color=plots.INK_3, linewidth=1)
    ax.set_yticks(y, markets, fontsize=9, color=plots.INK)
    plots.percent_axis(ax, "x")
    ax.grid(axis="y", visible=False)
    ax.grid(axis="x", color=plots.GRID, linewidth=0.8)
    ax.legend(frameon=False, fontsize=8.5, loc="lower right")
    ax.set_xlabel("Average HML return per year")
    note = f" · not loaded: {len(c['missing'])} region file(s)" if c["missing"] else ""
    plots.titles(fig, "Lab Figure 8.4  Value around the world, before and after 2007",
                 _sub(sim, "Kenneth French international HML factors, from 1990" + note))
    plots.finish(fig, out / "fig8_4_international.png")
    plt.close(fig)


def fig_drawdown(d, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 4.2)
    dd = d["drawdowns"]["drawdown"]
    dates = dd.index.to_timestamp()
    ax.fill_between(dates, dd.to_numpy(), 0, color=plots.RED, alpha=0.35, linewidth=0)
    ax.plot(dates, dd.to_numpy(), color=plots.RED, linewidth=1)
    plots.percent_axis(ax)
    ax.set_ylabel("Below previous peak")
    dds = d["drawdowns"]
    plots.titles(fig, "Lab Figure 8.5  How long value can disappoint",
                 _sub(sim, f"HML drawdowns · worst {dds['max_drawdown']:.0%} ({dds['max_drawdown_date']}) · longest "
                           f"spell below a previous peak: {dds['longest_underwater_months'] / 12:.1f} years from "
                           f"{dds['longest_underwater_start']}"))
    plots.finish(fig, out / "fig8_5_drawdowns.png")
    plt.close(fig)


def fig_tilt(d, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 4.6)
    bins = np.linspace(min(d["boot_full"].min(), d["boot_recent"].min()), np.quantile(d["boot_full"], 0.995), 60)
    ax.hist(d["boot_full"], bins=bins, color=plots.BLUE, alpha=0.5, label="Resampling the full history")
    ax.hist(d["boot_recent"], bins=bins, color=plots.ORANGE, alpha=0.5, label="Resampling 1991–today only")
    for v, col in ((d["p5_full"], plots.BLUE), (d["p5_recent"], plots.ORANGE)):
        ax.axvline(v, color=col, linewidth=1.5, linestyle=(0, (4, 3)))
    ax.axvline(0, color=plots.INK, linewidth=1)
    plots.percent_axis(ax, "x")
    ax.set_xlabel("Cumulative HML return over 10 years (value minus growth)")
    ax.set_ylabel("Bootstrap samples")
    ax.legend(frameon=False, fontsize=8.5)
    plots.titles(fig, "Lab Figure 8.6  Ten-year outcomes for a value bet",
                 _sub(sim, f"Stationary bootstrap, 24-month blocks · dashed: 5th percentiles ({d['p5_full']:.0%} and "
                           f"{d['p5_recent']:.0%}) · a tilt of w loses w times these against the market"))
    plots.finish(fig, out / "fig8_6_ten_year.png")
    plt.close(fig)


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------


def _md(df: pd.DataFrame, fmt: dict) -> str:
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join("---" for _ in cols) + " |"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(fmt[c](r[c]) if c in fmt else str(r[c]) for c in cols) + " |")
    return "\n".join(lines)


def _num(spec):
    return lambda v: "" if (v is None or (isinstance(v, float) and math.isnan(v))) else format(v, spec)


def write_report(out, us, a, b, c, d, sim):
    md = ["# Lab 8 results: Is Value Still Worth Waiting For?", ""]
    if sim:
        md += ["> **Simulated data.** These results test that the code runs; they say nothing about real markets. "
               "The simulated value premium is set to shrink after 2007.", ""]
    md += ["**Claim on trial:** cheap stocks earn higher returns than expensive ones.", ""]
    fm = {"mean_annual": _num("+.2%"), "t": _num(".2f"), "sharpe": _num(".2f"), "vol_annual": _num(".1%"),
          "capm_alpha_annual": _num("+.2%"), "capm_alpha_t": _num(".2f"), "market_beta": _num("+.2f")}
    ren = {"era": "Era", "mean_annual": "Mean (annual)", "t": "t", "sharpe": "Sharpe", "vol_annual": "Volatility",
           "capm_alpha_annual": "CAPM alpha (annual)", "capm_alpha_t": "Alpha t (NW)", "market_beta": "Market beta",
           "months": "Months", "start": "From", "end": "To"}
    md += ["## Part A: Replication", "",
           _md(a["table"].rename(columns=ren), {ren[k]: v for k, v in fm.items()}), "",
           f"Change after 2007 versus before: {a['break_diff_annual']:+.2%} a year (t = {a['break_t']:.2f}).", "",
           "![Lab Figure 8.1](fig8_1_cumulative.png)", "", "![Lab Figure 8.2](fig8_2_eras.png)", ""]
    tb = b["table"][["series", "period", "mean_annual", "t", "sharpe", "months", "start"]]
    md += ["## Part B: Stress tests", "",
           _md(tb.rename(columns={"series": "Series", "period": "Period", "mean_annual": "Mean (annual)", "t": "t",
                                  "sharpe": "Sharpe", "months": "Months", "start": "From"}),
               {"Mean (annual)": _num("+.2%"), "t": _num(".2f"), "Sharpe": _num(".2f")}), "",
           "**After trading costs** (turnover 2.9% a month, Novy-Marx and Velikov 2016; cost = 4 × turnover × one-way "
           "cost):", "",
           _md(b["costs"].assign(one_way_cost=b["costs"]["one_way_cost"] * 1e4).rename(columns={
               "one_way_cost": "One-way cost (bp)", "gross_mean_annual": "Gross (annual)", "net_mean_annual": "Net (annual)",
               "net_t": "Net t"}), {"One-way cost (bp)": _num(".0f"), "Gross (annual)": _num("+.2%"),
                                    "Net (annual)": _num("+.2%"), "Net t": _num(".2f")}), "",
           "![Lab Figure 8.3](fig8_3_robustness.png)", ""]
    md += ["## Part C: Other markets", "",
           _md(c["table"][["market", "period", "mean_annual", "t", "months", "start"]].rename(columns={
               "market": "Market", "period": "Period", "mean_annual": "Mean (annual)", "t": "t", "months": "Months",
               "start": "From"}), {"Mean (annual)": _num("+.2%"), "t": _num(".2f")}), ""]
    if c["missing"]:
        md += ["Not loaded: " + "; ".join(c["missing"]), ""]
    if "jkp" in c:
        md += ["**Jensen–Kelly–Pedersen book-to-market factor by country**", "",
               _md(c["jkp"], {"mean_annual": _num("+.2%"), "t": _num(".2f")}), ""]
    md += ["![Lab Figure 8.4](fig8_4_international.png)", ""]
    dds = d["drawdowns"]
    md += ["## Part D: Living with value", "",
           f"- Worst drawdown: {dds['max_drawdown']:.1%}, reached {dds['max_drawdown_date']}.",
           f"- Longest spell below a previous peak: {dds['longest_underwater_months']} months "
           f"({dds['longest_underwater_months'] / 12:.1f} years), starting {dds['longest_underwater_start']}.",
           f"- Worst realized 10 years: {dds['worst_10y_annual']:+.1%} a year (ending {dds['worst_10y_end']}); share of "
           f"rolling 10-year periods with a negative return: {dds['share_10y_negative']:.0%}.",
           f"- Bootstrap probability that value trails growth over a 10-year period: "
           f"{(d['boot_full'] < 0).mean():.0%} (full history), {(d['boot_recent'] < 0).mean():.0%} (1991–today).",
           f"- A tilt of w adds w × HML to a market portfolio. To keep a bad-case (5th percentile) 10-year shortfall "
           f"against the market below {d['tolerance']:.0%}, w can be at most about {d['w_max']:.2f}.", "",
           _md(d["tilts"].rename(columns={"tilt": "Tilt w", "tracking_error_annual": "Tracking error (annual)",
                                          "p_trail_10y_full": "P(trail market over 10 years)",
                                          "bad_case_10y_full": "Bad case 10-year (full history)",
                                          "bad_case_10y_recent": "Bad case 10-year (1991–today)",
                                          "worst_realized_10y": "Worst realized 10-year"}),
               {"Tilt w": _num(".2f"), "Tracking error (annual)": _num(".1%"), "P(trail market over 10 years)": _num(".0%"),
                "Bad case 10-year (full history)": _num("+.1%"), "Bad case 10-year (1991–today)": _num("+.1%"),
                "Worst realized 10-year": _num("+.1%")}), "",
           "![Lab Figure 8.5](fig8_5_drawdowns.png)", "", "![Lab Figure 8.6](fig8_6_ten_year.png)", ""]
    md += ["## Your verdict", "",
           "1. Does the value premium survive over the full history? Since 2007? Is the post-2007 shortfall "
           "statistically distinguishable from bad luck?",
           "2. Which stress test matters most: other measures, large stocks, other countries or costs?",
           "3. How large a value tilt could you, or a client, actually hold through the worst decade in the data?", ""]
    (out / "lab08_report.md").write_text("\n".join(md))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", choices=["french", "sim"], default="french")
    ap.add_argument("--ff3-file"), ap.add_argument("--six-file"), ap.add_argument("--bm-file")
    ap.add_argument("--ep-file"), ap.add_argument("--cfp-file"), ap.add_argument("--dp-file")
    for key in REGIONS:
        ap.add_argument(f"--{key.replace('_', '-')}-file", dest=f"{key}_file")
    ap.add_argument("--jkp-file", default=None, help="optional Jensen-Kelly-Pedersen CSV (location, name, date, ret)")
    ap.add_argument("--tolerance", type=float, default=0.10, help="bad-case 10-year shortfall an investor accepts")
    ap.add_argument("--n-boot", type=int, default=5000)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--sim-seed", type=int, default=0)
    ap.add_argument("--out", default=str(ROOT / "report"))
    return ap.parse_args(argv)


def run(args) -> dict:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    files = {"ff3": args.ff3_file, "six": args.six_file, "bm": args.bm_file, "ep": args.ep_file, "cfp": args.cfp_file,
             "dp": args.dp_file} | {k: getattr(args, f"{k}_file") for k in REGIONS}
    try:
        us = load_us(args.source, files, args.sim_seed)
        regions = load_regions(args.source, files, args.sim_seed)
        jkp = load_jkp(args.jkp_file) if args.jkp_file else None
    except DataUnavailable as err:
        raise SystemExit(str(err)) from None
    sim = us["simulated"]

    a = part_a(us)
    b = part_b(us)
    c = part_c(regions, us, jkp)
    d = part_d(us, args.tolerance, args.n_boot, args.seed)

    fig_cumulative(us, out, sim)
    fig_eras(a, out, sim)
    fig_robustness(b, out, sim)
    fig_international(c, out, sim)
    fig_drawdown(d, out, sim)
    fig_tilt(d, out, sim)

    a["table"].to_csv(out / "table_eras.csv", index=False)
    b["table"].to_csv(out / "table_robustness.csv", index=False)
    c["table"].to_csv(out / "table_international.csv", index=False)
    d["tilts"].to_csv(out / "table_tilts.csv", index=False)
    write_report(out, us, a, b, c, d, sim)

    dds = d["drawdowns"]
    summary = {"simulated": sim, "eras": a["table"].to_dict(orient="records"),
               "break_diff_annual": a["break_diff_annual"], "break_t": a["break_t"],
               "robustness": b["table"].to_dict(orient="records"), "international": c["table"].to_dict(orient="records"),
               "missing_regions": c["missing"],
               "max_drawdown": dds["max_drawdown"], "longest_underwater_months": dds["longest_underwater_months"],
               "worst_10y_annual": dds["worst_10y_annual"], "p_trail_10y": float((d["boot_full"] < 0).mean()),
               "w_max": d["w_max"]}
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=float))

    t = a["table"].set_index("era")
    for era, r in t.iterrows():
        print(f"{era:32s} HML {r.mean_annual:+.2%}/yr  t = {r.t:5.2f}")
    print(f"Longest under water: {dds['longest_underwater_months'] / 12:.1f} years; max drawdown "
          f"{dds['max_drawdown']:.0%}; max tilt for a {args.tolerance:.0%} bad-case shortfall: {d['w_max']:.2f}")
    if c["missing"]:
        print("Regions not loaded: " + "; ".join(c["missing"]))
    print(f"Report: {out / 'lab08_report.md'}")
    if sim:
        print("NOTE: simulated data. These results test the code only.")
    return summary


def main(argv=None):
    return run(parse_args(argv))


if __name__ == "__main__":
    main()
