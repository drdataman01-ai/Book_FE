"""fintest: the analysis module for *Financial Engineering and the Evidence:
Active Learning by Verifying Famous Claims*.

This copy contains the parts Labs 1 to 9 use:

* fintest.data   - download and parse data from the Kenneth R. French Data Library
* fintest.stats  - returns, Sharpe ratios, drawdowns, Newey-West regressions, multiple-testing helpers
* fintest.inference - stylized facts, robust and bootstrap errors, GRS, Fama-MacBeth, Hodrick
* fintest.multiple - multiple-testing corrections, deflated Sharpe ratio, PBO by CSCV
* fintest.predictors - the Goyal-Welch equity-premium predictors
* fintest.forecast - walk-forward forecasts, out-of-sample R2, Clark-West, scoring rules
* fintest.costs - trading costs, turnover, a simulated stock universe, impact and capacity
* fintest.shiller - Robert Shiller's long-run market data (CAPE)
* fintest.plots  - the book's chart style

Later chapters add backtesting with costs.
"""

__version__ = "0.9.0"
