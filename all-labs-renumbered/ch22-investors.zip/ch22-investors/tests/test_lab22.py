"""Tests for Lab 22. Run with:  python tests/test_lab22.py   (or: pytest tests/)

Runs offline: time- and money-weighted returns on hand-built cases, the behavior gap when money arrives before
losses, flow-timing regressions, the disposition simulation (PGR above PLR only with a bias), the cost of turnover,
withdrawal rules with known returns, bond returns from yields, the flow-file reader and the full lab on simulated
data (about two minutes).
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fintest.behavior import (aggregate_investor, bond_returns_annual, money_weighted,  # noqa: E402
                              simulate_disposition, simulated_assets_with_momentum, time_weighted,
                              turnover_experiment, withdrawal_success)


def test_twr_and_mwr():
    assert abs(time_weighted([0.1, -0.1]) - (-0.01)) < 1e-12
    # invest 100, get 110 one year later -> 10%
    assert abs(money_weighted([-100, 110], periods_per_year=1) - 0.10) < 1e-9
    idx = pd.period_range("2000-01", periods=24, freq="M")
    r = pd.Series(0.01, index=idx)
    g = aggregate_investor(r, pd.Series(0.0, index=idx), 100.0)
    assert abs(g["gap"]) < 1e-9 and abs(g["time_weighted"] - (1.01 ** 12 - 1)) < 1e-9


def test_gap_when_money_arrives_before_losses():
    idx = pd.period_range("2000-01", periods=24, freq="M")
    r = pd.Series([0.03] * 12 + [-0.03] * 12, index=idx)
    f = pd.Series([0.0] * 11 + [500.0] + [0.0] * 12, index=idx)       # big inflow after the good year
    g = aggregate_investor(r, f, 100.0)
    assert g["gap"] < -0.03


def test_disposition_simulation():
    R = simulated_assets_with_momentum(n_assets=30, n_months=240, seed=3)
    s0 = simulate_disposition(R, n_agents=80, winner_bias=0.0, seed=1)
    s9 = simulate_disposition(R, n_agents=80, winner_bias=0.9, seed=1)
    assert abs(s0["PGR"] - s0["PLR"]) < 0.06
    assert s9["PGR"] > s9["PLR"] + 0.15


def test_turnover_cost():
    idx = pd.period_range("2000-01", periods=120, freq="M")
    R = pd.DataFrame(0.005, index=idx, columns=[f"A{i}" for i in range(20)])
    t = turnover_experiment(R, turnovers=(0.0, 1.0), cost_bp=50, n_agents=20).set_index("annual_turnover")
    assert abs(t.loc[0.0, "cost_drag"]) < 1e-12
    assert 0.007 < t.loc[1.0, "cost_drag"] < 0.013          # about 2 x 100% x 50 bp = 1% a year


def test_withdrawal_rules():
    idx = pd.Index(range(1900, 1960))
    s = pd.Series(0.0, index=idx)
    b = pd.Series(0.0, index=idx)
    t = withdrawal_success(s, b, rates=(0.03, 0.04), years=30).set_index("rate")
    assert t.loc[0.03, "success_rate"] == 1.0 and t.loc[0.04, "success_rate"] == 0.0   # 30 x 4% > 100%
    p = withdrawal_success(s, b, rates=(0.04,), years=30, rule="percent")
    assert p["success_rate"].iloc[0] == 1.0


def test_bond_returns_annual():
    idx = pd.Index(range(2000, 2004))
    r = bond_returns_annual(pd.Series([5.0, 5.0, 6.0, 6.0], index=idx), pd.Series([100, 102, 104.04, 106.1208], index=idx))
    assert abs(r.loc[2001] - (1.05 / 1.02 - 1)) < 1e-9       # unchanged yield: coupon, deflated
    assert r.loc[2002] < 0                                     # yield up 1 point: price loss beats coupon net of inflation


def test_flow_reader():
    import lab22

    with tempfile.TemporaryDirectory() as tmp:
        f = Path(tmp) / "flows.csv"
        pd.DataFrame({"Date": ["2020-01-31", "2020-02-29"], "Net new cash flow": [10, -5],
                      "Total net assets": [1000, 1010]}).to_csv(f, index=False)
        fl = lab22.read_flows(f)
        assert list(fl["flow"]) == [10, -5] and fl["assets"].iloc[0] == 1000


def test_full_lab_runs_on_simulated_data():
    import lab22

    with tempfile.TemporaryDirectory() as tmp:
        s = lab22.main(["--source", "sim", "--out", tmp])
        assert len(list(Path(tmp).glob("fig22_*.png"))) == 5
        rep = (Path(tmp) / "lab22_report.md").read_text()
        assert "Simulated data" in rep and "Your verdict" in rep
        assert s["gap"]["gap"] < 0                                  # simulated flows chase returns
        assert s["timing"]["flow_on_past_return"]["t"] > 2


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print(f"ok  {name}")
