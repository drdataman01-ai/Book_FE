"""Lab 22: Do Individual Investors Hurt Themselves?

Chapter 22 of *Financial Engineering and the Evidence: Active Learning by Verifying Famous Claims*.

CLAIM ON TRIAL
  "Individual investors lose part of the return on their investments
   through their own trading behavior."

WHAT THE LAB DOES
  Part A  The behavior gap: time-weighted versus money-weighted returns of
          the aggregate investor in equity funds, from public net-flow data;
          do flows chase past returns, and do they predict future returns?
  Part B  The disposition effect: simulated investors who prefer selling
          winners trade the 49 industry portfolios; Odean's PGR and PLR, and
          what the winners sold and the losers kept did next.
  Part C  Overtrading: random portfolios with turnover from 0% to 250% a
          year, net of trading costs.
  Part D  Lifecycle: how often fixed, percentage and guardrail withdrawal
          rules survived 30 years of US history; sequence-of-returns risk.

DATA (free)
  Net flows to equity funds: a CSV you save from the Investment Company
  Institute (see README). Kenneth R. French Data Library: Fama/French 3
  Factors and 49 Industry Portfolios. Robert Shiller's ie_data.xls (Part D).

USAGE
  python lab22.py --flows-file data/equity_flows.csv --shiller-file data/ie_data.xls
  python lab22.py --source sim
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

from fintest import plots
from fintest.behavior import (aggregate_investor, bond_returns_annual, flow_timing, sequence_risk_example,
                              simulate_disposition, simulated_annual_real, simulated_assets_with_momentum,
                              simulated_flows, turnover_experiment, withdrawal_success)
from fintest.data import DataUnavailable, find_table, load_french_factors, load_french_tables
from fintest.shiller import read_shiller

ROOT = Path(__file__).resolve().parent


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------


def read_flows(path) -> pd.DataFrame:
    """CSV with a date column, a net-flow column and optionally an assets column (same currency units)."""
    df = pd.read_csv(path)
    low = {c.lower().strip(): c for c in df.columns}
    dcol = next((low[k] for k in ("date", "month", "period") if k in low), df.columns[0])
    fcol = next((low[k] for k in low if "flow" in k or "net new cash" in k), None)
    acol = next((low[k] for k in low if "asset" in k), None)
    if fcol is None:
        raise DataUnavailable(f"No flow column found in {path}; columns: {list(df.columns)}")
    idx = pd.to_datetime(df[dcol]).dt.to_period("M")
    out = pd.DataFrame({"flow": pd.to_numeric(df[fcol], errors="coerce").to_numpy()}, index=idx)
    if acol:
        out["assets"] = pd.to_numeric(df[acol], errors="coerce").to_numpy()
    return out.groupby(level=0).sum(min_count=1).dropna(subset=["flow"])


def annual_from_shiller(sh: pd.DataFrame) -> pd.DataFrame:
    jan = sh[sh.index.month == 1]
    stock = (jan["real_tr_price"] / jan["real_tr_price"].shift(1) - 1) if "real_tr_price" in sh else None
    if stock is None or stock.isna().all():
        tr = (sh["price"] + sh["dividend"] / 12) / sh["price"].shift(1)
        real = tr / (sh["cpi"] / sh["cpi"].shift(1))
        stock = np.exp(np.log(real).groupby(sh.index.year).sum()).shift(-0) - 1
        stock.index = stock.index.astype(int)
    else:
        stock.index = jan.index.year
    bond = bond_returns_annual(pd.Series(jan["gs10"].to_numpy(), index=jan.index.year),
                               pd.Series(jan["cpi"].to_numpy(), index=jan.index.year))
    # returns from January of year t-1 to January of year t are labelled t-1 (the year they cover)
    df = pd.DataFrame({"stock": stock.shift(-1), "bond": bond.shift(-1)}).dropna()
    df.index.name = "year"
    return df


def load(args) -> dict:
    notes = []
    if args.source == "sim":
        f = simulated_flows(seed=args.sim_seed)
        return {"returns": f["returns"], "flows": f["flows"], "start_assets": f["start_assets"],
                "assets_panel": simulated_assets_with_momentum(seed=args.sim_seed),
                "annual": simulated_annual_real(seed=args.sim_seed), "simulated": True, "notes": notes}
    ff = load_french_factors("ff3_monthly", path=args.ff3_file)
    col = lambda n: ff[[c for c in ff.columns if c.strip().upper() == n][0]]  # noqa: E731
    mkt = col("MKT-RF") + col("RF")
    out = {"simulated": False, "notes": notes, "returns": None, "flows": None, "start_assets": None}
    if args.flows_file:
        fl = read_flows(args.flows_file)
        r = mkt.reindex(fl.index).dropna()
        fl = fl.loc[r.index]
        out["returns"], out["flows"] = r, fl["flow"]
        out["start_assets"] = float(fl["assets"].dropna().iloc[0]) if "assets" in fl and fl["assets"].notna().any() \
            else args.start_assets
        if out["start_assets"] is None:
            raise DataUnavailable("Give --start-assets (assets at the start of the flow sample) or an assets column.")
        notes.append("fund returns proxied by the US market (French Mkt-RF + RF)")
    else:
        notes.append("no --flows-file: Part A skipped")
    t = load_french_tables("industry_49", path=args.ind49_file)
    out["assets_panel"] = find_table(t, "value", "weight").dropna()
    try:
        out["annual"] = annual_from_shiller(read_shiller(args.shiller_file)) if args.shiller_file else None
        if out["annual"] is None:
            notes.append("no --shiller-file: Part D skipped")
    except DataUnavailable as e:
        out["annual"] = None
        notes.append(f"Shiller data not loaded ({str(e).splitlines()[0]})")
    return out


# ---------------------------------------------------------------------------
# Parts
# ---------------------------------------------------------------------------


def part_a(d) -> dict | None:
    if d["flows"] is None:
        return None
    agg = aggregate_investor(d["returns"], d["flows"], d["start_assets"])
    timing = flow_timing(d["returns"], d["flows"], agg["assets"])
    decades = []
    r, f = d["returns"], d["flows"]
    for y0 in range(int(r.index[0].year) // 10 * 10, int(r.index[-1].year) + 1, 10):
        m = (r.index.year >= y0) & (r.index.year < y0 + 10)
        if m.sum() >= 36:
            a0 = agg["assets"].shift(1).fillna(d["start_assets"])[m].iloc[0]
            g = aggregate_investor(r[m], f[m], a0)
            decades.append({"decade": f"{y0}s", "time_weighted": g["time_weighted"], "money_weighted": g["money_weighted"],
                            "gap": g["gap"]})
    return {"agg": agg, "timing": timing, "decades": pd.DataFrame(decades)}


def part_b(d, biases=(0.0, 0.5, 0.9), seed: int = 0) -> pd.DataFrame:
    rows = []
    for wb in biases:
        s = simulate_disposition(d["assets_panel"], winner_bias=wb, seed=seed)
        rows.append({"winner_bias": wb, "PGR": s["PGR"], "PLR": s["PLR"], "PGR_minus_PLR": s["PGR_minus_PLR"],
                     "winners_sold_next_12m": s["winners_sold_next"], "losers_kept_next_12m": s["losers_kept_next"],
                     "sold_winners_minus_kept_losers": s["winners_sold_next"] - s["losers_kept_next"],
                     "agent_return_annual": float(12 * s["agent_returns"].iloc[1:].mean())})
    return pd.DataFrame(rows)


def part_c(d, cost_bp: float, seed: int = 0) -> pd.DataFrame:
    return turnover_experiment(d["assets_panel"], cost_bp=cost_bp, seed=seed)


def part_d(d) -> dict | None:
    if d["annual"] is None:
        return None
    an = d["annual"]
    tabs = [withdrawal_success(an["stock"], an["bond"], rule=r) for r in ("fixed_real", "percent", "guardrails")]
    worst = None
    fx = []
    for st in range(0, len(an) - 30 + 1):
        w = 1.0
        for y in range(30):
            w = (w - 0.04) * (1 + 0.6 * an["stock"].iloc[st + y] + 0.4 * an["bond"].iloc[st + y])
            if w <= 0:
                break
        fx.append({"start_year": int(an.index[st]), "end_wealth_4pct": max(w, 0.0)})
    fx = pd.DataFrame(fx)
    worst = fx.nsmallest(5, "end_wealth_4pct")
    seq_start = int(an.index[an.index.get_indexer([1966])[0]]) if 1966 in an.index else int(an.index[0])
    seq = sequence_risk_example(an.loc[seq_start:, "stock"], rate=0.05, equity=1.0)
    return {"table": pd.concat(tabs, ignore_index=True), "by_start": fx, "worst": worst, "seq": seq,
            "seq_start": seq_start}


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------


def _sub(sim, text):
    return text + ("  ·  SIMULATED DATA: tests the code only" if sim else "")


def fig_gap(a, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 4.4)
    t = a["decades"]
    x = np.arange(len(t))
    ax.bar(x - 0.2, t["time_weighted"], 0.4, color=plots.INK_3, label="Buy-and-hold (time-weighted)")
    ax.bar(x + 0.2, t["money_weighted"], 0.4, color=plots.BLUE, label="Aggregate investor (money-weighted)")
    ax.axhline(0, color=plots.INK_3, linewidth=0.8)
    ax.set_xticks(x, t["decade"])
    plots.percent_axis(ax)
    ax.set_ylabel("Annualized return")
    ax.grid(axis="x", visible=False)
    ax.set_ylim(min(0, float(t[["time_weighted", "money_weighted"]].min().min()) * 1.2),
                float(t[["time_weighted", "money_weighted"]].max().max()) * 1.35)
    ax.legend(frameon=False, fontsize=8.5, loc="upper left", ncol=2)
    g = a["agg"]
    plots.titles(fig, "Lab Figure 22.1  What the fund earned and what its investors earned",
                 _sub(sim, f"Whole sample: buy-and-hold {g['time_weighted']:.1%}, investors {g['money_weighted']:.1%} "
                           f"a year (gap {g['gap'] * 1e2:+.2f} percentage points)"))
    plots.finish(fig, out / "fig22_1_gap.png")
    plt.close(fig)


def fig_disposition(b, out, sim):
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.4))
    fig.patch.set_facecolor(plots.SURFACE)
    lab = [f"bias {w:g}" for w in b["winner_bias"]]
    x = np.arange(len(b))
    ax = axes[0]
    plots.style_axes(ax)
    ax.bar(x - 0.2, b["PGR"], 0.4, color=plots.BLUE, label="PGR: share of gains realized")
    ax.bar(x + 0.2, b["PLR"], 0.4, color=plots.RED, label="PLR: share of losses realized")
    ax.set_xticks(x, lab)
    plots.percent_axis(ax)
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    ax.set_title("What investors sell", loc="left", fontsize=9.5, color=plots.INK)
    ax = axes[1]
    plots.style_axes(ax)
    ax.bar(x - 0.2, b["winners_sold_next_12m"], 0.4, color=plots.BLUE, label="Winners sold")
    ax.bar(x + 0.2, b["losers_kept_next_12m"], 0.4, color=plots.RED, label="Losers kept")
    top = float(b[["winners_sold_next_12m", "losers_kept_next_12m"]].max().max())
    bot = float(b[["winners_sold_next_12m", "losers_kept_next_12m"]].min().min())
    ax.set_ylim(min(0, bot * 1.3), top * 1.35 if top > 0 else 0.01)
    ax.axhline(0, color=plots.INK_3, linewidth=0.8)
    ax.set_xticks(x, lab)
    plots.percent_axis(ax)
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    ax.set_title("Return over the next 12 months", loc="left", fontsize=9.5, color=plots.INK)
    for a_ in axes:
        a_.grid(axis="x", visible=False)
    plots.titles(fig, "Lab Figure 22.2  Selling winners, holding losers",
                 _sub(sim, "Simulated investors trading the 49 industry portfolios · bias 0: no preference · "
                           "bias 0.9: sell a winner 95% of the time when holding both"))
    plots.finish(fig, out / "fig22_2_disposition.png")
    plt.close(fig)


def fig_turnover(c, out, sim, cost_bp):
    fig, ax, plt = plots.new_figure(9.0, 4.4)
    x = 100 * c["annual_turnover"]
    ax.plot(x, c["gross_return"], marker="o", color=plots.INK_3, linewidth=1.5, label="Before costs")
    ax.plot(x, c["net_return"], marker="o", color=plots.RED, linewidth=1.5, label=f"After {cost_bp:g} bp per trade")
    plots.percent_axis(ax)
    ax.set_xlabel("Annual turnover (% of the portfolio replaced per year)")
    ax.set_ylabel("Annualized return")
    ax.legend(frameon=False, fontsize=8.5)
    plots.titles(fig, "Lab Figure 22.3  The cost of trading more",
                 _sub(sim, "Random portfolios of 10 industries; trades are random, so only costs differ systematically"))
    plots.finish(fig, out / "fig22_3_turnover.png")
    plt.close(fig)


def fig_withdrawal(dd, out, sim):
    import matplotlib.pyplot as plt

    t = dd["table"]
    names = {"fixed_real": "Fixed real amount (Bengen)", "percent": "Fixed % of current wealth",
             "guardrails": "Guardrails (±10% adjustments)"}
    cols = {"fixed_real": plots.INK, "percent": plots.BLUE, "guardrails": plots.GREEN}
    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.4))
    fig.patch.set_facecolor(plots.SURFACE)
    for r, g in t.groupby("rule", sort=False):
        axes[0].plot(100 * g["rate"], g["success_rate"], marker="o", color=cols[r], linewidth=1.6, label=names[r],
                     linestyle="--" if r == "guardrails" else "-")
        axes[1].plot(100 * g["rate"], g["lowest_withdrawal_vs_first"], marker="o", color=cols[r], linewidth=1.6,
                     label=names[r], linestyle="--" if r == "guardrails" else "-")
    axes[0].set_title("Never ran out of money", loc="left", fontsize=9.5, color=plots.INK)
    axes[1].set_title("Lowest yearly spending, relative to the first year", loc="left", fontsize=9.5, color=plots.INK)
    for ax in axes:
        plots.style_axes(ax)
        ax.set_xlabel("Initial withdrawal rate (% of starting wealth)")
        plots.percent_axis(ax)
        ax.set_ylim(0, 1.08)
    axes[0].legend(frameon=False, fontsize=8, loc="lower left")
    plots.titles(fig, "Lab Figure 22.4  How much can a retiree spend?",
                 _sub(sim, "60% stocks, 40% 10-year Treasuries, rebalanced yearly, real returns, every 30-year period "
                           "in the sample · flexible rules never run out but cut spending instead"))
    plots.finish(fig, out / "fig22_4_withdrawal.png")
    plt.close(fig)


def fig_sequence(dd, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 4.4)
    for lab, col in (("historical order", plots.RED), ("reversed order", plots.BLUE)):
        path = dd["seq"][lab]
        ax.plot(np.arange(1, len(path) + 1), path, color=col, linewidth=1.8, label=f"Returns in {lab}")
    ax.axhline(1, color=plots.INK_3, linewidth=0.8, linestyle="--")
    ax.set_xlabel("Years into retirement")
    ax.set_ylabel("Real wealth (start = 1)")
    ax.legend(frameon=False, fontsize=8.5)
    plots.titles(fig, "Lab Figure 22.5  Sequence-of-returns risk",
                 _sub(sim, f"All stocks, 5% real withdrawal, the 30 annual returns starting {dd['seq_start']} in "
                           "historical and reversed order: same average return, different outcome"))
    plots.finish(fig, out / "fig22_5_sequence.png")
    plt.close(fig)


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------


def _md(df, fmt):
    cols = list(df.columns)
    lines = ["| " + " | ".join(str(c) for c in cols) + " |", "| " + " | ".join("---" for _ in cols) + " |"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(fmt[c](r[c]) if c in fmt else str(r[c]) for c in cols) + " |")
    return "\n".join(lines)


def _num(spec):
    return lambda v: "" if (v is None or (isinstance(v, float) and math.isnan(v))) else format(v, spec)


def write_report(out, a, b, c, dd, sim, notes, args):
    pc = _num("+.2%")
    md = ["# Lab 22 results: Do Individual Investors Hurt Themselves?", ""]
    if sim:
        md += ["> **Simulated data.** These results test that the code runs; they say nothing about real markets.", ""]
    if notes:
        md += ["Notes: " + "; ".join(notes), ""]
    md += ["**Claim on trial:** individual investors lose part of the return on their investments through their own "
           "trading behavior.", ""]
    if a:
        g, tm = a["agg"], a["timing"]
        md += ["## Part A: The behavior gap", "",
               f"Over {g['years']:.0f} years: buy-and-hold {g['time_weighted']:.2%} a year, aggregate investor "
               f"{g['money_weighted']:.2%} a year, gap {1e2 * g['gap']:+.2f} percentage points.", "",
               _md(a["decades"], {"time_weighted": pc, "money_weighted": pc, "gap": pc}), "",
               f"Flows on past 12-month return: slope {tm['flow_on_past_return']['slope']:+.4f} "
               f"(t = {tm['flow_on_past_return']['t']:+.2f}). Next 12-month return on this month's flow: slope "
               f"{tm['future_return_on_flow']['slope']:+.3f} (t = {tm['future_return_on_flow']['t']:+.2f}); "
               "Newey–West, 12 lags.", "", "![Lab Figure 22.1](fig22_1_gap.png)", ""]
    md += ["## Part B: The disposition effect", "",
           _md(b, {"winner_bias": _num("g"), "PGR": _num(".3f"), "PLR": _num(".3f"), "PGR_minus_PLR": _num("+.3f"),
                   "winners_sold_next_12m": pc, "losers_kept_next_12m": pc, "sold_winners_minus_kept_losers": pc,
                   "agent_return_annual": pc}), "", "![Lab Figure 22.2](fig22_2_disposition.png)", "",
           f"## Part C: Overtrading ({args.cost_bp:g} bp per trade)", "",
           _md(c, {"annual_turnover": _num(".0%"), "gross_return": pc, "net_return": pc, "cost_drag": pc}), "",
           "![Lab Figure 22.3](fig22_3_turnover.png)", ""]
    if dd:
        md += ["## Part D: Withdrawal rules", "", _md(dd["table"], {"rate": _num(".1%"), "success_rate": _num(".0%"),
                                                                   "median_end_wealth": _num(".2f"),
                                                                   "lowest_withdrawal_vs_first": _num(".2f")}), "",
               "**Worst start years for a 4% fixed real withdrawal (60/40)**", "",
               _md(dd["worst"], {"start_year": lambda v: str(int(v)), "end_wealth_4pct": _num(".2f")}), "", "![Lab Figure 22.4](fig22_4_withdrawal.png)", "",
               "![Lab Figure 22.5](fig22_5_sequence.png)", ""]
    md += ["## Your verdict", "", "1. Did the aggregate investor earn less than the funds, and by how much?",
           "2. What does a preference for selling winners cost when winners keep winning?",
           "3. Which rules would you give an individual investor, and why?", ""]
    (out / "lab22_report.md").write_text("\n".join(md))


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", choices=["files", "sim"], default="files")
    ap.add_argument("--flows-file", help="monthly net flows to equity funds (date, flow[, assets])")
    ap.add_argument("--start-assets", type=float, default=None, help="assets at the start, if the file has none")
    ap.add_argument("--shiller-file", help="Robert Shiller's ie_data.xls (or a CSV export)")
    ap.add_argument("--ff3-file")
    ap.add_argument("--ind49-file")
    ap.add_argument("--cost-bp", type=float, default=50.0, help="cost per trade in Part C (basis points)")
    ap.add_argument("--sim-seed", type=int, default=0)
    ap.add_argument("--out", default=str(ROOT / "report"))
    return ap.parse_args(argv)


def run(args) -> dict:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    try:
        d = load(args)
    except DataUnavailable as err:
        raise SystemExit(str(err)) from None
    sim = d["simulated"]
    a = part_a(d)
    b = part_b(d, seed=args.sim_seed)
    c = part_c(d, args.cost_bp, seed=args.sim_seed)
    dd = part_d(d)
    if a:
        fig_gap(a, out, sim)
        a["decades"].to_csv(out / "table_gap_decades.csv", index=False)
    fig_disposition(b, out, sim)
    fig_turnover(c, out, sim, args.cost_bp)
    if dd:
        fig_withdrawal(dd, out, sim)
        fig_sequence(dd, out, sim)
        dd["table"].to_csv(out / "table_withdrawal.csv", index=False)
        dd["by_start"].to_csv(out / "table_withdrawal_by_start.csv", index=False)
    b.to_csv(out / "table_disposition.csv", index=False)
    c.to_csv(out / "table_turnover.csv", index=False)
    write_report(out, a, b, c, dd, sim, d["notes"], args)
    summary = {"simulated": sim,
               "gap": None if not a else {k: a["agg"][k] for k in ("time_weighted", "money_weighted", "gap")},
               "timing": None if not a else a["timing"], "disposition": b.to_dict(orient="records"),
               "turnover": c.to_dict(orient="records"),
               "withdrawal": None if not dd else dd["table"].to_dict(orient="records")}
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=float))
    if a:
        print(f"Behavior gap: {1e2 * a['agg']['gap']:+.2f} percentage points a year")
    print(b[["winner_bias", "PGR", "PLR", "sold_winners_minus_kept_losers"]].round(3).to_string(index=False))
    print(f"Report: {out / 'lab22_report.md'}")
    if sim:
        print("NOTE: simulated data. These results test the code only.")
    return summary


def main(argv=None):
    return run(parse_args(argv))


if __name__ == "__main__":
    main()
