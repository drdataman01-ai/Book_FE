# Lab 21: Can Language Models Read the News and Earn Returns?

Companion lab for **Chapter 21** of *Financial Engineering and the Evidence: Active Learning by Verifying Famous Claims*.

**Claim on trial:** text-based signals predict stock returns, and large language models extract them best.

## Quick start

```bash
pip install -r requirements.txt
python lab21.py --news-file data/headlines.csv --lm-file data/Loughran-McDonald_MasterDictionary.csv
```

Add a language model (optional):

```bash
export ANTHROPIC_API_KEY=...        # or OPENAI_API_KEY for the openai provider
python lab21.py --news-file data/headlines.csv --lm-file data/LM.csv \
    --llm-provider anthropic --llm-model MODEL_ID --cutoff 2025-03-01 --anonymize-too --max-llm 3000

# a local model through Ollama's OpenAI-compatible endpoint (no key needed)
python lab21.py --news-file ... --llm-provider openai --llm-base-url http://localhost:11434/v1 --llm-model llama3.1
```

Set `--cutoff` to the model's documented training-data cutoff; Part C splits the results there. LLM answers are cached in `data/llm_cache.json`, so a rerun costs nothing. `--max-llm` limits how many (most recent) headlines the model scores; check the provider's prices before raising it. `--finbert` adds FinBERT if `transformers` and `torch` are installed.

### Data

| Input | Where to get it | Option |
|---|---|---|
| Headlines: a CSV with a date or timestamp, a ticker and a headline (column names are detected: `date`/`timestamp`, `ticker`/`stock`/`symbol`, `headline`/`title`; optional `company`) | Any source you are licensed to use. Free examples: Kaggle datasets of dated, ticker-tagged financial headlines (for example "Massive Stock News Analysis DB for NLP/backtests"); RSS archives you collect yourself; company press releases from SEC EDGAR 8-K filings | `--news-file` |
| Daily prices | Downloaded from [Stooq](https://stooq.com) for each ticker (free, no key, US tickers), cached in `data/stooq/`; or your own file (long `date,ticker,ret` or wide) | `--returns-file` |
| Market return, for abnormal returns | French library `F-F_Research_Data_Factors_daily_CSV.zip` (downloaded) | `--ff3d-file` |
| Loughran–McDonald Master Dictionary | [Software Repository for Accounting and Finance](https://sraf.nd.edu/loughranmcdonald-master-dictionary/), University of Notre Dame (free for academic use) | `--lm-file` |

Time stamps with a UTC offset are converted to New York time. A headline without a time is treated as released after the close.

Or open `lab21_walkthrough.ipynb`, which runs the same steps with a prediction prompt before each one.

### Testing the code without real data

```bash
python lab21.py --source sim --cutoff 2021-06-01
```

The simulation writes headlines from a small vocabulary, a fifth of them negated ("fails to deliver: beats estimates"), and builds returns in which part of each piece of news is priced at once, part the next day and part over the following month, with the delayed part shrinking to zero over the sample. Two clearly labelled test doubles stand in for models: an **LLM stand-in** that reads the true sentiment 85% of the time (it is not a language model), and a **leaky scorer** that knows the next month's return before the cutoff. Results on simulated data test the code only.

## What the lab does

**Timing rule.** News before 4 p.m. on a trading day can be traded at that day's close, so day 1 is the next day's close-to-close return. News after the close, without a time, or on a non-trading day can be traded at the next close. Returns on the day the news came out are never counted, because an investor reading the headline could not have earned them.

| Part | Question | Method | Output |
|---|---|---|---|
| A. Dictionaries | Do word lists measure financial tone? | Loughran–McDonald net tone vs a general-purpose list; correlation between scorers; which everyday words the general list mislabels | Tables |
| B. Returns | Does the score predict returns an investor could earn? | Abnormal returns on day 1 and days 2–21 by score sign; daily cross-sectional regressions; daily long–short portfolio (positive news minus negative news, one-day hold) | Lab Figures 21.1–21.2 |
| C. Look-ahead | Has the model read what happened next? | Long–short Sharpe ratio before and after `--cutoff`; named versus anonymized headlines (with `--anonymize-too`) | Lab Figure 21.3 |
| D. Costs and decay | What is left after trading costs, and is it shrinking? | Sharpe ratio net of 0, 5, 10, 20 bp per round trip; year by year | Lab Figures 21.4–21.5 |

### Design notes

- **The general-purpose list** in `fintest/text.py` was written for this lab to make Loughran and McDonald's point visible: it includes everyday words such as *tax*, *cost*, *liability*, *crude* and *capital*. It is not the Harvard General Inquirer.
- **The prompt** follows Lopez-Lira and Tang (YES / NO / UNKNOWN for the stock's short-term price). Anonymization replaces the company name and ticker with "the company" (Glasserman and Lin).
- **Abnormal return** is the stock's return minus the market's, a beta-one adjustment; small stocks' betas differ from one, which matters less at a one-day horizon.
- **Licensing.** News headlines are usually copyrighted. Use data you are licensed to use, and do not redistribute it.

## Verification status

| Part | Status |
|---|---|
| Dictionary scoring and the Loughran–McDonald reader | Tested on a file in the published layout |
| Timing rule | Tested: before the close, after the close, no time, weekend |
| Event returns, long–short portfolio, costs | Tested on hand-built cases |
| LLM answer parsing and anonymization | Tested |
| LLM and FinBERT calls | **Not tested**: no network or model packages in the build environment |
| Full lab and notebook | Run end to end on simulated data |
| Real data | Not run from the build environment (network blocked) |

Run the tests with `python tests/test_lab21.py`.

## Exercises

1. Compare the day-1 abnormal return after positive and negative headlines for the Loughran–McDonald dictionary and the language model. Which is larger, and is the gap driven by negative news?
2. Restrict the sample to headlines published after the model's cutoff. Does the language model still beat the dictionary?
3. Score with and without company names (`--anonymize-too`). For which stocks does anonymization matter most?
4. Hold positions for 5 days instead of 1 (change `hold` in `long_short_daily`). How do returns and costs change?
5. Split the sample by firm size (use the number of headlines per ticker as a crude proxy if you have no market caps). Where is the signal strongest?

## Data citation

Loughran, T., and McDonald, B. (2011). When is a liability not a liability? Textual analysis, dictionaries, and 10-Ks. *Journal of Finance*, 66(1), 35–65; Master Dictionary from the Software Repository for Accounting and Finance, University of Notre Dame.
Kenneth R. French Data Library (Fama/French 3 Factors, daily). Stooq (daily prices).
