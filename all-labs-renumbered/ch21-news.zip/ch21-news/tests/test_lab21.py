"""Tests for Lab 21. Run with:  python tests/test_lab21.py   (or: pytest tests/)

Runs offline: tokenizing and dictionary scores, the Loughran-McDonald reader on a file in the published layout,
the trade-date rule (no trading before the news can be acted on), event returns, the long-short portfolio and
costs, parsing of language-model answers and anonymization, the look-ahead demo, and the full lab on simulated data.
The language-model and FinBERT scorers are not called (no network or model packages in the build environment).
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fintest.text import (Dictionary, LLMScorer, anonymize, assign_trade_date, event_returns,  # noqa: E402
                          long_short_daily, read_lm_dictionary, simulated_news)


def test_dictionary_and_lm_reader():
    d = Dictionary("t", ["beat", "strong"], ["miss", "weak"])
    assert d.score("Company beat estimates on strong demand") == 1
    assert d.score("Miss and weak, but beat") == -1 / 3
    assert d.score("Board meeting today") == 0
    with tempfile.TemporaryDirectory() as tmp:
        f = Path(tmp) / "lm.csv"
        pd.DataFrame({"Word": ["ABANDON", "ACHIEVE", "LIABILITY", "TAX"], "Negative": [2009, 0, 0, 0],
                      "Positive": [0, 2009, 0, 0], "Uncertainty": [0, 0, 0, 0]}).to_csv(f, index=False)
        lm = read_lm_dictionary(f)
        assert lm.neg == {"abandon"} and lm.pos == {"achieve"}
        assert lm.score("tax liability rises") == 0          # neutral in finance


def test_trade_date_rule():
    days = pd.bdate_range("2024-01-01", periods=10)              # Mon 1 Jan .. Fri 12 Jan
    ts = pd.Series(pd.to_datetime(["2024-01-02 09:30", "2024-01-02 17:00", "2024-01-02 00:00", "2024-01-06 10:00"]))
    first = assign_trade_date(ts, days).dt.strftime("%Y-%m-%d").tolist()
    # before the close: trade at Tuesday's close, first return Wednesday; after the close or no time: Thursday;
    # Saturday news: trade at Monday's close, first return Tuesday
    assert first == ["2024-01-03", "2024-01-04", "2024-01-04", "2024-01-09"]


def test_event_returns_and_long_short():
    days = pd.bdate_range("2024-01-01", periods=40)
    ret = pd.DataFrame(0.0, index=days, columns=["A", "B"])
    ret.loc[days[5], "A"] = 0.02
    ret.loc[days[5], "B"] = -0.01
    ev = pd.DataFrame({"ticker": ["A", "B"], "first_day": [days[5], days[5]], "s": [1.0, -1.0]})
    car = event_returns(ev, ret)
    assert np.allclose(car["car_1_1"], [0.02, -0.01])
    assert np.allclose(car["car_2_21"], 0.0)
    ls = long_short_daily(ev, "s", ret)
    assert len(ls) == 1 and abs(ls["ls"].iloc[0] - 0.03) < 1e-12
    ls_c = long_short_daily(ev, "s", ret, cost_bp=10)
    assert ls_c["ls"].iloc[0] < ls["ls"].iloc[0]


def test_llm_parsing_and_anonymize():
    assert LLMScorer.parse("YES\nGood news.") == 1 and LLMScorer.parse("NO - bad") == -1
    assert LLMScorer.parse("UNKNOWN") == 0 and LLMScorer.parse("Maybe") == 0
    assert anonymize("Apple (AAPL) beats estimates", "Apple", "AAPL") == "the company (the company) beats estimates"


def test_simulation_and_leaky_demo():
    import lab21

    with tempfile.TemporaryDirectory() as tmp:
        s = lab21.main(["--source", "sim", "--cutoff", "2021-06-01", "--out", tmp])
        assert len(list(Path(tmp).glob("fig21_*.png"))) == 5
        rep = (Path(tmp) / "lab21_report.md").read_text()
        assert "Simulated data" in rep and "Your verdict" in rep
        r = {x["scorer"]: x for x in s["returns"]}
        fin, gen = "Finance word list (simulation)", "General-purpose list"
        llm = "LLM stand-in (simulation; not a language model)"
        assert r[llm]["ls_sharpe"] > r[fin]["ls_sharpe"] > r[gen]["ls_sharpe"]   # negation hurts word lists
        c = pd.DataFrame(s["cutoff"]).set_index(["scorer", "window"])["ls_sharpe"]
        leak = lab21.LEAKY
        assert c[(leak, "before cutoff")] > 2 * c[(leak, "after cutoff")]


def test_simulated_news_shape():
    d = simulated_news(n_tickers=20, n_days=200, per_day=5)
    assert {"timestamp", "ticker", "headline", "true_sentiment"} <= set(d["news"].columns)
    assert d["abret"].shape == (200, 20)


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print(f"ok  {name}")
