"""Tests for Lab 7. Run with:  python tests/test_lab07.py   (or: pytest tests/)

Runs offline. CAPE and the Fed-model spread are checked against direct
calculations on a file in the Goyal-Welch layout, the Shiller reader on a
sheet in Shiller's layout, the long-horizon target and the bootstrap for
correct behavior under the null, and the full lab on simulated data.
"""

from __future__ import annotations

import math
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fintest.predictors import build_predictors, cape_from_index, parse_goyal_welch  # noqa: E402
from fintest.shiller import parse_shiller_csv_text, real_returns  # noqa: E402


def _gw_raw(n=150, seed=0):
    rng = np.random.default_rng(seed)
    ym = [(1920 + (i // 12)) * 100 + i % 12 + 1 for i in range(n)]
    idx = 100 * np.cumprod(1 + rng.normal(0.006, 0.04, n))
    df = pd.DataFrame({"yyyymm": ym, "Index": idx, "D12": idx * 0.04, "E12": idx * rng.uniform(0.05, 0.09, n),
                       "b/m": 0.6, "tbl": 0.03, "AAA": 0.04, "BAA": 0.05, "lty": 0.035, "ntis": 0.01,
                       "Rfree": 0.0025, "infl": rng.normal(0.002, 0.003, n), "ltr": 0.003, "corpr": 0.004,
                       "svar": 0.002, "CRSP_SPvw": rng.normal(0.008, 0.04, n)})
    return df


def test_cape_and_fed_spread_match_direct_calculation():
    raw = parse_goyal_welch(_gw_raw())
    p = build_predictors(raw)
    t = 140
    cpi = np.cumprod(1 + raw["infl"].to_numpy())
    real_e = raw["e12"].to_numpy() / cpi
    direct = (raw["index"].to_numpy()[t] / cpi[t]) / real_e[t - 119:t + 1].mean()
    assert abs(p["cape"].iloc[t] - direct) < 1e-10
    assert p["cape"].iloc[:119].isna().all() and np.isfinite(p["cape"].iloc[119])
    assert abs(p["fedspread"].iloc[t] - (raw["e12"].iloc[t] / raw["index"].iloc[t] - raw["lty"].iloc[t])) < 1e-12
    assert abs(p["infl_now"].iloc[t] - raw["infl"].iloc[t]) < 1e-15  # not lagged, unlike "infl"


def test_cape_waits_for_inflation_data():
    price = pd.Series(np.linspace(10, 20, 300))
    e = pd.Series(np.full(300, 1.0))
    infl = pd.Series([np.nan] * 50 + [0.0] * 250)
    c = cape_from_index(price, e, infl)
    assert c.iloc[:169].isna().all() and abs(c.iloc[200] - price.iloc[200]) < 1e-12


SHILLER_SAMPLE = """,,,,,,,,,,,,,
Stock Market Data Used in "Irrational Exuberance",,,,,,,,,,,,,
,,,,,,,,,,,,,
Date,P,D,E,CPI,Date Fraction,Rate GS10,Real Price,Real Dividend,Real Total Return Price,Real Earnings,Real TR Scaled Earnings,CAPE,
1871.01,4.44,0.26,0.4,12.46,1871.04,5.32,100,5.8,100,9,9,NA,
1871.02,4.5,0.26,0.4,12.84,1871.13,5.32,99,5.7,99.5,8.8,8.8,NA,
1871.1,4.6,0.26,0.4,12.5,1871.79,5.32,103,5.8,105,8.9,8.9,15.2,
1871.11,4.7,0.26,0.4,12.5,1871.88,5.32,105,5.8,107,8.9,8.9,15.6,
"""


def test_shiller_reader_layout():
    s = parse_shiller_csv_text(SHILLER_SAMPLE)
    assert [str(i) for i in s.index] == ["1871-01", "1871-02", "1871-10", "1871-11"]
    assert abs(s.loc["1871-10", "cape"] - 15.2) < 1e-12 and np.isnan(s.loc["1871-01", "cape"])
    r = real_returns(s)
    assert abs(r.loc["1871-02"] - math.log(99.5 / 100)) < 1e-12


def test_target_sums_future_returns():
    import lab07

    r = np.arange(1.0, 11.0)
    z = lab07._target(r, 3)
    assert z[0] == 2 + 3 + 4 and np.isnan(z[-3:]).all()


def test_bootstrap_size_and_stambaugh_sign():
    import lab07
    from fintest.inference import ar1_predictors, long_horizon_tstats

    rng = np.random.default_rng(1)
    T = 600
    e = rng.standard_normal(T)
    x = ar1_predictors(T, 1, 0.98, rng, shocks=e, rho=-0.9)[:, 0]
    r = 0.005 + 0.04 * e  # no predictability
    ts = lab07.stambaugh_bootstrap(r, x, 12, n_boot=200, seed=2)
    assert ts.mean() > 0.2  # the Stambaugh bias pushes t-statistics up when rho < 0
    assert np.quantile(ts, 0.95) > 1.645
    # Under the null, the actual t should rarely exceed the bootstrap 95% point.
    exceed = 0
    for s in range(30):
        g = np.random.default_rng(100 + s)
        ee = g.standard_normal(T)
        xx = ar1_predictors(T, 1, 0.98, g, shocks=ee, rho=-0.9)[:, 0]
        rr = 0.005 + 0.04 * ee
        t_act = long_horizon_tstats(rr, xx, 12, nw_lags=11)["t_newey_west"][0]
        tb = lab07.stambaugh_bootstrap(rr, xx, 12, n_boot=100, seed=s)
        exceed += t_act > np.quantile(tb, 0.95)
    assert exceed <= 5


def test_part_d_range_brackets_point():
    import lab07

    df = lab07.load("sim")
    d = lab07.part_d(df)
    lo, hi = d["range_now"]
    assert lo < d["point_now"] < hi and d["slope"] < 0 and d["rmse_model"] > 0


def test_part_d_with_shiller_data():
    import lab07

    n, rng = 1600, np.random.default_rng(0)
    idx = pd.period_range("1881-01", periods=n, freq="M")
    cape = np.exp(np.log(16) + np.cumsum(rng.normal(0, 0.03, n)) * 0.3)
    r = 0.005 - 0.02 * (np.log(cape) - np.log(16)) / 12 + rng.normal(0, 0.04, n)
    sh = pd.DataFrame({"price": 1.0, "dividend": 0.04, "earnings": 0.06, "cpi": 1.0, "cape": cape,
                       "real_tr_price": np.exp(np.cumsum(r))}, index=idx)
    d = lab07.part_d(lab07.load("sim"), sh)
    assert d["source"] == "Shiller" and d["sample"][0].startswith("1881") and d["slope"] < 0


def test_full_lab_runs_on_simulated_data():
    import lab07

    with tempfile.TemporaryDirectory() as tmp:
        summary = lab07.main(["--source", "sim", "--n-boot", "40", "--out", tmp])
        out = Path(tmp)
        assert len(list(out.glob("fig7_*.png"))) == 5
        report = (out / "lab07_report.md").read_text()
        assert "Simulated data" in report and "Your verdict" in report
        oos = pd.DataFrame(summary["out_of_sample"])
        assert set(oos["horizon"]) == {1, 12, 120}
        r = oos.set_index(["predictor", "horizon"])["r2_oos"]
        assert r[("dp", 12)] > r[("tms", 12)]  # in the simulation only dp has power


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print(f"ok  {name}")
