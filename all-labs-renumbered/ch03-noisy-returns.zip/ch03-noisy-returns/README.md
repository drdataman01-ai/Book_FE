# Lab 3: How Reliable Is a t-Statistic?

Companion lab for **Chapter 3** of *Financial Engineering and the Evidence: Active Learning by Verifying Famous Claims*.

**Claim on trial:** standard regression statistics are reliable for financial returns.

## Quick start

```bash
pip install -r requirements.txt
python lab03.py
```

The first run downloads three files from the Kenneth R. French Data Library and caches them in `data/`. The lab then runs in under a minute. Open `report/lab03_report.md` for the results.

For a guided version, open `lab03_walkthrough.ipynb` in Jupyter. It asks you to predict each result before you see it.

### If the download fails

Download these CSV files from the [Kenneth R. French Data Library](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html) and save them in `data/`, or pass them directly:

| Library page title | File |
|---|---|
| Fama/French 3 Factors | `F-F_Research_Data_Factors_CSV.zip` |
| Fama/French 3 Factors [Daily] | `F-F_Research_Data_Factors_daily_CSV.zip` |
| 25 Portfolios Formed on Size and Book-to-Market (5 x 5) | `25_Portfolios_5x5_CSV.zip` |

```bash
python lab03.py --monthly-file F-F_Research_Data_Factors_CSV.zip \
                --daily-file F-F_Research_Data_Factors_daily_CSV.zip \
                --portfolios-file 25_Portfolios_5x5_CSV.zip
```

### Testing the code without real data

```bash
python lab03.py --source sim
```

**Results from simulated data are not evidence about markets;** the report and figures are labeled. The lab never switches to simulated data on its own.

## What the lab does

| Part | Question | Method | Output |
|---|---|---|---|
| A. Stylized facts | How far are returns from textbook data? | Moments, tail counts and autocorrelations of daily and monthly market returns | Lab Figures 3.1–3.2 |
| B. Four standard errors | Does the choice of standard error change conclusions about alphas? | CAPM and three-factor alphas of the 25 size/book-to-market portfolios, with classical, White, Newey–West and stationary-bootstrap errors; GRS test | Lab Figure 3.3 |
| C. Overlapping regressions | How often do overlapping regressions find predictability that is not there? | Real monthly market returns paired with 1,000 simulated AR(1) predictors with no predictive power; rejection rates for classical, Newey–West and Hodrick (1992) t-statistics at horizons of 1–60 months | Lab Figure 3.4 |
| D. Fama–MacBeth | What price does the cross-section put on market, size and value exposure? | Two-pass regressions with Fama–MacBeth and Shanken-corrected errors | Tables |
| E. Economic significance | How large are the alphas, and how sure are we? | Alphas in % per year with 95% bootstrap intervals | Lab Figure 3.5 |

### Design notes

- **Sample.** Parts B, D and E start in July 1963 by default, the period used by Fama and French (1993) and much later work; use `--start 1926-07` for the full sample. Parts A and C use the full sample.
- **Newey–West lags.** By default Part B uses the rule of thumb floor(4(T/100)^(2/9)); Part C uses lags equal to the horizon k.
- **Bootstrap.** Stationary bootstrap (Politis and Romano 1994) with a mean block length of 12 months, resampling portfolio and factor returns together; 2,000 draws.
- **Hodrick (1992) 1B errors** are computed under the null of no predictability, which is how they are used to test it.
- **Fama–MacBeth** uses full-sample betas, a common simplification for portfolios.
- **GRS** uses maximum-likelihood covariance estimates and the F distribution, so `scipy` is required.

## Options

```text
--source {french,sim}     real data (default) or simulated data for testing
--monthly-file / --daily-file / --portfolios-file PATH
--start YYYY-MM           first month for Parts B, D, E (default 1963-07)
--end YYYY-MM             last month for Parts B, D, E (default: latest)
--nw-lags N               Newey–West lags in Part B (default: rule of thumb)
--n-boot N                bootstrap draws (default 2000)
--block B                 mean bootstrap block length in months (default 12)
--n-sims N                Part C: number of useless predictors (default 1000)
--phi P                   Part C: predictor autocorrelation (default 0.98)
--rho R                   Part C: correlation of predictor and return shocks (default 0)
--seed N                  random seed (default 2026)
--out DIR                 output folder (default report/)
```

## Outputs (`report/`)

- `lab03_report.md`: all results, with a "Your verdict" prompt
- `fig3_1_autocorrelation.png` to `fig3_5_alpha_intervals.png`
- `table_*.csv`: moments, tails, autocorrelations, alphas for each model, overlap results, Fama–MacBeth premia
- `summary.json`: headline numbers for grading or automated checks

## Files

```text
ch03-noisy-returns/
├── README.md
├── requirements.txt
├── lab03.py                 # the lab: data, parts A–E, figures, report
├── lab03_walkthrough.ipynb  # guided, step-by-step version
├── fintest/                 # the book's analysis module (Labs 1–3 subset)
│   ├── data.py              # French library download and parsing
│   ├── stats.py             # returns, Sharpe ratios, Newey–West
│   ├── inference.py         # stylized facts, standard errors, bootstrap, GRS, Fama–MacBeth, Hodrick
│   └── plots.py             # chart style
├── data/                    # downloaded files are cached here
└── tests/test_lab03.py      # runs offline
```

Run the tests with `python tests/test_lab03.py` (or `pytest tests/`).

## Verification status

| Part | Status |
|---|---|
| Classical, White and Newey–West errors | Tested against direct matrix calculations |
| GRS test | Tested against the formula computed directly, and for correct size under the null |
| Fama–MacBeth | Tested: recovers a known premium in simulated data; Shanken errors exceed uncorrected ones |
| Hodrick (1992) and long-horizon t-statistics | Tested against a loop-based calculation; overlap inflates classical rejections as expected |
| Stationary bootstrap | Tested: mean block length matches its setting |
| Full lab and notebook | Run end to end on simulated data |
| French library parsers | Tested on files in the library's published layouts; **confirm on the live files at first run** |
| Live download | Not tested from the build environment (network blocked); the error message explains the manual route |

## Exercises

1. Part C: re-run with `--rho -0.9`, roughly the correlation between dividend-yield shocks and return shocks. What happens to the average slope (Stambaugh bias) and to the rejection rates?
2. Part C: re-run with `--phi 0.9` and `--phi 0.995`. How does predictor persistence affect false discoveries?
3. Part B: re-run with `--start 1926-07`, and then with `--nw-lags 12`. Which conclusions change?
4. Part B: implement a bootstrap version of the GRS test by resampling under the null (subtract each portfolio's estimated alpha before resampling). Compare its p-value with the F-based one.
5. Part D: estimate betas on rolling 60-month windows instead of the full sample. How do the premia change?

## Data citation

Kenneth R. French Data Library: Fama/French 3 Factors (monthly and daily); 25 Portfolios Formed on Size and Book-to-Market (5 x 5). https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html
