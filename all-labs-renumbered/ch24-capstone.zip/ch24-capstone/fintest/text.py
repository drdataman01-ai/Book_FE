"""Text as data for return prediction (Chapter 21).

* tokenize, Dictionary, read_lm_dictionary - word-list tone scores, including the Loughran-McDonald (2011) finance
  dictionary read from its public master file
* GENERAL_LISTS - a small general-purpose word list written for this lab (not the Harvard dictionary) to show how
  everyday words such as "liability", "tax" or "cost" mislabel financial text
* LLMScorer - asks a language model whether a headline is good or bad news for the stock (Lopez-Lira and Tang),
  through the Anthropic Messages API or any OpenAI-compatible endpoint (OpenAI, a local Ollama server); results are
  cached on disk; optional anonymization of the company name (Glasserman and Lin)
* FinBERTScorer - optional, through the `transformers` package
* assign_trade_date, event_returns, long_short_daily, daily_cross_section - event-study and portfolio tests
* simulated_news - fake headlines and returns with known sentiment, negation and decay. TESTING ONLY.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
from pathlib import Path

import numpy as np
import pandas as pd

TOKEN = re.compile(r"[a-z]+(?:'[a-z]+)?")
NEGATORS = {"not", "no", "never", "fails", "failed", "fail", "without", "misses"}


def tokenize(text: str) -> list[str]:
    return TOKEN.findall(str(text).lower())


class Dictionary:
    """Tone = (positive - negative) / (positive + negative), 0 when neither occurs."""

    def __init__(self, name: str, positive, negative):
        self.name, self.pos, self.neg = name, set(positive), set(negative)

    def counts(self, text: str) -> tuple[int, int, int]:
        toks = tokenize(text)
        return sum(t in self.pos for t in toks), sum(t in self.neg for t in toks), len(toks)

    def score(self, text: str) -> float:
        p, n, _ = self.counts(text)
        return 0.0 if p + n == 0 else (p - n) / (p + n)

    def score_many(self, texts) -> np.ndarray:
        return np.array([self.score(t) for t in texts])


def read_lm_dictionary(path) -> Dictionary:
    """The Loughran-McDonald master dictionary CSV (Software Repository for Accounting and Finance, University of
    Notre Dame). A word belongs to a list when its 'Negative' or 'Positive' column is non-zero."""
    df = pd.read_csv(path)
    cols = {c.lower().strip(): c for c in df.columns}
    w, neg, pos = cols["word"], cols["negative"], cols["positive"]
    words = df[w].astype(str).str.lower()
    return Dictionary("Loughran–McDonald", words[df[pos] != 0], words[df[neg] != 0])


# A small general-purpose list written for this lab. It deliberately contains everyday words that a general
# dictionary treats as emotional but that are neutral in financial text (tax, cost, liability, crude, capital ...).
GENERAL_LISTS = {
    "positive": ["good", "great", "happy", "win", "wins", "gain", "gains", "strong", "success", "best", "improve",
                 "improves", "rise", "rises", "beat", "beats", "up", "record", "growth", "upgrade", "share", "shares",
                 "interest", "capital", "board"],
    "negative": ["bad", "loss", "losses", "weak", "fall", "falls", "drop", "drops", "miss", "misses", "cut", "cuts",
                 "decline", "declines", "risk", "risks", "tax", "cost", "costs", "liability", "liabilities", "crude",
                 "vice", "mine", "cancer", "charge", "charges", "expense", "expenses", "foreign", "against"],
}


def general_dictionary() -> Dictionary:
    return Dictionary("General-purpose list", GENERAL_LISTS["positive"], GENERAL_LISTS["negative"])


def misclassification(general: Dictionary, finance: Dictionary, texts) -> pd.DataFrame:
    """Words the general list calls negative or positive that the finance dictionary does not, ranked by how often
    they occur in the corpus."""
    from collections import Counter

    c = Counter(t for x in texts for t in tokenize(x))
    rows = []
    for side, gen, fin in (("negative", general.neg, finance.neg), ("positive", general.pos, finance.pos)):
        for w in gen:
            if c[w] and w not in fin:
                rows.append({"general_list": side, "word": w, "occurrences": c[w]})
    return pd.DataFrame(rows).sort_values("occurrences", ascending=False) if rows else \
        pd.DataFrame(columns=["general_list", "word", "occurrences"])


# ---------------------------------------------------------------------------
# Language-model scorers (optional)
# ---------------------------------------------------------------------------


PROMPT = ("Forget all your previous instructions. Pretend you are a financial expert with stock recommendation "
          "experience. Answer YES if good news, NO if bad news, or UNKNOWN if uncertain in the first line. Then "
          "elaborate with one short and concise sentence on the next line. Is this headline good or bad for the stock "
          "price of {company} in the short term?\n\nHeadline: {headline}")


def anonymize(headline: str, company: str | None, ticker: str | None) -> str:
    out = headline
    for name in [company, ticker]:
        if name:
            out = re.sub(re.escape(str(name)), "the company", out, flags=re.IGNORECASE)
    return out


class LLMScorer:
    """Scores headlines +1 (YES), -1 (NO) or 0 (UNKNOWN) with a language model, following Lopez-Lira and Tang's
    prompt. provider='anthropic' uses the Messages API (ANTHROPIC_API_KEY); provider='openai' uses any
    OpenAI-compatible chat endpoint (OPENAI_API_KEY, base_url for e.g. a local Ollama server at
    http://localhost:11434/v1). Every answer is cached in `cache` so reruns cost nothing. NOT TESTED against the
    live services in the build environment."""

    def __init__(self, provider: str, model: str, cache: Path, base_url: str | None = None, anonymize: bool = False,
                 timeout: int = 60):
        import requests  # noqa: F401  (checked early)

        self.provider, self.model, self.base_url, self.anon, self.timeout = provider, model, base_url, anonymize, timeout
        self.name = f"LLM: {model}" + (" (anonymized)" if anonymize else "")
        self.cache_path = Path(cache)
        self.cache = json.loads(self.cache_path.read_text()) if self.cache_path.exists() else {}
        key_env = "ANTHROPIC_API_KEY" if provider == "anthropic" else "OPENAI_API_KEY"
        self.key = os.environ.get(key_env, "")
        if provider == "anthropic" and not self.key:
            raise RuntimeError(f"Set {key_env} to use the Anthropic provider.")

    def _ask(self, prompt: str) -> str:
        import requests

        if self.provider == "anthropic":
            r = requests.post("https://api.anthropic.com/v1/messages", timeout=self.timeout,
                              headers={"x-api-key": self.key, "anthropic-version": "2023-06-01",
                                       "content-type": "application/json"},
                              json={"model": self.model, "max_tokens": 60, "temperature": 0,
                                    "messages": [{"role": "user", "content": prompt}]})
            r.raise_for_status()
            return "".join(b.get("text", "") for b in r.json()["content"])
        url = (self.base_url or "https://api.openai.com/v1").rstrip("/") + "/chat/completions"
        r = requests.post(url, timeout=self.timeout, headers={"Authorization": f"Bearer {self.key}"},
                          json={"model": self.model, "temperature": 0, "max_tokens": 60,
                                "messages": [{"role": "user", "content": prompt}]})
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]

    @staticmethod
    def parse(answer: str) -> float:
        first = answer.strip().split("\n")[0].upper()
        if first.startswith("YES"):
            return 1.0
        if first.startswith("NO"):
            return -1.0
        return 0.0

    def score_many(self, headlines, companies=None, tickers=None, save_every: int = 50) -> np.ndarray:
        out = []
        companies = companies if companies is not None else [None] * len(headlines)
        tickers = tickers if tickers is not None else [None] * len(headlines)
        for i, (h, c, t) in enumerate(zip(headlines, companies, tickers)):
            text = anonymize(h, c, t) if self.anon else h
            who = "the company" if self.anon else (c or t or "the company")
            prompt = PROMPT.format(company=who, headline=text)
            k = hashlib.sha1(f"{self.provider}|{self.model}|{prompt}".encode()).hexdigest()
            if k not in self.cache:
                try:
                    self.cache[k] = self._ask(prompt)
                except Exception as e:  # noqa: BLE001
                    self.cache[k] = f"ERROR {e}"
                if i % save_every == 0:
                    self.cache_path.write_text(json.dumps(self.cache))
            out.append(self.parse(self.cache[k]) if not self.cache[k].startswith("ERROR") else np.nan)
        self.cache_path.write_text(json.dumps(self.cache))
        return np.array(out)


class FinBERTScorer:
    """FinBERT (ProsusAI/finbert) through `transformers`: P(positive) - P(negative). Optional."""

    name = "FinBERT"

    def __init__(self, model_id: str = "ProsusAI/finbert"):
        from transformers import pipeline

        self.pipe = pipeline("text-classification", model=model_id, top_k=None, truncation=True)

    def score_many(self, texts, batch: int = 32) -> np.ndarray:
        out = []
        for i in range(0, len(texts), batch):
            for res in self.pipe(list(texts[i:i + batch])):
                d = {r["label"].lower(): r["score"] for r in res}
                out.append(d.get("positive", 0) - d.get("negative", 0))
        return np.array(out)


# ---------------------------------------------------------------------------
# Return tests
# ---------------------------------------------------------------------------


def assign_trade_date(ts: pd.Series, trading_days: pd.DatetimeIndex, close_hour: int = 16) -> pd.Series:
    """The first trading day whose close-to-close return an investor can earn by trading on the news at a close.
    News on a trading day before the close is tradable at that close, so its first return is the next trading day.
    News after the close, or with no time stamp (treated conservatively as after the close), is tradable at the next
    close, so its first return is two trading days later. News on a non-trading day is tradable at the next close."""
    ts = pd.to_datetime(pd.Series(ts))
    has_time = ((ts.dt.hour + ts.dt.minute) > 0).to_numpy()
    before_close = has_time & (ts.dt.hour.to_numpy() < close_hour)
    day = ts.dt.normalize().to_numpy()
    p = trading_days.searchsorted(day, side="left")
    pc = np.minimum(p, len(trading_days) - 1)
    on_trading_day = trading_days[pc].to_numpy() == day
    first = np.where(on_trading_day, np.where(before_close, p + 1, p + 2), p + 1)
    first = np.minimum(first, len(trading_days) - 1)
    return pd.Series(trading_days[first], index=ts.index)


def event_returns(events: pd.DataFrame, ret: pd.DataFrame, windows=((1, 1), (2, 21))) -> pd.DataFrame:
    """For each event (columns ticker, first_day), cumulative abnormal return over trading-day windows counted from
    first_day = day 1. `ret` is a wide DataFrame of daily abnormal returns (dates x tickers)."""
    days = ret.index
    out = {f"car_{a}_{b}": np.full(len(events), np.nan) for a, b in windows}
    cols = {c: i for i, c in enumerate(ret.columns)}
    R = ret.to_numpy()
    lr = np.log1p(np.nan_to_num(R, nan=0.0))
    cum = np.vstack([np.zeros(R.shape[1]), np.cumsum(lr, axis=0)])
    pos = days.searchsorted(pd.to_datetime(events["first_day"]).to_numpy())
    for k, (tk, p) in enumerate(zip(events["ticker"], pos)):
        j = cols.get(tk)
        if j is None:
            continue
        for a, b in windows:
            s, e = p + a - 1, p + b
            if e <= R.shape[0] and np.isfinite(R[s, j]):
                out[f"car_{a}_{b}"][k] = math.expm1(cum[e, j] - cum[s, j])
    return pd.DataFrame(out, index=events.index)


def long_short_daily(events: pd.DataFrame, score: str, ret: pd.DataFrame, hold: int = 1,
                     cost_bp: float = 0.0) -> pd.DataFrame:
    """Each trading day, buy (equal weight) stocks whose news scored positive and sell those that scored negative,
    from the first tradable day, holding for `hold` days. Returns daily long, short and long-short returns net of
    `cost_bp` per round trip (buying and later selling a position costs cost_bp in total, as in Lopez-Lira and Tang),
    and turnover (sum of absolute weight changes in a book of 1 long and 1 short; replacing the whole book is 4)."""
    days = ret.index
    pos = days.searchsorted(pd.to_datetime(events["first_day"]).to_numpy())
    s = events[score].to_numpy()
    W_l = np.zeros(ret.shape)
    W_s = np.zeros(ret.shape)
    cols = {c: i for i, c in enumerate(ret.columns)}
    for p, tk, v in zip(pos, events["ticker"], s):
        j = cols.get(tk)
        if j is None or not np.isfinite(v) or v == 0 or p >= len(days):
            continue
        target = W_l if v > 0 else W_s
        target[p:min(p + hold, len(days)), j] = 1.0
    R = np.nan_to_num(ret.to_numpy(), nan=0.0)
    nl, ns = W_l.sum(1), W_s.sum(1)
    long = np.where(nl > 0, (W_l * R).sum(1) / np.maximum(nl, 1), np.nan)
    short = np.where(ns > 0, (W_s * R).sum(1) / np.maximum(ns, 1), np.nan)
    ls = long - short
    # turnover: each day, positions entering and leaving, as a share of a book of 1 long + 1 short
    wl = W_l / np.maximum(nl, 1)[:, None]
    ws = W_s / np.maximum(ns, 1)[:, None]
    to = np.r_[0, np.abs(np.diff(wl, axis=0)).sum(1) + np.abs(np.diff(ws, axis=0)).sum(1)]
    out = pd.DataFrame({"long": long, "short": short, "ls": ls - cost_bp / 2 / 1e4 * to, "turnover": to,
                        "n_long": nl, "n_short": ns}, index=days)
    return out[(nl > 0) & (ns > 0)]


def ls_stats(ls: pd.DataFrame, periods: int = 252) -> dict:
    x = ls["ls"].dropna().to_numpy()
    if len(x) < 20:
        return {"mean_daily_bp": np.nan, "t": np.nan, "sharpe": np.nan, "days": len(x)}
    m, sd = x.mean(), x.std(ddof=1)
    return {"mean_daily_bp": 1e4 * m, "t": m / (sd / math.sqrt(len(x))), "sharpe": m / sd * math.sqrt(periods),
            "days": len(x)}


def daily_cross_section(events: pd.DataFrame, score: str, target: str) -> dict:
    """Fama-MacBeth style: each trading day with at least 5 events, regress the event return on the score; report the
    average slope and its t-statistic."""
    slopes = []
    for _, g in events.dropna(subset=[score, target]).groupby("first_day"):
        if len(g) >= 5 and g[score].std() > 0:
            slopes.append(np.polyfit(g[score], g[target], 1)[0])
    s = np.array(slopes)
    if len(s) < 20:
        return {"slope": np.nan, "t": np.nan, "days": len(s)}
    return {"slope": float(s.mean()), "t": float(s.mean() / (s.std(ddof=1) / math.sqrt(len(s)))), "days": len(s)}


# ---------------------------------------------------------------------------
# Simulation
# ---------------------------------------------------------------------------


_SIM_POS = ["beats estimates", "raises guidance", "wins contract", "record revenue", "upgrade", "strong demand",
            "dividend increase", "approval granted", "expands margins", "buyback announced"]
_SIM_NEG = ["misses estimates", "cuts guidance", "loses contract", "revenue decline", "downgrade", "weak demand",
            "dividend cut", "recall announced", "margin pressure", "probe opened"]
_SIM_NEUTRAL = ["tax filing", "board meeting", "capital structure update", "liability insurance renewal",
                "crude oil costs discussed", "foreign office opening", "annual report released", "share class change"]


def simulated_news(n_tickers: int = 200, n_days: int = 1500, per_day: int = 15, seed: int = 0,
                   start: str = "2018-01-02", decay_start: float = 0.6) -> dict:
    """Fake headlines and daily abnormal returns. Each headline has a true sentiment (+1, -1 or 0). About a fifth of
    positive and negative headlines are negated ("fails to beat estimates"), which word lists misread. Part of the news
    is priced on the event day, part on the next day and part drifts over the next month; the delayed share shrinks
    linearly to zero by the end of the sample, imitating adoption. Includes a lab-written finance word list matched
    to the simulated vocabulary. TESTING ONLY."""
    rng = np.random.default_rng(seed)
    days = pd.bdate_range(start, periods=n_days)
    tickers = [f"T{i:03d}" for i in range(n_tickers)]
    rows = []
    for d_i, d in enumerate(days[:-25]):
        for _ in range(rng.poisson(per_day)):
            s = rng.choice([1, -1, 0], p=[0.35, 0.35, 0.30])
            tk = tickers[rng.integers(n_tickers)]
            if s == 0:
                text = rng.choice(_SIM_NEUTRAL)
            else:
                phrase = rng.choice(_SIM_POS if s > 0 else _SIM_NEG)
                if rng.random() < 0.2:          # negation flips the meaning
                    s = -s
                    phrase = "fails to deliver: " + phrase if s < 0 else "no longer faces " + phrase
                text = phrase
            hour = int(rng.choice([8, 12, 17, 0]))
            rows.append({"timestamp": d + pd.Timedelta(hours=hour), "ticker": tk, "company": f"Company {tk}",
                         "headline": f"Company {tk} {text}", "true_sentiment": s, "day_index": d_i})
    news = pd.DataFrame(rows)
    R = 0.018 * rng.standard_t(4, (n_days, n_tickers)) / math.sqrt(2)
    size = 0.007
    for _, r in news.iterrows():
        j = int(r.ticker[1:])
        d_i = r.day_index
        frac = decay_start * (1 - d_i / n_days)                     # share not priced at once
        after_close = r.timestamp.hour >= 16 or r.timestamp.hour == 0
        first = d_i + (1 if after_close else 0)
        R[first, j] += size * r.true_sentiment * (1 - frac)
        R[first + 1, j] += size * r.true_sentiment * frac * 0.6
        R[first + 2:first + 22, j] += size * r.true_sentiment * frac * 0.4 / 20
    ret = pd.DataFrame(R, index=days, columns=tickers)
    lex = Dictionary("Finance word list (simulation)",
                     ["beats", "raises", "wins", "record", "upgrade", "strong", "increase", "approval", "expands",
                      "buyback"],
                     ["misses", "cuts", "loses", "decline", "downgrade", "weak", "cut", "recall", "pressure", "probe"])
    return {"news": news.drop(columns=["day_index"]), "abret": ret, "dictionary": lex, "simulated": True}


def simulated_llm_scores(news: pd.DataFrame, accuracy: float = 0.85, seed: int = 1) -> np.ndarray:
    """TEST DOUBLE, NOT A LANGUAGE MODEL: reads the true sentiment correctly with probability `accuracy`, otherwise
    answers UNKNOWN. It stands in for an LLM that handles negation."""
    rng = np.random.default_rng(seed)
    s = news["true_sentiment"].to_numpy().astype(float)
    return np.where(rng.random(len(s)) < accuracy, s, 0.0)


def leaky_scores(news: pd.DataFrame, ret: pd.DataFrame, cutoff: str, fallback=None) -> np.ndarray:
    """DEMONSTRATION OF LOOK-AHEAD, NOT A MODEL: before `cutoff` it 'remembers' the sign of the stock's next-month
    return; after it, it falls back to `fallback` scores (zero if none), as a model would once past its training
    data."""
    c = pd.Timestamp(cutoff)
    days = ret.index
    out = np.zeros(len(news)) if fallback is None else np.asarray(fallback, float).copy()
    for k, (ts, tk) in enumerate(zip(pd.to_datetime(news["timestamp"]), news["ticker"])):
        if ts >= c:
            continue
        p = days.searchsorted(ts.normalize())
        if p + 22 < len(days):
            out[k] = np.sign(ret[tk].iloc[p + 1:p + 22].sum())
    return out
