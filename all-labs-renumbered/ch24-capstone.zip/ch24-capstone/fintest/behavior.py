"""Investor behavior and its cost (Chapter 22).

* time_weighted, money_weighted (IRR), aggregate_investor - the gap between what an asset earns and what its
  investors earn, from returns and net flows
* flow_timing - do flows predict future returns?
* simulate_disposition, pgr_plr - agents who sell winners and hold losers (Odean 1998), the proportion of gains
  and losses realized, and what the winners sold and losers kept did next
* turnover_experiment - random portfolios with different turnover, net of trading costs (Barber and Odean 2000)
* withdrawal_success, bond_returns_annual - historical sustainability of retirement withdrawal rules: a fixed real
  withdrawal (Bengen 1994), a fixed percentage of wealth, and a simple guardrail rule
* simulated_* - fake data with known behavior. TESTING ONLY.
"""

from __future__ import annotations

import math

import numpy as np
import pandas as pd
from scipy.optimize import brentq


# ---------------------------------------------------------------------------
# Time- and money-weighted returns
# ---------------------------------------------------------------------------


def time_weighted(returns) -> float:
    """Annualizable growth of 1 invested throughout: product of (1 + r) minus 1, for the whole period."""
    return float(np.prod(1 + np.asarray(returns, float)) - 1)


def money_weighted(cashflows, periods_per_year: int = 12) -> float:
    """Internal rate of return of equally spaced cash flows (investor's perspective: contributions negative,
    withdrawals and the final value positive), annualized."""
    cf = np.asarray(cashflows, float)
    t = np.arange(len(cf))
    f = lambda r: np.sum(cf * np.exp(-t * np.log1p(r)))  # noqa: E731
    r = brentq(f, -0.2, 0.2)          # per period; wide enough for monthly or annual data, safe from overflow
    return float((1 + r) ** periods_per_year - 1)


def aggregate_investor(returns: pd.Series, flows: pd.Series, start_assets: float,
                       periods_per_year: int = 12) -> dict:
    """The aggregate investor in an asset: assets grow with the return and change with net flows,
    A_t = A_{t-1}(1 + r_t) + F_t. Returns the annualized time-weighted (buy-and-hold) return, the annualized
    money-weighted return (IRR of -A_0, -F_1, ..., -F_T + A_T) and the gap between them."""
    r = returns.astype(float).to_numpy()
    F = flows.reindex(returns.index).fillna(0).astype(float).to_numpy()
    A = np.empty(len(r))
    prev = start_assets
    for t in range(len(r)):
        prev = prev * (1 + r[t]) + F[t]
        A[t] = prev
    cf = np.r_[-start_assets, -F]
    cf[-1] += A[-1]
    years = len(r) / periods_per_year
    tw = (1 + time_weighted(r)) ** (1 / years) - 1
    mw = money_weighted(cf, periods_per_year)
    return {"time_weighted": tw, "money_weighted": mw, "gap": mw - tw, "assets": pd.Series(A, index=returns.index),
            "years": years}


def flow_timing(returns: pd.Series, flows: pd.Series, assets: pd.Series, horizon: int = 12) -> dict:
    """Regress the next `horizon`-period return on this period's flow scaled by lagged assets, and on the past
    `horizon`-period return (performance chasing). Newey-West t-statistics."""
    f = (flows / assets.shift(1)).rename("flow")
    fut = np.exp(np.log1p(returns).rolling(horizon).sum().shift(-horizon)) - 1
    past = np.exp(np.log1p(returns).rolling(horizon).sum()) - 1
    out = {}
    for name, y, x in (("future_return_on_flow", fut, f), ("flow_on_past_return", f, past)):
        df = pd.concat([y.rename("y"), x.rename("x")], axis=1).dropna()
        X = np.c_[np.ones(len(df)), df["x"]]
        b, *_ = np.linalg.lstsq(X, df["y"].to_numpy(), rcond=None)
        e = df["y"].to_numpy() - X @ b
        T, L = len(e), horizon
        Xe = X * e[:, None]
        S = Xe.T @ Xe / T
        for l in range(1, L + 1):
            G = Xe[l:].T @ Xe[:-l] / T
            S += (1 - l / (L + 1)) * (G + G.T)
        Q = np.linalg.inv(X.T @ X / T)
        V = Q @ S @ Q / T
        out[name] = {"slope": float(b[1]), "t": float(b[1] / math.sqrt(V[1, 1])), "n": T}
    return out


# ---------------------------------------------------------------------------
# Disposition effect
# ---------------------------------------------------------------------------


def simulate_disposition(R: pd.DataFrame, n_agents: int = 400, holdings: int = 5, sell_prob: float = 0.15,
                         winner_bias: float = 0.0, seed: int = 0, horizon: int = 12) -> dict:
    """Agents hold `holdings` assets (columns of R, monthly returns). Each month an agent sells one holding with
    probability `sell_prob`, choosing a position at a gain with probability 0.5 + winner_bias/2 when it holds both
    gains and losses (winner_bias = 0: no preference; 1: always a winner), and buys a random asset not held.
    Records, at each sale, the realized and paper gains and losses (Odean's PGR and PLR) and the next `horizon`
    months' return of the winner sold and of the losers still held. Returns agent-average monthly returns too."""
    rng = np.random.default_rng(seed)
    X = R.to_numpy()
    T, N = X.shape
    logc = np.vstack([np.zeros(N), np.cumsum(np.log1p(np.nan_to_num(X)), axis=0)])   # log price index
    rg = pg = rl = pl = 0
    sold_w, kept_l, sold_l, kept_w = [], [], [], []
    agent_ret = np.zeros(T)
    for a in range(n_agents):
        hold = list(rng.choice(N, holdings, replace=False))
        basis = {j: 0 for j in hold}                       # purchase time
        for t in range(1, T):
            agent_ret[t] += np.nanmean(X[t, hold]) / n_agents
            if rng.random() >= sell_prob:
                continue
            gain = {j: logc[t + 1, j] - logc[basis[j], j] for j in hold}   # gain up to end of month t
            winners = [j for j in hold if gain[j] > 0]
            losers = [j for j in hold if gain[j] <= 0]
            if winners and losers:
                pick_w = rng.random() < 0.5 + winner_bias / 2
                pool = winners if pick_w else losers
            else:
                pool = hold
            j = pool[rng.integers(len(pool))]
            others = [k for k in hold if k != j]
            if gain[j] > 0:
                rg += 1
                pg += sum(gain[k] > 0 for k in others)
                pl += sum(gain[k] <= 0 for k in others)
            else:
                rl += 1
                pl += sum(gain[k] <= 0 for k in others)
                pg += sum(gain[k] > 0 for k in others)
            if t + 1 + horizon <= T:
                fut = lambda k: math.expm1(logc[t + 1 + horizon, k] - logc[t + 1, k])  # noqa: E731
                if gain[j] > 0:
                    sold_w.append(fut(j))
                    kept_l += [fut(k) for k in others if gain[k] <= 0]
                else:
                    sold_l.append(fut(j))
                    kept_w += [fut(k) for k in others if gain[k] > 0]
            new = rng.choice([k for k in range(N) if k not in hold])
            hold = others + [int(new)]
            basis = {k: basis.get(k, t + 1) for k in hold}
            basis[int(new)] = t + 1
    pgr = rg / max(rg + pg, 1)
    plr = rl / max(rl + pl, 1)
    return {"PGR": pgr, "PLR": plr, "PGR_minus_PLR": pgr - plr, "realized_gains": rg, "realized_losses": rl,
            "winners_sold_next": float(np.mean(sold_w)) if sold_w else np.nan,
            "losers_kept_next": float(np.mean(kept_l)) if kept_l else np.nan,
            "n_winners_sold": len(sold_w), "agent_returns": pd.Series(agent_ret, index=R.index)}


# ---------------------------------------------------------------------------
# Overtrading
# ---------------------------------------------------------------------------


def turnover_experiment(R: pd.DataFrame, turnovers=(0.0, 0.25, 0.75, 1.5, 2.5), holdings: int = 10,
                        cost_bp: float = 50, n_agents: int = 200, seed: int = 0) -> pd.DataFrame:
    """Random equal-weight portfolios of `holdings` assets that replace positions at random at the given annual
    turnover (share of the portfolio replaced per year), paying `cost_bp` per unit traded (a sale plus a purchase of
    the same amount counts as two units). Picks are random, so any difference in gross return is luck; the cost
    is the systematic effect."""
    rng = np.random.default_rng(seed)
    X = np.nan_to_num(R.to_numpy())
    T, N = X.shape
    rows = []
    for to in turnovers:
        p_replace = to / 12
        gross, net = [], []
        for _ in range(n_agents):
            hold = rng.choice(N, holdings, replace=False)
            g = n = 1.0
            for t in range(T):
                r = X[t, hold].mean()
                g *= 1 + r
                k = rng.binomial(holdings, min(p_replace, 1.0))
                traded = k / holdings
                n *= (1 + r) * (1 - 2 * traded * cost_bp / 1e4)
                if k:
                    out_idx = rng.choice(holdings, k, replace=False)
                    pool = np.setdiff1d(np.arange(N), hold)
                    hold[out_idx] = rng.choice(pool, k, replace=False)
            years = T / 12
            gross.append(g ** (1 / years) - 1)
            net.append(n ** (1 / years) - 1)
        rows.append({"annual_turnover": to, "gross_return": float(np.mean(gross)), "net_return": float(np.mean(net)),
                     "cost_drag": float(np.mean(gross) - np.mean(net))})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Withdrawal rules
# ---------------------------------------------------------------------------


def withdrawal_success(stock: pd.Series, bond: pd.Series, rates=(0.03, 0.035, 0.04, 0.045, 0.05, 0.06),
                       years: int = 30, equity: float = 0.6, rule: str = "fixed_real") -> pd.DataFrame:
    """Annual real returns. For every start year with `years` of data, start with wealth 1 and withdraw at the start
    of each year: 'fixed_real' takes rate x initial wealth every year (Bengen); 'percent' takes rate x current wealth;
    'guardrails' starts at rate x initial wealth, cuts the withdrawal by 10% when it exceeds 1.2 x rate of current
    wealth and raises it by 10% when it is below 0.8 x rate. Rebalanced annually to `equity` in stocks. Reports the
    share of start years in which wealth never ran out, the median ending wealth and, for 'percent' and
    'guardrails', the lowest withdrawal as a share of the first."""
    s, b = stock.dropna(), bond.reindex(stock.index).dropna()
    idx = s.index.intersection(b.index)
    s, b = s.loc[idx].to_numpy(), b.loc[idx].to_numpy()
    starts = range(0, len(idx) - years + 1)
    rows = []
    for rate in rates:
        ok, ends, worst = 0, [], []
        for st in starts:
            w, wd = 1.0, rate
            min_wd = wd
            failed = False
            for y in range(years):
                if rule == "percent":
                    wd = rate * w
                elif rule == "guardrails" and y > 0:
                    cur = wd / max(w, 1e-12)
                    if cur > 1.2 * rate:
                        wd *= 0.9
                    elif cur < 0.8 * rate:
                        wd *= 1.1
                w -= wd
                min_wd = min(min_wd, wd)
                if w <= 0:
                    failed = True
                    break
                w *= 1 + equity * s[st + y] + (1 - equity) * b[st + y]
            ok += not failed
            ends.append(0.0 if failed else w)
            worst.append(min_wd / rate)
        rows.append({"rule": rule, "rate": rate, "success_rate": ok / len(starts), "median_end_wealth": float(np.median(ends)),
                     "lowest_withdrawal_vs_first": float(np.min(worst)), "start_years": len(starts)})
    return pd.DataFrame(rows)


def bond_returns_annual(gs10_annual_pct: pd.Series, cpi: pd.Series) -> pd.Series:
    """Approximate annual real return on a 10-year Treasury bond from year-end yields (percent): coupon plus price
    change of a par bond held one year, deflated by CPI."""
    y = gs10_annual_pct.astype(float) / 100
    prev = y.shift(1)
    n = 9.0
    price = prev / y * (1 - (1 + y) ** (-n)) + (1 + y) ** (-n)
    nominal = price - 1 + prev
    infl = cpi / cpi.shift(1) - 1
    return ((1 + nominal) / (1 + infl) - 1).dropna()


def sequence_risk_example(stock_real: pd.Series, rate: float = 0.05, years: int = 30, equity: float = 1.0) -> dict:
    """The same 30 annual returns in historical and in reversed order, with a fixed real withdrawal: ending wealth
    differs although the average return is identical."""
    r = stock_real.dropna().to_numpy()[:years]
    out = {}
    for lab, seq in (("historical order", r), ("reversed order", r[::-1])):
        w, path = 1.0, []
        for x in seq:
            w = max(w - rate, 0) * (1 + equity * x)
            path.append(w)
        out[lab] = path
    return out


# ---------------------------------------------------------------------------
# Simulation
# ---------------------------------------------------------------------------


def simulated_flows(n_months: int = 600, seed: int = 0, start: str = "1975-01", chase: float = 0.6) -> dict:
    """Fake monthly equity-fund returns with mild mean reversion and flows that chase past 12-month returns. TESTING
    ONLY."""
    rng = np.random.default_rng(seed)
    idx = pd.period_range(start, periods=n_months, freq="M")
    r = np.zeros(n_months)
    val = 0.0
    for t in range(n_months):
        val = 0.98 * val + 0.04 * rng.standard_normal()
        r[t] = 0.007 - 0.02 * val + 0.04 * rng.standard_normal()
    r = pd.Series(r, index=idx)
    past = np.exp(np.log1p(r).rolling(12, min_periods=1).sum()) - 1
    A = 100.0
    flows = []
    for t in range(n_months):
        f = A * (0.002 + chase * 0.01 * past.iloc[t] / 0.1 * 0.5 + 0.004 * rng.standard_normal())
        A = A * (1 + r.iloc[t]) + f
        flows.append(f)
    return {"returns": r, "flows": pd.Series(flows, index=idx), "start_assets": 100.0}


def simulated_assets_with_momentum(n_assets: int = 49, n_months: int = 1188, seed: int = 0,
                                   start: str = "1926-07") -> pd.DataFrame:
    """Fake monthly returns with persistent expected-return differences, so past winners tend to keep winning (as in
    industry momentum). TESTING ONLY."""
    rng = np.random.default_rng(seed)
    idx = pd.period_range(start, periods=n_months, freq="M")
    mu = np.zeros(n_assets)
    out = np.zeros((n_months, n_assets))
    mkt = 0.006 + 0.045 * rng.standard_normal(n_months)
    for t in range(n_months):
        mu = 0.95 * mu + 0.0015 * rng.standard_normal(n_assets)
        out[t] = mkt[t] + mu + 0.05 * rng.standard_normal(n_assets)
    return pd.DataFrame(out, index=idx, columns=[f"A{i:02d}" for i in range(n_assets)])


def simulated_annual_real(n_years: int = 150, seed: int = 0, start: int = 1872) -> pd.DataFrame:
    """Fake annual real stock and bond returns with means and volatilities close to US history. TESTING ONLY."""
    rng = np.random.default_rng(seed)
    idx = pd.Index(range(start, start + n_years), name="year")
    s = 0.065 + 0.18 * rng.standard_normal(n_years)
    b = 0.02 + 0.08 * rng.standard_normal(n_years) + 0.1 * np.r_[0, np.diff(s)] * 0
    return pd.DataFrame({"stock": s, "bond": b}, index=idx)
