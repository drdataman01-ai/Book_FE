"""Lab 3: How Reliable Is a t-Statistic?

Chapter 3 of *Financial Engineering and the Evidence: A Claim-Verify
Approach to Quantitative Finance*.

CLAIM ON TRIAL
  "Standard regression statistics are reliable for financial returns."

WHAT THE LAB DOES
  Part A  Stylized facts. Fat tails, volatility clustering and autocorrelation
          in daily and monthly U.S. market returns (real data).
  Part B  Four standard errors. Alphas of the 25 Fama-French size/book-to-market
          portfolios under the CAPM and the three-factor model, with classical,
          White, Newey-West and bootstrap standard errors, plus the GRS test.
  Part C  Overlapping regressions. Real market returns paired with 1,000
          simulated predictors that have NO predictive power: how often do
          classical, Newey-West and Hodrick t-statistics find "predictability"
          at horizons from 1 to 60 months?
  Part D  Fama-MacBeth. Risk premia for the market, size and value from the
          25 portfolios, with Fama-MacBeth and Shanken-corrected errors.
  Part E  Economic significance. Alphas with bootstrap confidence intervals,
          in percent per year.

DATA (Kenneth R. French Data Library, downloaded automatically)
  Fama/French 3 Factors (monthly and daily); 25 Portfolios Formed on Size and
  Book-to-Market (5 x 5), value-weighted monthly returns.

USAGE
  python lab03.py                    # real data
  python lab03.py --source sim       # fake data, to test the code
  python lab03.py --start 1926-07    # use the full sample for Parts B, D, E

OUTPUT
  report/lab03_report.md, five figures (PNG), CSV tables and summary.json.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

from fintest import plots
from fintest.data import (
    DataUnavailable,
    find_table,
    load_french_factors,
    load_french_tables,
    simulated_25_portfolios,
    simulated_daily_market,
    simulated_ff3_monthly,
)
from fintest.inference import (
    acf,
    ar1_predictors,
    bootstrap_coefficients,
    fama_macbeth,
    grs_test,
    long_horizon_tstats,
    moments,
    ols_all_se,
    tail_counts,
)

ROOT = Path(__file__).resolve().parent
FACTORS = ["Mkt-RF", "SMB", "HML"]


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------


def load_all(source: str, monthly_file=None, daily_file=None, portfolios_file=None, sim_seed: int = 0) -> dict:
    if source == "sim":
        ff3 = simulated_ff3_monthly(seed=sim_seed)
        daily = simulated_daily_market(seed=sim_seed)
        p25 = simulated_25_portfolios(ff3, seed=sim_seed)
        simulated = True
    else:
        ff3 = load_french_factors("ff3_monthly", path=monthly_file)
        daily = load_french_factors("ff3_daily", path=daily_file)
        tables = load_french_tables("size_bm_25", path=portfolios_file)
        p25 = find_table(tables, "value", "weight")
        simulated = False
    return {"ff3": ff3, "daily": daily, "p25": label_25(p25), "simulated": simulated}


def label_25(df: pd.DataFrame) -> pd.DataFrame:
    """Rename the 25 portfolio columns S1B1 ... S5B5 (size quintile, book-to-market quintile).

    The French file lists portfolios size-major: SMALL LoBM, ME1 BM2, ...,
    SMALL HiBM, ME2 BM1, ..., BIG HiBM. The 25 return columns are taken by
    position, so the code does not depend on exact column names.
    """
    out = df.iloc[:, :25].copy()
    out.columns = [f"S{i // 5 + 1}B{i % 5 + 1}" for i in range(25)]
    return out


def panel(data: dict, start: str | None, end: str | None):
    """Portfolio excess returns and factors over a common sample."""
    ff3, p25 = data["ff3"], data["p25"]
    idx = ff3.index.intersection(p25.index)
    if start:
        idx = idx[idx >= pd.Period(start, freq="M")]
    if end:
        idx = idx[idx <= pd.Period(end, freq="M")]
    p25 = p25.loc[idx].dropna(axis=1, how="any")
    Y = p25.sub(ff3.loc[idx, "RF"], axis=0)
    F = ff3.loc[idx, FACTORS]
    return Y, F


# ---------------------------------------------------------------------------
# Part A: stylized facts
# ---------------------------------------------------------------------------


def part_a(data: dict, nlags: int = 50) -> dict:
    d = (data["daily"]["Mkt-RF"] + data["daily"]["RF"]).dropna().to_numpy()
    m = (data["ff3"]["Mkt-RF"] + data["ff3"]["RF"]).dropna().to_numpy()
    mom = pd.DataFrame([dict(frequency="Daily", **moments(d)), dict(frequency="Monthly", **moments(m))])
    ac = pd.DataFrame({"lag": np.arange(1, nlags + 1), "returns": acf(d, nlags), "absolute_returns": acf(np.abs(d), nlags)})
    monthly_ac = pd.DataFrame({"lag": np.arange(1, 13), "returns": acf(m, 12), "absolute_returns": acf(np.abs(m), 12)})
    tails = pd.DataFrame(tail_counts(d, ks=(3, 4, 5, 6)))
    worst = data["daily"].index[int(np.argmin(d))]
    return {"moments": mom, "acf_daily": ac, "acf_monthly": monthly_ac, "tails": tails, "daily": d,
            "worst_day": str(worst.date()), "worst_return": float(d.min()),
            "daily_start": str(data["daily"].index[0].date()), "daily_end": str(data["daily"].index[-1].date())}


# ---------------------------------------------------------------------------
# Part B: alphas with four standard errors, and the GRS test
# ---------------------------------------------------------------------------


def part_b(Y: pd.DataFrame, F: pd.DataFrame, n_boot: int = 2000, mean_block: float = 12, seed: int = 0,
           nw_lags: int | None = None) -> dict:
    out = {}
    for model, cols in (("CAPM", ["Mkt-RF"]), ("Three-factor", FACTORS)):
        f = F[cols].to_numpy()
        y = Y.to_numpy()
        reg = ols_all_se(y, f, nw_lags)
        boot = bootstrap_coefficients(y, f, n_boot=n_boot, mean_block=mean_block, seed=seed)
        a_boot = boot[:, 0, :]
        alpha = reg["coef"][0]
        table = pd.DataFrame({
            "portfolio": Y.columns,
            "alpha_annual": alpha * 12,
            "t_classical": alpha / reg["se_classical"][0],
            "t_white": alpha / reg["se_white"][0],
            "t_newey_west": alpha / reg["se_nw"][0],
            "t_bootstrap": alpha / a_boot.std(axis=0, ddof=1),
            "ci_low_annual": np.percentile(a_boot, 2.5, axis=0) * 12,
            "ci_high_annual": np.percentile(a_boot, 97.5, axis=0) * 12,
        })
        se_ratio = {"White / classical": float(np.median(reg["se_white"][0] / reg["se_classical"][0])),
                    "Newey-West / classical": float(np.median(reg["se_nw"][0] / reg["se_classical"][0])),
                    "Bootstrap / classical": float(np.median(a_boot.std(axis=0, ddof=1) / reg["se_classical"][0]))}
        counts = {m: int((np.abs(table[f"t_{m}"]) > 1.96).sum())
                  for m in ("classical", "white", "newey_west", "bootstrap")}
        out[model] = {"table": table, "se_ratio": se_ratio, "significant_counts": counts,
                      "grs": grs_test(y, f), "nw_lags": reg["nw_lags"]}
    out["sample"] = {"start": str(Y.index[0]), "end": str(Y.index[-1]), "months": len(Y),
                     "n_portfolios": Y.shape[1]}
    return out


# ---------------------------------------------------------------------------
# Part C: overlapping long-horizon regressions with a useless predictor
# ---------------------------------------------------------------------------


def part_c(data: dict, horizons=(1, 6, 12, 24, 36, 60), n_sims: int = 1000, phi: float = 0.98,
           rho: float = 0.0, seed: int = 0) -> dict:
    r = data["ff3"]["Mkt-RF"].dropna().to_numpy()
    rng = np.random.default_rng(seed)
    shocks = (r - r.mean()) / r.std()
    # The predictor's innovation at t is tied to the return realized at t (rho), never to future returns.
    X = ar1_predictors(len(r), n_sims, phi, rng, shocks=shocks, rho=rho)
    rows = []
    for k in horizons:
        res = long_horizon_tstats(r, X, k)
        rows.append({"horizon_months": k, "n_obs": res["n_obs"],
                     "reject_classical": float((np.abs(res["t_classical"]) > 1.96).mean()),
                     "reject_newey_west": float((np.abs(res["t_newey_west"]) > 1.96).mean()),
                     "reject_hodrick": float((np.abs(res["t_hodrick"]) > 1.96).mean()),
                     "mean_r2": float(res["r2"].mean()), "p95_r2": float(np.percentile(res["r2"], 95)),
                     "mean_slope": float(res["slope"].mean())})
    return {"table": pd.DataFrame(rows), "n_sims": n_sims, "phi": phi, "rho": rho, "months": len(r)}


# ---------------------------------------------------------------------------
# Part D: Fama-MacBeth
# ---------------------------------------------------------------------------


def part_d(Y: pd.DataFrame, F: pd.DataFrame) -> dict:
    out = {}
    for model, cols in (("CAPM", ["Mkt-RF"]), ("Three-factor", FACTORS)):
        fm = fama_macbeth(Y.to_numpy(), F[cols].to_numpy(), names=cols)
        out[model] = {"table": pd.DataFrame({
            "term": fm["labels"],
            "premium_annual": fm["lambda"] * 12,
            "t_fama_macbeth": fm["t_fm"],
            "t_shanken": fm["t_shanken"],
            "factor_mean_annual": fm["factor_means"] * 12,
        }), "shanken_c": fm["shanken_c"], "r2": fm["cross_sectional_r2"]}
    return out


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------


def _sub(sim: bool, text: str) -> str:
    return text + ("  ·  SIMULATED DATA: tests the code only" if sim else "")


def fig_acf(a: dict, out: Path, sim: bool):
    fig, ax, plt = plots.new_figure()
    ac = a["acf_daily"]
    ax.axhline(0, color=plots.INK_3, linewidth=1)
    n = len(a["daily"])
    band = 1.96 / math.sqrt(n)
    ax.axhspan(-band, band, color=plots.SHADE, zorder=0)
    ax.plot(ac["lag"], ac["absolute_returns"], color=plots.ORANGE, linewidth=2, marker="o", markersize=4)
    ax.plot(ac["lag"], ac["returns"], color=plots.BLUE, linewidth=2, marker="o", markersize=4)
    ax.text(ac["lag"].iloc[-1], ac["absolute_returns"].iloc[-1], "  absolute returns", va="center", fontsize=9,
            color=plots.INK)
    ax.text(ac["lag"].iloc[-1], ac["returns"].iloc[-1], "  returns", va="center", fontsize=9, color=plots.INK)
    ax.set_xlim(0, ac["lag"].iloc[-1] * 1.18)
    ax.set_xlabel("Lag (trading days)")
    ax.set_ylabel("Autocorrelation")
    plots.titles(fig, "Figure 3.1  Returns barely remember the past; their size does",
                 _sub(sim, f"Daily U.S. market returns, {a['daily_start']} to {a['daily_end']} · shaded band: "
                           "what independent data would show 95% of the time"))
    plots.finish(fig, out / "fig3_1_autocorrelation.png")
    plt.close(fig)


def fig_tails(a: dict, out: Path, sim: bool):
    fig, ax, plt = plots.new_figure()
    d = a["daily"]
    z = (d - d.mean()) / d.std(ddof=1)
    lim = max(8, math.ceil(np.abs(z).max()))
    bins = np.linspace(-lim, lim, 2 * lim * 4 + 1)
    counts, edges = np.histogram(z, bins=bins)
    centers = (edges[:-1] + edges[1:]) / 2
    width = edges[1] - edges[0]
    ax.bar(centers, np.where(counts > 0, counts, np.nan), width=width * 0.9, color=plots.BLUE)
    grid = np.linspace(-lim, lim, 600)
    normal = len(z) * width * np.exp(-grid ** 2 / 2) / math.sqrt(2 * math.pi)
    ax.plot(grid, np.where(normal > 0.05, normal, np.nan), color=plots.INK_2, linewidth=1.5)
    ax.set_yscale("log")
    ax.set_ylim(0.5, counts.max() * 2)
    ax.set_xlabel("Daily return, in standard deviations from the mean")
    ax.set_ylabel("Number of days (log scale)")
    t = a["tails"].set_index("threshold_sd")
    note = (f"Moves beyond 5 standard deviations: {int(t.loc[5, 'observed'])} days observed, "
            f"{t.loc[5, 'normal_expected']:.2f} expected under a normal distribution")
    plots.titles(fig, "Figure 3.2  Fat tails: extreme days are far more common than the bell curve allows",
                 _sub(sim, note + " · grey curve: normal distribution"))
    plots.finish(fig, out / "fig3_2_tails.png")
    plt.close(fig)


def fig_alpha_grid(b: dict, out: Path, sim: bool):
    import matplotlib.pyplot as plt
    from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm

    fig, axes = plt.subplots(1, 2, figsize=(10, 4.9))
    fig.patch.set_facecolor(plots.SURFACE)
    cmap = LinearSegmentedColormap.from_list("div", [plots.BLUE, "#f0efec", plots.RED])
    vmax = max(abs(b[m]["table"]["alpha_annual"]).max() for m in ("CAPM", "Three-factor")) * 100
    norm = TwoSlopeNorm(vmin=-vmax, vcenter=0, vmax=vmax)
    for ax, model in zip(axes, ("CAPM", "Three-factor")):
        t = b[model]["table"]
        grid = t["alpha_annual"].to_numpy().reshape(5, 5) * 100
        tgrid = t["t_newey_west"].to_numpy().reshape(5, 5)
        ax.imshow(grid, cmap=cmap, norm=norm)
        for i in range(5):
            for j in range(5):
                ax.text(j, i - 0.12, f"{grid[i, j]:+.1f}", ha="center", va="center", fontsize=9.5,
                        color=plots.INK, fontweight="bold" if abs(tgrid[i, j]) > 1.96 else "normal")
                ax.text(j, i + 0.22, f"t {tgrid[i, j]:+.1f}", ha="center", va="center", fontsize=7.5,
                        color=plots.INK_2)
        ax.set_xticks(range(5), ["Growth", "2", "3", "4", "Value"], fontsize=9, color=plots.INK_2)
        ax.set_yticks(range(5), ["Small", "2", "3", "4", "Big"], fontsize=9, color=plots.INK_2)
        ax.set_xlabel("Book-to-market quintile", color=plots.INK_2, fontsize=9)
        ax.set_title(f"{model}  ·  GRS p = {b[model]['grs']['p_value']:.3f}", loc="left", fontsize=10,
                     color=plots.INK, pad=8)
        for s in ax.spines.values():
            s.set_visible(False)
        ax.tick_params(length=0)
    axes[0].set_ylabel("Size quintile", color=plots.INK_2, fontsize=9)
    s = b["sample"]
    plots.titles(fig, "Figure 3.3  Alphas of the 25 size and book-to-market portfolios (% per year)",
                 _sub(sim, f"{s['start']} to {s['end']} · red: positive, blue: negative · bold: |t| > 1.96 with "
                           "Newey–West errors"))
    plots.finish(fig, out / "fig3_3_alpha_grid.png")
    plt.close(fig)


def fig_overlap(c: dict, out: Path, sim: bool):
    import matplotlib.pyplot as plt

    t = c["table"]
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.4), gridspec_kw={"width_ratios": [1.6, 1]})
    fig.patch.set_facecolor(plots.SURFACE)
    ax = axes[0]
    plots.style_axes(ax)
    k = t["horizon_months"]
    series = (("reject_classical", plots.RED, "classical OLS"), ("reject_newey_west", plots.ORANGE, "Newey–West"),
              ("reject_hodrick", plots.BLUE, "Hodrick (1992)"))
    for col, color, label in series:
        ax.plot(k, t[col], color=color, linewidth=2, marker="o", markersize=6, markeredgecolor=plots.SURFACE,
                markeredgewidth=1.5)
        ax.text(k.iloc[-1] + 1.5, t[col].iloc[-1], label, va="center", fontsize=9, color=plots.INK)
    ax.axhline(0.05, color=plots.INK_3, linewidth=1, linestyle=(0, (4, 3)))
    ax.text(k.iloc[-1] + 1.5, 0.056, "correct rate (5%)", ha="left", va="bottom", fontsize=9, color=plots.INK_2)
    ax.set_xlim(0, k.iloc[-1] * 1.35)
    ax.set_ylim(0, max(0.1, t["reject_classical"].max() * 1.12))
    plots.percent_axis(ax)
    ax.set_xlabel("Forecast horizon (months)")
    ax.set_ylabel("Share of useless predictors found 'significant'")
    ax.set_title("False discoveries at |t| > 1.96", loc="left", fontsize=10, color=plots.INK, pad=8)

    ax = axes[1]
    plots.style_axes(ax)
    ax.plot(k, t["mean_r2"], color=plots.VIOLET, linewidth=2, marker="o", markersize=6,
            markeredgecolor=plots.SURFACE, markeredgewidth=1.5)
    ax.fill_between(k, 0, t["p95_r2"], color=plots.VIOLET, alpha=0.12, linewidth=0)
    plots.percent_axis(ax)
    ax.set_xlabel("Forecast horizon (months)")
    ax.set_ylabel("R² of a useless predictor")
    ax.set_title("R² rises with horizon anyway", loc="left", fontsize=10, color=plots.INK, pad=8)
    plots.titles(fig, "Figure 3.4  Overlapping regressions find predictability that is not there",
                 _sub(sim, f"Real monthly market returns ({c['months']} months) paired with {c['n_sims']:,} simulated "
                           f"predictors with no predictive power (autocorrelation {c['phi']}) · right: line = average, "
                           "band = up to 95th percentile"))
    plots.finish(fig, out / "fig3_4_overlap.png")
    plt.close(fig)


def fig_econ(b: dict, out: Path, sim: bool):
    fig, ax, plt = plots.new_figure(9, 6.2)
    t = b["Three-factor"]["table"].sort_values("alpha_annual").reset_index(drop=True)
    y = np.arange(len(t))
    ax.axvspan(-0.01, 0.01, color=plots.SHADE, zorder=0)
    ax.axvline(0, color=plots.INK_3, linewidth=1)
    for yi, r in t.iterrows():
        sig = (r.ci_low_annual > 0) or (r.ci_high_annual < 0)
        color = plots.ORANGE if sig else plots.BLUE
        ax.plot([r.ci_low_annual, r.ci_high_annual], [yi, yi], color=color, linewidth=2, solid_capstyle="round")
        ax.plot(r.alpha_annual, yi, "o", color=color, markersize=7, markeredgecolor=plots.SURFACE,
                markeredgewidth=1.5)
    ax.set_yticks(y, t["portfolio"], fontsize=8, color=plots.INK_2)
    plots.percent_axis(ax, "x")
    ax.set_xlabel("Three-factor alpha, % per year (dot) with 95% bootstrap interval (line)")
    ax.grid(axis="x", color=plots.GRID, linewidth=0.8)
    ax.grid(axis="y", visible=False)
    ax.set_ylim(-0.8, len(t) + 0.4)
    ax.text(0, len(t) - 0.35, "within ±1% a year", ha="center", va="bottom", fontsize=8.5, color=plots.INK_2)
    plots.titles(fig, "Figure 3.5  How big, and how sure? Alphas with their uncertainty",
                 _sub(sim, "Orange: interval excludes zero · S = size quintile (1 small), B = book-to-market "
                           "quintile (1 growth)"))
    plots.finish(fig, out / "fig3_5_alpha_intervals.png")
    plt.close(fig)


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------


def _md(df: pd.DataFrame, fmt: dict) -> str:
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join("---" for _ in cols) + " |"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(fmt[c](r[c]) if c in fmt else str(r[c]) for c in cols) + " |")
    return "\n".join(lines)


def _f(spec):
    def fmt(v):
        if pd.isna(v):
            return ""
        return format(int(round(v)) if spec.endswith("d") else v, spec)
    return fmt


def write_report(out: Path, a, b, c, d, sim: bool):
    md = ["# Lab 3 results: How Reliable Is a t-Statistic?", ""]
    if sim:
        md += ["> **Simulated data.** These numbers test that the lab runs. They say nothing about real markets. "
               "Run without `--source sim` for real results.", ""]
    md += ["**Claim on trial:** standard regression statistics are reliable for financial returns.", ""]

    md += ["## Part A: Stylized facts", "",
           _md(a["moments"].rename(columns={"frequency": "Returns", "n": "Observations", "mean": "Mean",
                                            "std": "Std. dev.", "skewness": "Skewness", "kurtosis": "Kurtosis"}),
               {"Mean": _f(".4%"), "Std. dev.": _f(".3%"), "Skewness": _f(".2f"), "Kurtosis": _f(".1f"),
                "Observations": _f(",d")}), "",
           "A normal distribution has skewness 0 and kurtosis 3.", "",
           f"Worst day: {a['worst_day']}, {a['worst_return']:.1%}.", "",
           _md(a["tails"].rename(columns={"threshold_sd": "Beyond (std. dev.)", "observed": "Days observed",
                                          "normal_expected": "Expected if normal"}),
               {"Days observed": _f(",d"), "Expected if normal": _f(".2f")}), "",
           "![Figure 3.1](fig3_1_autocorrelation.png)", "", "![Figure 3.2](fig3_2_tails.png)", ""]

    s = b["sample"]
    md += ["## Part B: Four standard errors for 25 alphas", "",
           f"Sample {s['start']} to {s['end']} ({s['months']} months), {s['n_portfolios']} value-weighted portfolios. "
           f"Newey–West lags: {b['CAPM']['nw_lags']}.", ""]
    rows = []
    for model in ("CAPM", "Three-factor"):
        cnt, ratio, g = b[model]["significant_counts"], b[model]["se_ratio"], b[model]["grs"]
        rows.append({"Model": model, "|t|>1.96 classical": cnt["classical"], "White": cnt["white"],
                     "Newey–West": cnt["newey_west"], "Bootstrap": cnt["bootstrap"],
                     "Median SE ratio NW/classical": ratio["Newey-West / classical"],
                     "Median SE ratio bootstrap/classical": ratio["Bootstrap / classical"],
                     "Mean |alpha| (%/yr)": g["mean_abs_alpha_annual"] * 100,
                     "GRS": g["grs"], "GRS p-value": g["p_value"]})
    md += [_md(pd.DataFrame(rows), {"Median SE ratio NW/classical": _f(".2f"),
                                    "Median SE ratio bootstrap/classical": _f(".2f"),
                                    "Mean |alpha| (%/yr)": _f(".2f"), "GRS": _f(".2f"), "GRS p-value": _f(".4f")}), "",
           "Full portfolio-level results are in table_alphas_capm.csv and table_alphas_three_factor.csv.", "",
           "![Figure 3.3](fig3_3_alpha_grid.png)", ""]

    t = c["table"]
    md += ["## Part C: Overlapping regressions with a useless predictor", "",
           f"{c['n_sims']:,} simulated predictors (AR(1), autocorrelation {c['phi']}, correlation with return shocks "
           f"{c['rho']}) paired with real monthly market excess returns. The true slope is zero, so a correct test "
           "rejects 5% of the time.", "",
           _md(t[["horizon_months", "reject_classical", "reject_newey_west", "reject_hodrick", "mean_r2"]].rename(
               columns={"horizon_months": "Horizon (months)", "reject_classical": "Classical",
                        "reject_newey_west": "Newey–West", "reject_hodrick": "Hodrick (1992)",
                        "mean_r2": "Average R²"}),
               {"Classical": _f(".1%"), "Newey–West": _f(".1%"), "Hodrick (1992)": _f(".1%"),
                "Average R²": _f(".1%")}), "",
           "![Figure 3.4](fig3_4_overlap.png)", ""]

    md += ["## Part D: Fama–MacBeth risk premia", ""]
    for model in ("CAPM", "Three-factor"):
        md += [f"**{model}** (cross-sectional R² {d[model]['r2']:.2f}; Shanken multiplier 1 + c = "
               f"{1 + d[model]['shanken_c']:.3f})", "",
               _md(d[model]["table"].rename(columns={"term": "Term", "premium_annual": "Premium (%/yr)",
                                                    "t_fama_macbeth": "t (Fama–MacBeth)", "t_shanken": "t (Shanken)",
                                                    "factor_mean_annual": "Factor's own average (%/yr)"}),
                   {"Premium (%/yr)": lambda v: f"{v * 100:+.2f}", "t (Fama–MacBeth)": _f(".2f"),
                    "t (Shanken)": _f(".2f"),
                    "Factor's own average (%/yr)": lambda v: "" if pd.isna(v) else f"{v * 100:.2f}"}), ""]

    tf = b["Three-factor"]["table"]
    sig = (tf["ci_low_annual"] > 0) | (tf["ci_high_annual"] < 0)
    small_sig = int((sig & (tf["alpha_annual"].abs() < 0.01)).sum())
    big_insig = int((~sig & (tf["alpha_annual"].abs() > 0.02)).sum())
    md += ["## Part E: Economic significance", "",
           f"- Three-factor alphas whose 95% bootstrap interval excludes zero: {int(sig.sum())} of {len(tf)}.",
           f"- Of those, economically small (|alpha| < 1% a year): {small_sig}.",
           f"- Alphas larger than 2% a year whose interval includes zero: {big_insig}.",
           f"- Median width of the 95% interval: {(tf['ci_high_annual'] - tf['ci_low_annual']).median():.1%} a year.", "",
           "![Figure 3.5](fig3_5_alpha_intervals.png)", ""]

    md += ["## Your verdict", "",
           "Where did the choice of standard error matter, and where did it not? Use Parts B and C. "
           "Then judge the claim: are standard regression statistics reliable for financial returns? "
           "Name one research design where you would never trust a classical t-statistic.", ""]
    (out / "lab03_report.md").write_text("\n".join(md))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", choices=["french", "sim"], default="french")
    ap.add_argument("--monthly-file", default=None, help="Fama/French 3 Factors (monthly) zip or CSV")
    ap.add_argument("--daily-file", default=None, help="Fama/French 3 Factors [Daily] zip or CSV")
    ap.add_argument("--portfolios-file", default=None, help="25 Portfolios Formed on Size and Book-to-Market zip or CSV")
    ap.add_argument("--start", default="1963-07", help="first month for Parts B, D, E (default 1963-07)")
    ap.add_argument("--end", default=None, help="last month for Parts B, D, E (default: latest)")
    ap.add_argument("--nw-lags", type=int, default=None, help="Newey-West lags in Part B (default: rule of thumb)")
    ap.add_argument("--n-boot", type=int, default=2000)
    ap.add_argument("--block", type=float, default=12, help="mean block length (months) for the stationary bootstrap")
    ap.add_argument("--n-sims", type=int, default=1000, help="Part C: number of useless predictors")
    ap.add_argument("--phi", type=float, default=0.98, help="Part C: predictor autocorrelation")
    ap.add_argument("--rho", type=float, default=0.0,
                    help="Part C: correlation of predictor shocks with return shocks (Stambaugh); default 0")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--sim-seed", type=int, default=0)
    ap.add_argument("--out", default=str(ROOT / "report"))
    return ap.parse_args(argv)


def run(args) -> dict:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    try:
        data = load_all(args.source, args.monthly_file, args.daily_file, args.portfolios_file, args.sim_seed)
    except DataUnavailable as e:
        raise SystemExit(str(e)) from None
    sim = data["simulated"]
    Y, F = panel(data, args.start, args.end)

    a = part_a(data)
    b = part_b(Y, F, n_boot=args.n_boot, mean_block=args.block, seed=args.seed, nw_lags=args.nw_lags)
    c = part_c(data, n_sims=args.n_sims, phi=args.phi, rho=args.rho, seed=args.seed)
    d = part_d(Y, F)

    fig_acf(a, out, sim)
    fig_tails(a, out, sim)
    fig_alpha_grid(b, out, sim)
    fig_overlap(c, out, sim)
    fig_econ(b, out, sim)

    a["moments"].to_csv(out / "table_moments.csv", index=False)
    a["tails"].to_csv(out / "table_tails.csv", index=False)
    a["acf_daily"].to_csv(out / "table_acf_daily.csv", index=False)
    b["CAPM"]["table"].to_csv(out / "table_alphas_capm.csv", index=False)
    b["Three-factor"]["table"].to_csv(out / "table_alphas_three_factor.csv", index=False)
    c["table"].to_csv(out / "table_overlap.csv", index=False)
    d["CAPM"]["table"].to_csv(out / "table_fama_macbeth_capm.csv", index=False)
    d["Three-factor"]["table"].to_csv(out / "table_fama_macbeth_three_factor.csv", index=False)
    write_report(out, a, b, c, d, sim)

    summary = {
        "simulated": sim,
        "moments": a["moments"].to_dict(orient="records"),
        "tails": a["tails"].to_dict(orient="records"),
        "alphas": {m: {"significant_counts": b[m]["significant_counts"], "se_ratio": b[m]["se_ratio"],
                       "grs": b[m]["grs"]} for m in ("CAPM", "Three-factor")},
        "overlap": c["table"].to_dict(orient="records"),
        "fama_macbeth": {m: d[m]["table"].to_dict(orient="records") for m in ("CAPM", "Three-factor")},
        "sample": b["sample"],
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=float))

    mom = a["moments"].set_index("frequency")
    ct = c["table"].set_index("horizon_months")
    print(f"A  Daily kurtosis {mom.loc['Daily', 'kurtosis']:.1f} (normal: 3)")
    for m in ("CAPM", "Three-factor"):
        cnt = b[m]["significant_counts"]
        print(f"B  {m}: |t|>1.96 for {cnt['classical']} (classical), {cnt['newey_west']} (Newey-West), "
              f"{cnt['bootstrap']} (bootstrap) of {b['sample']['n_portfolios']}; GRS p = {b[m]['grs']['p_value']:.4f}")
    k = ct.index.max()
    print(f"C  At {k} months a useless predictor is 'significant' {ct.loc[k, 'reject_classical']:.0%} of the time "
          f"(classical), {ct.loc[k, 'reject_newey_west']:.0%} (Newey-West), {ct.loc[k, 'reject_hodrick']:.0%} (Hodrick)")
    fmc = d["CAPM"]["table"].set_index("term")
    print(f"D  CAPM market premium {fmc.loc['Mkt-RF', 'premium_annual']:.1%} a year versus the market's own "
          f"{fmc.loc['Mkt-RF', 'factor_mean_annual']:.1%}")
    print(f"Report: {out / 'lab03_report.md'}")
    if sim:
        print("NOTE: simulated data. These results test the code only.")
    return summary


def main(argv=None):
    return run(parse_args(argv))


if __name__ == "__main__":
    main()
