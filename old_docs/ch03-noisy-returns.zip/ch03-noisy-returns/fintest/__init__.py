"""fintest: the analysis module for *Financial Engineering and the Evidence:
A Claim-Verify Approach to Quantitative Finance*.

This copy contains the parts Labs 1 to 3 use:

* fintest.data   - download and parse data from the Kenneth R. French Data Library
* fintest.stats  - returns, Sharpe ratios, drawdowns, Newey-West regressions, multiple-testing helpers
* fintest.inference - stylized facts, robust and bootstrap errors, GRS, Fama-MacBeth, Hodrick
* fintest.plots  - the book's chart style

Later chapters add backtesting with costs, the deflated Sharpe ratio and
forecast-evaluation tests.
"""

__version__ = "0.3.0"
