"""Tests for Lab 3. Run with:  python tests/test_lab03.py   (or: pytest tests/)

Runs offline. Statistics are checked against direct, loop-based calculations;
the 25-portfolio parser against a file in the French library's layout; and the
full lab on simulated data.
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fintest.data import find_table, parse_french_tables  # noqa: E402
from fintest.inference import (  # noqa: E402
    acf,
    fama_macbeth,
    grs_test,
    long_horizon_tstats,
    moments,
    ols_all_se,
    stationary_bootstrap_indices,
)

HEADER = ",SMALL LoBM,ME1 BM2,ME1 BM3,ME1 BM4,SMALL HiBM,ME2 BM1,ME2 BM2,ME2 BM3,ME2 BM4,ME2 BM5," \
         "ME3 BM1,ME3 BM2,ME3 BM3,ME3 BM4,ME3 BM5,ME4 BM1,ME4 BM2,ME4 BM3,ME4 BM4,ME4 BM5," \
         "BIG LoBM,ME5 BM2,ME5 BM3,ME5 BM4,BIG HiBM"
P25_SAMPLE = (
    "This file was created using the 202508 CRSP database.\n\n"
    "  Average Value Weighted Returns -- Monthly\n" + HEADER + "\n"
    "192607," + ",".join(f"{0.1 * i:.2f}" for i in range(25)) + "\n"
    "192608," + ",".join(f"{0.2 * i:.2f}" for i in range(25)) + "\n\n"
    "  Average Equal Weighted Returns -- Monthly\n" + HEADER + "\n"
    "192607," + ",".join("1.00" for _ in range(25)) + "\n"
)


def test_parse_and_label_25_portfolios():
    from lab03 import label_25

    tables = parse_french_tables(P25_SAMPLE, "M")
    vw = label_25(find_table(tables, "value", "weight"))
    assert vw.shape == (2, 25)
    assert vw.columns[0] == "S1B1" and vw.columns[4] == "S1B5" and vw.columns[5] == "S2B1"
    assert vw.columns[-1] == "S5B5"
    assert abs(vw.loc["1926-08", "S5B5"] - 0.048) < 1e-12  # 0.2 * 24 percent


def test_moments_and_acf():
    rng = np.random.default_rng(0)
    x = rng.standard_normal(200_000)
    m = moments(x)
    assert abs(m["skewness"]) < 0.03 and abs(m["kurtosis"] - 3) < 0.06
    ar = np.empty(50_000)
    ar[0] = 0
    e = rng.standard_normal(50_000)
    for t in range(1, len(ar)):
        ar[t] = 0.6 * ar[t - 1] + e[t]
    assert abs(acf(ar, 1)[0] - 0.6) < 0.02


def test_classical_se_matches_textbook():
    rng = np.random.default_rng(1)
    T = 400
    f = rng.standard_normal(T)
    y = 0.1 + 0.5 * f + rng.standard_normal(T)
    res = ols_all_se(y[:, None], f)
    X = np.column_stack([np.ones(T), f])
    b = np.linalg.lstsq(X, y, rcond=None)[0]
    e = y - X @ b
    se = np.sqrt(np.diag(np.linalg.inv(X.T @ X)) * (e @ e) / (T - 2))
    assert np.allclose(res["se_classical"][:, 0], se)


def test_grs_matches_direct_formula_and_size():
    rng = np.random.default_rng(2)
    T, N = 600, 10
    f = rng.normal(0.005, 0.045, (T, 1))
    B = rng.uniform(0.5, 1.5, N)
    Y = f * B + rng.normal(0, 0.02, (T, N))  # true alphas are zero
    g = grs_test(Y, f)
    X = np.column_stack([np.ones(T), f])
    coef = np.linalg.lstsq(X, Y, rcond=None)[0]
    E = Y - X @ coef
    S = E.T @ E / T
    a = coef[0]
    mu, var = f.mean(), f.var()
    direct = (T / N) * ((T - N - 1) / (T - 2)) * (a @ np.linalg.solve(S, a)) / (1 + mu ** 2 / var)
    assert abs(g["grs"] - direct) < 1e-10
    # Under the null, p-values should not be systematically tiny.
    ps = []
    for seed in range(60):
        r = np.random.default_rng(100 + seed)
        ff = r.normal(0.005, 0.045, (T, 1))
        YY = ff * B + r.normal(0, 0.02, (T, N))
        ps.append(grs_test(YY, ff)["p_value"])
    assert 0.0 < np.mean(np.array(ps) < 0.05) < 0.15


def test_fama_macbeth_recovers_known_premium():
    rng = np.random.default_rng(3)
    T, N = 2000, 25
    f = rng.normal(0.006, 0.04, (T, 1))
    beta = np.linspace(0.5, 1.5, N)
    # Expected excess return = beta * mean(f): the factor's price equals its mean.
    Y = f * beta + rng.normal(0, 0.01, (T, N))
    fm = fama_macbeth(Y, f, names=["mkt"])
    assert abs(fm["lambda"][1] - f.mean()) < 0.002
    assert abs(fm["lambda"][0]) < 0.002
    assert fm["se_shanken"][1] >= fm["se_fm"][1]


def test_hodrick_matches_loop_and_classical_matches_ols():
    rng = np.random.default_rng(4)
    T, k = 300, 12
    r = rng.normal(0.005, 0.04, T)
    x = np.cumsum(rng.standard_normal(T)) * 0.1
    res = long_horizon_tstats(r, x[:, None], k)
    n = T - k
    y = np.array([r[t + 1:t + 1 + k].sum() for t in range(n)])
    xd = x[:n] - x[:n].mean()
    yd = y - y.mean()
    b = (xd * yd).sum() / (xd ** 2).sum()
    e = yd - b * xd
    t_cl = b / np.sqrt((e ** 2).sum() / (n - 2) / (xd ** 2).sum())
    assert abs(res["t_classical"][0] - t_cl) < 1e-9
    eps = r - r[1:].mean()
    S = 0.0
    for s in range(1, T):
        lo, hi = max(0, s - k), min(s, n)
        S += (eps[s] * xd[lo:hi].sum()) ** 2
    t_h = b / (np.sqrt(S) / (xd ** 2).sum())
    assert abs(res["t_hodrick"][0] - t_h) < 1e-9


def test_overlap_inflates_classical_rejections():
    from fintest.inference import ar1_predictors

    rng = np.random.default_rng(5)
    r = rng.normal(0.005, 0.045, 900)
    X = ar1_predictors(900, 400, 0.98, rng)
    short = long_horizon_tstats(r, X, 1)
    long = long_horizon_tstats(r, X, 36)
    rej = lambda t: float((np.abs(t) > 1.96).mean())  # noqa: E731
    assert rej(long["t_classical"]) > 0.3
    assert rej(long["t_hodrick"]) < 0.12
    assert rej(short["t_classical"]) < 0.12


def test_stationary_bootstrap_blocks():
    rng = np.random.default_rng(6)
    idx = stationary_bootstrap_indices(100_000, 12, rng)
    breaks = (np.diff(idx) != 1) & ~((idx[:-1] == 99_999) & (idx[1:] == 0))
    mean_len = len(idx) / (breaks.sum() + 1)
    assert 10.5 < mean_len < 13.5
    assert idx.min() >= 0 and idx.max() < 100_000


def test_full_lab_runs_on_simulated_data():
    import lab03

    with tempfile.TemporaryDirectory() as tmp:
        summary = lab03.main(["--source", "sim", "--n-boot", "200", "--n-sims", "200", "--out", tmp])
        out = Path(tmp)
        assert len(list(out.glob("fig3_*.png"))) == 5
        report = (out / "lab03_report.md").read_text()
        assert "Simulated data" in report and "Your verdict" in report
        assert summary["simulated"] is True and summary["sample"]["n_portfolios"] == 25


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print(f"ok  {name}")
