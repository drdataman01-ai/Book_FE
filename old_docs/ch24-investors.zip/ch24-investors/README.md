# Lab 24: Do Individual Investors Hurt Themselves?

Companion lab for **Chapter 24** of *Financial Engineering and the Evidence: A Claim-Verify Approach to Quantitative Finance*.

**Claim on trial:** individual investors lose part of the return on their investments through their own trading behavior.

## Quick start

```bash
pip install -r requirements.txt
python lab24.py --flows-file data/equity_flows.csv --shiller-file data/ie_data.xls
python lab24.py --cost-bp 25            # Part C with a lower cost per trade
```

A run takes about two minutes. Parts B and C need only the French library files, which are downloaded; Part A needs a flow file and Part D needs Shiller's data. Without them those parts are skipped and the report says so.

| Data | Source | Option |
|---|---|---|
| Monthly net flows to US equity mutual funds (and, if available, their total net assets) | Investment Company Institute statistics on long-term mutual fund flows (ici.org, research and statistics); save a CSV with a date column, a column whose name contains "flow" (or "net new cash") and optionally one containing "assets". Any other aggregate flow series in the same layout works | `--flows-file` (and `--start-assets` if there is no assets column) |
| Market return (fund return proxy in Part A) | French library: `F-F_Research_Data_Factors_CSV.zip` | `--ff3-file` |
| 49 Industry Portfolios (the "stocks" in Parts B and C) | French library: `49_Industry_Portfolios_CSV.zip` | `--ind49-file` |
| Long-run US stock prices, dividends, CPI and 10-year yields from 1871 | Robert Shiller, `ie_data.xls` from http://www.econ.yale.edu/~shiller/data.htm | `--shiller-file` |

Or open `lab24_walkthrough.ipynb`, which runs the same steps with a prediction prompt before each one.

### Testing the code without real data

```bash
python lab24.py --source sim
```

The simulation builds a fund whose investors chase past returns, industries with persistent return differences (so past winners tend to keep winning), and annual real stock and bond returns with US-like means and volatilities. Results on simulated data test the code only.

## What the lab does

| Part | Question | Method | Output |
|---|---|---|---|
| A. Behavior gap | Do fund investors earn less than their funds? | Aggregate assets follow A_t = A_{t−1}(1 + r_t) + flow_t; compare the buy-and-hold (time-weighted) return with the money-weighted return (IRR of the flows); by decade. Do flows chase past 12-month returns, and do they predict the next 12 months? Newey–West t | Figure 24.1 |
| B. Disposition effect | What does selling winners and holding losers cost? | 400 simulated investors hold 5 of the 49 industries and sell one each month with probability 15%, preferring winners to different degrees; Odean's PGR (share of gains realized) and PLR (share of losses realized); the next 12 months' return of winners sold and losers kept | Figure 24.2 |
| C. Overtrading | What does turnover cost? | Random portfolios of 10 industries with annual turnover from 0% to 250%, 50 bp per trade | Figure 24.3 |
| D. Lifecycle | How much can a retiree spend? | Every 30-year period since 1871, 60/40 real returns: fixed real withdrawal (Bengen), fixed percentage of wealth, guardrails; sequence-of-returns risk | Figures 24.4–24.5 |

### Design notes

- **Part A** treats all equity funds as one investor, so it measures the timing of aggregate flows, not the trading of any individual. The market return stands in for the funds' return; funds that lag the market would shift both returns by about the same amount. The money-weighted return is sensitive to large flows late in the sample.
- **Part B** uses industry portfolios as stand-ins for stocks, because individual stock returns are not free. Industry momentum makes selling recent winners costly; with individual stocks, short-term reversal works the other way at a one-month horizon. Use your own brokerage records with Exercise 4 for a personal test.
- **Part D** uses Shiller's annual real S&P returns and a constant-maturity approximation of 10-year Treasury returns, with no fees or taxes. Bengen (1994) used intermediate-term Treasuries, so results differ slightly from his.

## Verification status

| Part | Status |
|---|---|
| Time- and money-weighted returns | Tested on hand-built cases |
| Behavior gap | Tested: zero with no flows; negative when money arrives before losses |
| Disposition simulation | Tested: PGR ≈ PLR without a bias, PGR > PLR with one |
| Turnover costs | Tested: cost drag ≈ 2 × turnover × cost |
| Withdrawal rules, bond returns | Tested with known returns |
| Flow-file reader | Tested on a file in the documented layout |
| Full lab and notebook | Run end to end on simulated data |
| Real data | Not run from the build environment (network blocked) |

Run the tests with `python tests/test_lab24.py` (about two minutes).

## Exercises

1. Compute the behavior gap separately for 1990–1999 and 2000–2009. When was it largest, and why?
2. In Part B, set the selling probability to 5% and to 40% a month. How does the cost of the disposition effect change?
3. Re-run Part C at 5 bp and at 100 bp per trade. At what cost does trading 100% of the portfolio a year cost 1% of return?
4. Export your own (or a sample) brokerage history and compute your time-weighted and money-weighted returns with `time_weighted` and `money_weighted`.
5. Find the highest fixed real withdrawal rate that never failed over 30 years since 1871 with 60/40, and the start year that set it.

## Data citation

Investment Company Institute (fund flow statistics). Kenneth R. French Data Library (Fama/French 3 Factors; 49 Industry Portfolios). Shiller, R. J., U.S. stock market data, http://www.econ.yale.edu/~shiller/data.htm.
