"""Lab 4: The Best of a Thousand Rules.

Chapter 4 of *Financial Engineering and the Evidence: A Claim-Verify
Approach to Quantitative Finance*.

CLAIM ON TRIAL
  "A strategy that clears t = 2 after a search is a genuine discovery."

WHAT THE LAB DOES
  Part A  The search. About 950 market-timing rules (moving averages,
          crossovers, momentum, seasonal and volatility filters, and their
          contrarian versions) are backtested on the first half of nearly a
          century of U.S. data. The best rule is judged with and without
          multiple-testing corrections, with the deflated Sharpe ratio, and
          in the second half of the sample.
  Part B  Probability of backtest overfitting. Combinatorially symmetric
          cross-validation (CSCV) across 12,870 splits of the full sample.
  Part C  The hurdle. The Sharpe ratio the best of N no-skill strategies is
          expected to reach, for backtests of 10, 25 and 50 years.
  Part D  What corrections cost. A simulation with known truth: 1,000
          strategies, 10% of them genuinely good. False discoveries and
          missed discoveries under every correction.

SKILL MEASURE
  Each rule is in the market or in Treasury bills. Its skill is its return
  after removing its market exposure (the "hedged" return: the rule's excess
  return minus beta times the market's), so a rule that merely holds the
  market earns zero. The Sharpe ratio of the hedged return is the rule's
  appraisal ratio, and its t-statistic is the t-statistic of alpha.

DATA
  Fama/French 3 Factors (monthly), Kenneth R. French Data Library.

USAGE
  python lab04.py
  python lab04.py --source sim          # fake data, to test the code
  python lab04.py --split 1990-12       # last month of the backtest

OUTPUT
  report/lab04_report.md, five figures (PNG), CSV tables and summary.json.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

from fintest import plots
from fintest.data import DataUnavailable, load_french_factors, simulated_market
from fintest.inference import moments
from fintest.multiple import (
    apply_corrections,
    cscv_pbo,
    deflated_sharpe,
    effective_trials,
    expected_max_sharpe,
)

ROOT = Path(__file__).resolve().parent
ALPHA = 0.025  # one-sided; equivalent to a two-sided 5% test (t > 1.96)


# ---------------------------------------------------------------------------
# Data and rules
# ---------------------------------------------------------------------------


def load_market(source: str, data_file=None, sim_seed: int = 0) -> pd.DataFrame:
    df = simulated_market(seed=sim_seed) if source == "sim" else load_french_factors("ff3_monthly", path=data_file)
    out = pd.DataFrame({"mkt_rf": df["Mkt-RF"], "rf": df["RF"]}).dropna()
    out.attrs["simulated"] = bool(df.attrs.get("simulated", False))
    return out


def build_rules(mkt: pd.DataFrame) -> pd.DataFrame:
    """Positions (1 = in the market, 0 = Treasury bills) for every rule, shape (months, rules).

    Every signal uses data up to the end of month t and sets the position for
    month t+1, so there is no look-ahead. Rows before a rule has enough
    history are filled with 1 (in the market, the neutral default) and the
    lab's backtest starts after the longest warm-up anyway.
    """
    total = mkt["mkt_rf"] + mkt["rf"]
    price = (1 + total).cumprod()
    rf_cum = (1 + mkt["rf"]).cumprod()
    month = mkt.index.month.to_numpy()
    rules: dict[str, pd.Series] = {}

    for k in range(2, 25):  # price above its k-month moving average, with a band
        ma = price.rolling(k).mean()
        for band in (0.0, 0.01, 0.02, 0.05):
            rules[f"price>MA{k}+{band:.0%}"] = (price > ma * (1 + band)).astype(float).where(ma.notna())
    for fast in range(1, 13):  # moving-average crossovers
        for slow in range(fast + 1, 25):
            f, s = price.rolling(fast).mean(), price.rolling(slow).mean()
            rules[f"MA{fast}>MA{slow}"] = (f > s).astype(float).where(s.notna())
    for look in range(1, 25):  # time-series momentum, with and without skipping the last month
        for skip in (0, 1):
            past = price.shift(skip) / price.shift(skip + look) - 1
            bills = rf_cum.shift(skip) / rf_cum.shift(skip + look) - 1
            rules[f"mom{look}skip{skip}>0"] = (past > 0).astype(float).where(past.notna())
            rules[f"mom{look}skip{skip}>bills"] = (past > bills).astype(float).where(past.notna())
    for start in range(1, 13):  # seasonal: out of the market for `length` months starting in `start`
        for length in range(1, 7):
            out_months = {(start - 1 + j) % 12 + 1 for j in range(length)}
            nxt = np.roll(month, -1)  # calendar month of the month being traded
            rules[f"out_m{start}_len{length}"] = pd.Series([0.0 if m in out_months else 1.0 for m in nxt],
                                                           index=mkt.index)
    vol = total.abs()
    for k in (3, 6, 12):  # volatility filter: in the market when recent volatility is below its running median
        rv = vol.rolling(k).mean()
        rules[f"lowvol{k}"] = (rv < rv.expanding(60).median()).astype(float).where(rv.notna())

    base = pd.DataFrame(rules)
    contrarian = 1.0 - base
    contrarian.columns = [f"NOT[{c}]" for c in base.columns]
    signals = pd.concat([base, contrarian], axis=1)
    positions = signals.shift(1)  # decided at the end of month t, held in month t+1
    return positions


def hedged_returns(pos: pd.DataFrame, mkt: pd.DataFrame, fit_index) -> tuple[pd.DataFrame, pd.Series]:
    """Each rule's excess return minus beta times the market's, beta estimated on `fit_index`."""
    m = mkt["mkt_rf"]
    strat = pos.mul(m, axis=0)  # in the market: market excess return; in bills: 0
    mf, sf = m.loc[fit_index], strat.loc[fit_index]
    beta = ((sf.sub(sf.mean())).mul(mf - mf.mean(), axis=0)).sum() / ((mf - mf.mean()) ** 2).sum()
    return strat - np.outer(m.to_numpy(), beta.to_numpy()), beta


# ---------------------------------------------------------------------------
# Part A: the search
# ---------------------------------------------------------------------------


def _sr(x: np.ndarray) -> np.ndarray:
    return x.mean(axis=0) / x.std(axis=0, ddof=1)


def part_a(mkt: pd.DataFrame, split: str | None = None, warmup: int = 36, effective_method: str = "variance") -> dict:
    pos_all = build_rules(mkt)
    idx = mkt.index[warmup:]
    pos_all = pos_all.loc[idx].fillna(1.0)
    n = len(idx)
    cut = n // 2 if split is None else int(np.searchsorted(idx.astype(str), split, side="right"))
    is_idx, oos_idx = idx[:cut], idx[cut:]

    h_is, beta = hedged_returns(pos_all, mkt.loc[idx], is_idx)
    H = h_is.loc[is_idx].to_numpy()
    sr = _sr(H)
    T = H.shape[0]
    t = sr * math.sqrt(T)
    disc = apply_corrections(t, ALPHA)
    best = int(np.nanargmax(sr))
    name = pos_all.columns[best]

    # Deflated Sharpe ratio of the best rule, with the raw and effective number of trials.
    mom = moments(H[:, best])
    var_sr = float(np.var(sr, ddof=1))
    n_raw = H.shape[1]
    n_eff = effective_trials(H, effective_method)
    dsr_raw = deflated_sharpe(sr[best], T, n_raw, var_sr, mom["skewness"], mom["kurtosis"])
    dsr_eff = deflated_sharpe(sr[best], T, n_eff, var_sr, mom["skewness"], mom["kurtosis"])

    # After selection: re-estimate beta on the out-of-sample period so alpha is measured there.
    h_oos, _ = hedged_returns(pos_all, mkt.loc[idx], oos_idx)
    O = h_oos.loc[oos_idx].to_numpy()
    sr_oos = _sr(O)
    t_oos = sr_oos * math.sqrt(O.shape[0])

    rows = []
    for method, mask in disc.items():
        pos_mask = mask & (t > 0)
        rows.append({"method": method, "discoveries": int(pos_mask.sum()),
                     "includes_best": bool(mask[best]),
                     "mean_t_after": float(t_oos[pos_mask].mean()) if pos_mask.any() else float("nan"),
                     "share_positive_after": float((t_oos[pos_mask] > 0).mean()) if pos_mask.any() else float("nan")})
    order = np.argsort(-t)
    top = pd.DataFrame({"rule": pos_all.columns[order[:15]], "t_backtest": t[order[:15]],
                        "appraisal_backtest": sr[order[:15]] * math.sqrt(12),
                        "t_after": t_oos[order[:15]], "appraisal_after": sr_oos[order[:15]] * math.sqrt(12)})
    return {
        "n_rules": n_raw, "n_effective": n_eff, "backtest": (str(is_idx[0]), str(is_idx[-1]), T),
        "after": (str(oos_idx[0]), str(oos_idx[-1]), O.shape[0]),
        "sr": sr, "t": t, "t_oos": t_oos, "sr_oos": sr_oos, "best": best, "best_name": name,
        "best_t": float(t[best]), "best_appraisal": float(sr[best] * math.sqrt(12)),
        "best_t_after": float(t_oos[best]), "best_appraisal_after": float(sr_oos[best] * math.sqrt(12)),
        "best_skew": mom["skewness"], "best_kurt": mom["kurtosis"],
        "dsr_raw": dsr_raw, "dsr_eff": dsr_eff, "sr_variance": var_sr,
        "discoveries": pd.DataFrame(rows), "top": top, "corr_in_out": float(np.corrcoef(t, t_oos)[0, 1]),
        "hedged_full": hedged_returns(pos_all, mkt.loc[idx], idx)[0],
        "positions": pos_all, "index": idx, "cut": cut, "beta_best": float(beta.iloc[best]),
    }


# ---------------------------------------------------------------------------
# Part B: probability of backtest overfitting
# ---------------------------------------------------------------------------


def part_b(a: dict, n_blocks: int = 16) -> dict:
    return cscv_pbo(a["hedged_full"].to_numpy(), n_blocks=n_blocks)


# ---------------------------------------------------------------------------
# Part C: the hurdle
# ---------------------------------------------------------------------------


def part_c(years=(10, 25, 50), trials=(1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 5000, 10000)) -> pd.DataFrame:
    """Expected best annualized Sharpe ratio among N no-skill monthly strategies.

    Under the null with independent normal returns, the variance of a
    per-period Sharpe estimate is about 1/T.
    """
    rows = []
    for y in years:
        T = 12 * y
        for n in trials:
            rows.append({"years": y, "trials": n, "expected_best_sharpe": expected_max_sharpe(n, 1 / T) * math.sqrt(12)})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Part D: what corrections cost
# ---------------------------------------------------------------------------


def part_d(n_strategies: int = 1000, n_months: int = 600, share_true: float = 0.10, true_sharpe: float = 0.5,
           correlation: float = 0.0, n_reps: int = 200, seed: int = 0) -> pd.DataFrame:
    """False and missed discoveries when the truth is known.

    share_true of the strategies have an annualized Sharpe ratio of
    true_sharpe; the rest have none. `correlation` adds a common factor so
    strategies are correlated. Each repetition draws fresh returns.
    """
    rng = np.random.default_rng(seed)
    n_true = int(round(n_strategies * share_true))
    mu = np.zeros(n_strategies)
    mu[:n_true] = true_sharpe / math.sqrt(12)  # per-period Sharpe; returns have unit volatility
    acc: dict[str, list] = {}
    for _ in range(n_reps):
        common = rng.standard_normal((n_months, 1))
        eps = rng.standard_normal((n_months, n_strategies))
        R = mu + math.sqrt(correlation) * common + math.sqrt(1 - correlation) * eps
        t = _sr(R) * math.sqrt(n_months)
        for method, mask in apply_corrections(t, ALPHA).items():
            d = int(mask.sum())
            false = int(mask[n_true:].sum())
            acc.setdefault(method, []).append((false / d if d else 0.0, mask[:n_true].mean() if n_true else np.nan,
                                               d, false))
    rows = []
    for method, vals in acc.items():
        v = np.array(vals, dtype=float)
        rows.append({"method": method, "false_discovery_rate": v[:, 0].mean(), "power": v[:, 1].mean(),
                     "avg_discoveries": v[:, 2].mean(), "avg_false_discoveries": v[:, 3].mean()})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------


def _sub(sim: bool, text: str) -> str:
    return text + ("  ·  SIMULATED DATA: tests the code only" if sim else "")


def fig_search(a: dict, out: Path, sim: bool):
    fig, ax, plt = plots.new_figure()
    ar = a["sr"] * math.sqrt(12)
    bins = np.linspace(min(ar.min(), -0.6), max(ar.max(), 0.6) + 0.02, 50)
    ax.hist(ar, bins=bins, color=plots.BLUE, edgecolor=plots.SURFACE, linewidth=0.8)
    sr0_raw = a["dsr_raw"]["sr0"] * math.sqrt(12)
    sr0_eff = a["dsr_eff"]["sr0"] * math.sqrt(12)
    for x, label, style in ((sr0_raw, f"Luck hurdle, best of {a['n_rules']} rules: {sr0_raw:.2f}", (0, (5, 3))),
                            (sr0_eff, f"Luck hurdle, best of {a['n_effective']:.0f} effective: {sr0_eff:.2f}",
                             (0, (1.5, 2)))):
        ax.axvline(x, color=plots.INK_2, linewidth=1.4, linestyle=style, label=label)
    ax.legend(loc="upper right", frameon=True, facecolor=plots.SURFACE, edgecolor=plots.GRID, fontsize=8.5)
    ax.set_xlim(right=max(sr0_raw, ar.max()) + 0.75)
    ax.annotate(f"best rule\n{a['best_appraisal']:.2f}", (a["best_appraisal"], 0), xytext=(0, 40),
                textcoords="offset points", ha="center", fontsize=9, color=plots.INK,
                arrowprops={"arrowstyle": "-", "color": plots.ORANGE, "lw": 1.5})
    ax.set_xlabel("Annualized appraisal ratio in the backtest (Sharpe ratio of the market-hedged return)")
    ax.set_ylabel("Number of rules")
    bt = a["backtest"]
    plots.titles(fig, f"Figure 4.1  {a['n_rules']} timing rules, and how high luck alone would reach",
                 _sub(sim, f"Backtest {bt[0]} to {bt[1]} · dashed lines: Sharpe ratio expected from the best of N "
                           "rules with no skill (Bailey and López de Prado)"))
    plots.finish(fig, out / "fig4_1_rule_search.png")
    plt.close(fig)


def fig_discoveries(a: dict, out: Path, sim: bool):
    fig, ax, plt = plots.new_figure()
    d = a["discoveries"]
    y = np.arange(len(d))[::-1]
    ax.barh(y, d["discoveries"], color=[plots.ORANGE if i == 0 else plots.BLUE for i in range(len(d))], height=0.6)
    for yi, (_, r) in zip(y, d.iterrows()):
        after = "" if pd.isna(r.mean_t_after) else f"   later t: {r.mean_t_after:+.2f} on average"
        ax.text(r.discoveries + max(d["discoveries"].max() * 0.01, 0.3), yi, f"{int(r.discoveries)}{after}",
                va="center", fontsize=9, color=plots.INK)
    ax.set_yticks(y, d["method"], fontsize=9, color=plots.INK)
    ax.set_xlim(0, max(d["discoveries"].max() * 1.6, 3))
    ax.set_xlabel("Rules declared significant in the backtest")
    ax.grid(axis="x", color=plots.GRID, linewidth=0.8)
    ax.grid(axis="y", visible=False)
    plots.titles(fig, "Figure 4.2  How many 'discoveries' survive each correction?",
                 _sub(sim, "One-sided tests at 2.5% (equivalent to two-sided 5%) · 'later t': the discoveries' average "
                           "t-statistic in the second half of the sample"))
    plots.finish(fig, out / "fig4_2_discoveries.png")
    plt.close(fig)


def fig_hurdle(c: pd.DataFrame, a: dict, out: Path, sim: bool):
    fig, ax, plt = plots.new_figure()
    colors = {10: plots.RED, 25: plots.ORANGE, 50: plots.BLUE}
    for y, g in c.groupby("years"):
        ax.plot(g["trials"], g["expected_best_sharpe"], color=colors.get(y, plots.VIOLET), linewidth=2, marker="o",
                markersize=5, markeredgecolor=plots.SURFACE)
        ax.text(g["trials"].iloc[-1] * 1.25, g["expected_best_sharpe"].iloc[-1], f"{y}-year backtest", va="center",
                fontsize=9, color=plots.INK)
    ax.set_xscale("log")
    ax.set_xlim(0.8, c["trials"].max() * 6)
    ax.set_xlabel("Number of strategies tried (log scale)")
    ax.set_ylabel("Expected best annualized Sharpe ratio, no skill")
    plots.titles(fig, "Figure 4.3  The Sharpe ratio luck can buy",
                 _sub(sim, "Expected maximum Sharpe ratio among N independent monthly strategies with no skill · "
                           "more tries and shorter backtests raise it"))
    plots.finish(fig, out / "fig4_3_hurdle.png")
    plt.close(fig)


def fig_pbo(b: dict, out: Path, sim: bool):
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(10, 4.4))
    fig.patch.set_facecolor(plots.SURFACE)
    ax = axes[0]
    plots.style_axes(ax)
    lg = b["logits"]
    bins = np.linspace(lg.min() - 0.1, lg.max() + 0.1, 40)
    ax.hist(lg[lg < 0], bins=bins, color=plots.RED, edgecolor=plots.SURFACE, linewidth=0.6)
    ax.hist(lg[lg >= 0], bins=bins, color=plots.BLUE, edgecolor=plots.SURFACE, linewidth=0.6)
    ax.axvline(0, color=plots.INK_3, linewidth=1)
    ax.set_xlabel("Logit of the in-sample winner's out-of-sample rank")
    ax.set_ylabel("Number of splits")
    ax.set_title(f"PBO = {b['pbo']:.0%} of {b['n_splits']:,} splits below the median", loc="left", fontsize=10,
                 color=plots.INK, pad=8)
    ax = axes[1]
    plots.style_axes(ax)
    ax.scatter(b["sr_in_best"] * math.sqrt(12), b["sr_out_best"] * math.sqrt(12), s=6, color=plots.BLUE, alpha=0.35,
               linewidths=0)
    ax.axhline(0, color=plots.INK_3, linewidth=1)
    ax.set_xlabel("Winner's Sharpe ratio, training half")
    ax.set_ylabel("Same rule, test half")
    ax.set_title("Performance after selection", loc="left", fontsize=10, color=plots.INK, pad=8)
    plots.titles(fig, "Figure 4.4  Probability of backtest overfitting (combinatorially symmetric cross-validation)",
                 _sub(sim, "Left: red = the rule chosen in training ranked below the median in testing · right: each dot "
                           "is one split (annualized appraisal ratios)"))
    plots.finish(fig, out / "fig4_4_pbo.png")
    plt.close(fig)


def fig_tradeoff(d: pd.DataFrame, out: Path, meta: dict):
    fig, ax, plt = plots.new_figure(8.5, 5.2)
    colors = [plots.RED, plots.YELLOW, plots.AQUA, plots.GREEN, plots.VIOLET, plots.BLUE]
    for (_, r), color in zip(d.iterrows(), colors):
        ax.plot(r.false_discovery_rate, r.power, "o", color=color, markersize=10, markeredgecolor=plots.SURFACE,
                markeredgewidth=2)
        dy = {"Holm": 7, "Bonferroni": -12, "t > 3": -10, "Benjamini-Hochberg": 4}.get(r.method, -3)
        ax.annotate(r.method, (r.false_discovery_rate, r.power), textcoords="offset points", xytext=(9, dy),
                    fontsize=9, color=plots.INK)
    ax.axvline(0.05, color=plots.INK_3, linewidth=1, linestyle=(0, (4, 3)))
    ax.text(0.05, 0.02, " 5% false discovery rate", fontsize=8.5, color=plots.INK_2, va="bottom")
    plots.percent_axis(ax, "x")
    plots.percent_axis(ax)
    ax.set_xlim(-0.01, max(0.12, d["false_discovery_rate"].max() * 1.35))
    ax.set_ylim(0, 1.0)
    ax.set_xlabel("False discovery rate (share of discoveries that are false)")
    ax.set_ylabel("Power (share of good strategies found)")
    ax.grid(axis="x", color=plots.GRID, linewidth=0.8)
    plots.titles(fig, "Figure 4.5  Every correction trades false discoveries for missed ones",
                 f"Simulation with known truth: {meta['n']:,} strategies, {meta['share']:.0%} with true Sharpe ratio "
                 f"{meta['sr']}, {meta['years']} years of monthly returns, {meta['reps']} repetitions")
    plots.finish(fig, out / "fig4_5_tradeoff.png")
    plt.close(fig)


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------


def _md(df: pd.DataFrame, fmt: dict) -> str:
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join("---" for _ in cols) + " |"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(fmt[c](r[c]) if c in fmt else str(r[c]) for c in cols) + " |")
    return "\n".join(lines)


def _num(spec):
    return lambda v: "" if (isinstance(v, float) and math.isnan(v)) else format(v, spec)


def write_report(out: Path, a, b, c, d, meta, sim: bool):
    md = ["# Lab 4 results: The Best of a Thousand Rules", ""]
    if sim:
        md += ["> **Simulated market data.** Parts A and B test that the code runs; they say nothing about real "
               "markets. Parts C and D are simulations by design.", ""]
    md += ["**Claim on trial:** a strategy that clears t = 2 after a search is a genuine discovery.", ""]
    bt, af = a["backtest"], a["after"]
    md += ["## Part A: The search", "",
           f"- {a['n_rules']} rules ({a['n_effective']:.0f} effective independent trials: the principal components that "
           f"explain 90% of the variance of their returns; half the rules are exact mirror images of the other half). Backtest {bt[0]} to {bt[1]} ({bt[2]} months); after selection {af[0]} to {af[1]} ({af[2]} months).",
           f"- Best rule: **{a['best_name']}**, backtest appraisal ratio {a['best_appraisal']:.2f} a year, "
           f"t = {a['best_t']:.2f} (skewness {a['best_skew']:.2f}, kurtosis {a['best_kurt']:.1f}).",
           f"- Deflated Sharpe ratio: {a['dsr_raw']['dsr']:.3f} with {a['n_rules']} trials; "
           f"{a['dsr_eff']['dsr']:.3f} with {a['n_effective']:.0f} effective trials. Values above 0.95 would count as "
           "significant after the search.",
           f"- After selection: appraisal ratio {a['best_appraisal_after']:.2f}, t = {a['best_t_after']:.2f}.",
           f"- Correlation between backtest and later t-statistics across all rules: {a['corr_in_out']:+.2f}.", "",
           _md(a["discoveries"].rename(columns={"method": "Method", "discoveries": "Discoveries",
                                                "includes_best": "Includes best rule",
                                                "mean_t_after": "Average t after selection",
                                                "share_positive_after": "Share positive after"}),
               {"Average t after selection": _num("+.2f"), "Share positive after": _num(".0%")}), "",
           "**The 15 best backtests, and what happened next**", "",
           _md(a["top"].rename(columns={"rule": "Rule", "t_backtest": "Backtest t", "appraisal_backtest": "Backtest AR",
                                        "t_after": "Later t", "appraisal_after": "Later AR"}),
               {"Backtest t": _num(".2f"), "Backtest AR": _num(".2f"), "Later t": _num("+.2f"),
                "Later AR": _num("+.2f")}), "",
           "AR = annualized appraisal ratio (Sharpe ratio of the market-hedged return).", "",
           "![Figure 4.1](fig4_1_rule_search.png)", "", "![Figure 4.2](fig4_2_discoveries.png)", ""]
    md += ["## Part B: Probability of backtest overfitting", "",
           f"- CSCV with {meta['blocks']} blocks: {b['n_splits']:,} splits of the full sample.",
           f"- PBO = {b['pbo']:.1%}: the share of splits in which the rule chosen in the training half ranked below the "
           "median rule in the test half. 50% means selection carries no information; below 50% means it does.",
           f"- Median out-of-sample appraisal ratio of the selected rule: {np.median(b['sr_out_best']) * math.sqrt(12):+.2f}.",
           "", "![Figure 4.4](fig4_4_pbo.png)", ""]
    piv = c.pivot(index="trials", columns="years", values="expected_best_sharpe").reset_index()
    piv.columns = ["Strategies tried"] + [f"{y}-year backtest" for y in piv.columns[1:]]
    md += ["## Part C: The Sharpe ratio luck can buy", "",
           _md(piv, {col: _num(".2f") for col in piv.columns[1:]} | {"Strategies tried": lambda v: f"{int(v):,}"}), "",
           "![Figure 4.3](fig4_3_hurdle.png)", ""]
    md += ["## Part D: What corrections cost (simulation, truth known)", "",
           f"{meta['n']:,} strategies; {meta['share']:.0%} have a true annualized Sharpe ratio of {meta['sr']}; "
           f"{meta['years']} years of monthly returns; correlation {meta['corr']}; {meta['reps']} repetitions.", "",
           _md(d.rename(columns={"method": "Method", "false_discovery_rate": "False discovery rate", "power": "Power",
                                 "avg_discoveries": "Discoveries", "avg_false_discoveries": "False discoveries"}),
               {"False discovery rate": _num(".1%"), "Power": _num(".1%"), "Discoveries": _num(".1f"),
                "False discoveries": _num(".1f")}), "",
           "![Figure 4.5](fig4_5_tradeoff.png)", ""]
    md += ["## Your verdict", "",
           "Does the best rule's t-statistic make it a discovery? Use the corrections, the deflated Sharpe ratio, the "
           "PBO and the after-selection result. Then use Part D to explain which correction you would apply if you were "
           "(a) choosing one strategy to fund and (b) screening a list for further research.", ""]
    (out / "lab04_report.md").write_text("\n".join(md))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", choices=["french", "sim"], default="french")
    ap.add_argument("--data-file", default=None, help="Fama/French 3 Factors (monthly) zip or CSV")
    ap.add_argument("--split", default=None, help="last month of the backtest (default: middle of the sample)")
    ap.add_argument("--effective-method", choices=["variance", "participation"], default="variance",
                    help="how to count effective trials for the deflated Sharpe ratio")
    ap.add_argument("--blocks", type=int, default=16, help="CSCV blocks (even; default 16)")
    ap.add_argument("--sim-strategies", type=int, default=1000, help="Part D")
    ap.add_argument("--sim-years", type=int, default=50, help="Part D")
    ap.add_argument("--sim-share-true", type=float, default=0.10, help="Part D")
    ap.add_argument("--sim-true-sharpe", type=float, default=0.5, help="Part D")
    ap.add_argument("--sim-correlation", type=float, default=0.0, help="Part D")
    ap.add_argument("--sim-reps", type=int, default=200, help="Part D")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--sim-seed", type=int, default=0, help="seed for simulated market data (--source sim)")
    ap.add_argument("--out", default=str(ROOT / "report"))
    return ap.parse_args(argv)


def run(args) -> dict:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    try:
        mkt = load_market(args.source, args.data_file, args.sim_seed)
    except DataUnavailable as e:
        raise SystemExit(str(e)) from None
    sim = mkt.attrs.get("simulated", False)

    a = part_a(mkt, args.split, effective_method=args.effective_method)
    b = part_b(a, args.blocks)
    c = part_c()
    d = part_d(args.sim_strategies, args.sim_years * 12, args.sim_share_true, args.sim_true_sharpe,
               args.sim_correlation, args.sim_reps, args.seed)
    meta = {"n": args.sim_strategies, "share": args.sim_share_true, "sr": args.sim_true_sharpe,
            "years": args.sim_years, "corr": args.sim_correlation, "reps": args.sim_reps,
            "blocks": args.blocks}

    fig_search(a, out, sim)
    fig_discoveries(a, out, sim)
    fig_hurdle(c, a, out, False)
    fig_pbo(b, out, sim)
    fig_tradeoff(d, out, meta)

    a["discoveries"].to_csv(out / "table_discoveries.csv", index=False)
    a["top"].to_csv(out / "table_top_rules.csv", index=False)
    pd.DataFrame({"rule": a["positions"].columns, "t_backtest": a["t"], "t_after": a["t_oos"],
                  "appraisal_backtest": a["sr"] * math.sqrt(12), "appraisal_after": a["sr_oos"] * math.sqrt(12)}
                 ).to_csv(out / "table_all_rules.csv", index=False)
    c.to_csv(out / "table_hurdle.csv", index=False)
    d.to_csv(out / "table_corrections_simulation.csv", index=False)
    pd.DataFrame({"logit": b["logits"], "sr_in_best": b["sr_in_best"], "sr_out_best": b["sr_out_best"]}).to_csv(
        out / "table_cscv_splits.csv", index=False)
    write_report(out, a, b, c, d, meta, sim)

    summary = {
        "simulated": sim, "n_rules": a["n_rules"], "n_effective": a["n_effective"], "best_rule": a["best_name"],
        "best_t": a["best_t"], "best_appraisal": a["best_appraisal"], "best_t_after": a["best_t_after"],
        "dsr_raw": a["dsr_raw"], "dsr_effective": a["dsr_eff"], "pbo": b["pbo"],
        "discoveries": a["discoveries"].to_dict(orient="records"), "corrections_simulation": d.to_dict(orient="records"),
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=float))

    print(f"A  {a['n_rules']} rules; best: {a['best_name']} (t = {a['best_t']:.2f}, appraisal {a['best_appraisal']:.2f})")
    print(f"   deflated Sharpe ratio {a['dsr_raw']['dsr']:.3f} ({a['n_rules']} trials), "
          f"{a['dsr_eff']['dsr']:.3f} ({a['n_effective']:.0f} effective); after selection t = {a['best_t_after']:.2f}")
    disc = a["discoveries"].set_index("method")["discoveries"]
    print("   discoveries: " + ", ".join(f"{k} {v}" for k, v in disc.items()))
    print(f"B  probability of backtest overfitting: {b['pbo']:.1%}")
    print(f"Report: {out / 'lab04_report.md'}")
    if sim:
        print("NOTE: simulated market data for Parts A and B. These results test the code only.")
    return summary


def main(argv=None):
    return run(parse_args(argv))


if __name__ == "__main__":
    main()
