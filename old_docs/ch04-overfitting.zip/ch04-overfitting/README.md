# Lab 4: The Best of a Thousand Rules

Companion lab for **Chapter 4** of *Financial Engineering and the Evidence: A Claim-Verify Approach to Quantitative Finance*.

**Claim on trial:** a strategy that clears t = 2 after a search is a genuine discovery.

## Quick start

```bash
pip install -r requirements.txt
python lab04.py
```

The first run downloads one file from the Kenneth R. French Data Library and caches it in `data/`. The lab then runs in well under a minute. Open `report/lab04_report.md` for the results.

For a guided version, open `lab04_walkthrough.ipynb` in Jupyter. It asks you to predict each result before you see it.

### If the download fails

Download **Fama/French 3 Factors** (`F-F_Research_Data_Factors_CSV.zip`) from the [Kenneth R. French Data Library](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html) and save it in `data/`, or pass it directly:

```bash
python lab04.py --data-file F-F_Research_Data_Factors_CSV.zip
```

### Testing the code without real data

```bash
python lab04.py --source sim
```

**Results from simulated data are not evidence about markets;** the report and figures are labeled. The lab never switches to simulated data on its own.

## What the lab does

| Part | Question | Method | Output |
|---|---|---|---|
| A. The search | Does the best of ~950 timing rules hold up? | Backtest on the first half of the sample; six decision rules (none, t > 3, Benjamini–Hochberg, Benjamini–Yekutieli, Holm, Bonferroni); deflated Sharpe ratio with raw and effective trials; the second half of the sample as the out-of-sample check | Figures 4.1–4.2, tables |
| B. Overfitting | Does choosing the best backtest pick a better rule? | Probability of backtest overfitting by combinatorially symmetric cross-validation (16 blocks, 12,870 splits) | Figure 4.4 |
| C. The hurdle | What Sharpe ratio can luck buy? | Expected best Sharpe ratio among N no-skill strategies, for 10-, 25- and 50-year backtests | Figure 4.3 |
| D. The cost of corrections | What does each correction trade away? | Simulation with known truth: 1,000 strategies, 10% genuinely good; false discovery rate and power | Figure 4.5 |

### The rules

473 rules and their 473 contrarian mirror images, 946 in all. Each is either fully in the market or in Treasury bills, decided at the end of a month for the next month:

- price above its k-month moving average (k = 2–24), with bands of 0%, 1%, 2% and 5%
- fast moving average above slow moving average (all pairs with fast 1–12, slow up to 24)
- past 1–24-month return above zero or above the bill return, with and without skipping the latest month
- seasonal: out of the market for 1–6 months starting in any calendar month
- volatility filter: in the market when recent volatility is below its running median

### Design notes

- **Skill measure.** A rule's skill is its *hedged* return: its excess return minus beta times the market's. A rule that is always in the market scores exactly zero, and the t-statistic of the hedged return's mean is the t-statistic of the rule's alpha. Beta is estimated in the backtest for Part A and re-estimated in the second half for the out-of-sample check.
- **No look-ahead.** Every position uses data through the end of the previous month (a test checks this by shocking one month and confirming no earlier position changes). Rules are in the market during their warm-up, and the backtest starts after 36 months.
- **Tests.** One-sided at 2.5%, the same as the familiar two-sided 5% test (t > 1.96). Benjamini–Hochberg and Benjamini–Yekutieli control the false discovery rate at 2.5%; Holm and Bonferroni control the family-wise error rate at 2.5%.
- **Effective trials.** Contrarian rules are exact mirror images (their hedged returns are minus the originals'), and most trend rules are near copies of each other. The default effective number of trials is the number of principal components that explain 90% of the variance of the rules' backtest returns. `--effective-method participation` uses the participation ratio instead, which gives far smaller numbers. Both stand in for the clustering approach of López de Prado (2019); the choice is a judgment, and the deflated Sharpe ratio is sensitive to it (Exercise 2).
- **Deflated Sharpe ratio.** Bailey and López de Prado (2014), using the cross-sectional variance of the rules' Sharpe ratios and the best rule's skewness and kurtosis.
- **PBO.** Bailey, Borwein, López de Prado and Zhu (2017). The full sample (after warm-up) is cut into 16 equal blocks; within each split Sharpe ratios are computed on the raw hedged returns with full-sample betas.
- **Part C** assumes independent, normal monthly returns, so the variance of a Sharpe-ratio estimate is about 1/T.

## Options

```text
--source {french,sim}     real data (default) or simulated data for testing
--data-file PATH          Fama/French 3 Factors (monthly) zip or CSV
--split YYYY-MM           last month of the backtest (default: middle of the sample)
--effective-method {variance,participation}
--blocks S                CSCV blocks, even (default 16)
--sim-strategies N        Part D: number of strategies (default 1000)
--sim-years Y             Part D: years of monthly returns (default 50)
--sim-share-true X        Part D: share with genuine skill (default 0.10)
--sim-true-sharpe S       Part D: their annualized Sharpe ratio (default 0.5)
--sim-correlation R       Part D: correlation between strategies (default 0)
--sim-reps N              Part D: repetitions (default 200)
--seed N                  random seed for Part D (default 2026)
--sim-seed N              seed for simulated market data (--source sim)
--out DIR                 output folder (default report/)
```

## Outputs (`report/`)

- `lab04_report.md`: all results, with a "Your verdict" prompt
- `fig4_1_rule_search.png` to `fig4_5_tradeoff.png`
- `table_all_rules.csv`: every rule's backtest and later t-statistic and appraisal ratio
- `table_discoveries.csv`, `table_top_rules.csv`, `table_cscv_splits.csv`, `table_hurdle.csv`, `table_corrections_simulation.csv`
- `summary.json`: headline numbers for grading or automated checks

## Files

```text
ch04-overfitting/
├── README.md
├── requirements.txt
├── lab04.py                 # the lab: rules, parts A–D, figures, report
├── lab04_walkthrough.ipynb  # guided, step-by-step version
├── fintest/                 # the book's analysis module (Labs 1–4 subset)
│   ├── data.py              # French library download and parsing
│   ├── stats.py             # returns, Sharpe ratios, Newey–West
│   ├── inference.py         # stylized facts, standard errors, bootstrap, GRS, Fama–MacBeth
│   ├── multiple.py          # corrections, deflated Sharpe ratio, effective trials, CSCV
│   └── plots.py             # chart style
├── data/                    # downloaded files are cached here
└── tests/test_lab04.py      # runs offline
```

Run the tests with `python tests/test_lab04.py` (or `pytest tests/`).

## Verification status

| Part | Status |
|---|---|
| Bonferroni, Holm, Benjamini–Hochberg, Benjamini–Yekutieli | Tested against their textbook definitions on 50 random sets of p-values |
| Expected maximum Sharpe ratio | Tested against Monte Carlo for 10, 100 and 1,000 trials (within 4%) |
| Probabilistic and deflated Sharpe ratios | Tested: PSR = 0.5 at the benchmark; best of 1,000 noise strategies rarely passes the DSR |
| Effective trials | Tested: about 0.9 N for noise; duplicate and mirrored strategies add nothing |
| CSCV / PBO | Tested against a brute-force loop; PBO ≈ 50% for noise and near 0 with one real signal |
| Rules | Tested for look-ahead; contrarian mirrors cancel exactly |
| Part D | Tested: Benjamini–Hochberg keeps the false discovery rate under 5%; power ordered as expected |
| Full lab and notebook | Run end to end on simulated data |
| French library parser | Tested in earlier labs on files in the library's published layout; **confirm on the live file at first run** |
| Live download | Not tested from the build environment (network blocked); the error message explains the manual route |

## Exercises

1. Move the split with `--split 1963-06` and then `--split 2000-12`. Does the same family of rules win each time? Does the winner survive in the later sample?
2. Re-run with `--effective-method participation`. How much does the deflated Sharpe ratio change? Write one paragraph on who should choose the effective number of trials, and when.
3. Part D: re-run with `--sim-correlation 0.3`, then `--sim-share-true 0.01`. When does Benjamini–Hochberg lose control of the false discovery rate, and when does Benjamini–Yekutieli earn its cost?
4. Add 200 rules of your own (for example, the 10-month moving-average rule of Faber 2007 with different bands). Report how the best t-statistic, the hurdle and the PBO change. What does this say about adding "just a few more" variations?
5. Implement White's (2000) reality check with the stationary bootstrap from `fintest.inference` and apply it to the 946 rules. Compare its verdict with the deflated Sharpe ratio.

## Data citation

Kenneth R. French Data Library: Fama/French 3 Factors (monthly). https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html
