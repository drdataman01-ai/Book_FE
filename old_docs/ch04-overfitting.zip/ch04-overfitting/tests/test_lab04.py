"""Tests for Lab 4. Run with:  python tests/test_lab04.py   (or: pytest tests/)

Runs offline. The corrections are checked against their textbook
definitions, the expected maximum Sharpe ratio against Monte Carlo, CSCV
against a brute-force loop, the rules for look-ahead, and the full lab on
simulated data.
"""

from __future__ import annotations

import itertools
import sys
import tempfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fintest.multiple import (  # noqa: E402
    apply_corrections,
    benjamini_hochberg,
    benjamini_yekutieli,
    bonferroni,
    cscv_pbo,
    deflated_sharpe,
    effective_trials,
    expected_max_sharpe,
    holm,
    probabilistic_sharpe,
)


def _bh_definition(p, q):
    """Largest k with p_(k) <= k q / m; reject the k smallest."""
    m = len(p)
    ps = np.sort(p)
    ks = [k for k in range(1, m + 1) if ps[k - 1] <= k * q / m]
    if not ks:
        return np.zeros(m, bool)
    return p <= ps[max(ks) - 1]


def _holm_definition(p, alpha):
    m = len(p)
    ps = np.sort(p)
    k = 0
    while k < m and ps[k] <= alpha / (m - k):
        k += 1
    return p <= ps[k - 1] if k else np.zeros(m, bool)


def test_corrections_match_definitions():
    rng = np.random.default_rng(0)
    for _ in range(50):
        m = rng.integers(5, 200)
        p = np.concatenate([rng.uniform(0, 1, m), rng.uniform(0, 0.002, rng.integers(0, 10))])
        assert (benjamini_hochberg(p, 0.05) == _bh_definition(p, 0.05)).all()
        assert (holm(p, 0.05) == _holm_definition(p, 0.05)).all()
        assert (bonferroni(p, 0.05) == (p <= 0.05 / len(p))).all()
        c = np.sum(1 / np.arange(1, len(p) + 1))
        assert (benjamini_yekutieli(p, 0.05) == _bh_definition(p, 0.05 / c)).all()
        # Ordering: Bonferroni <= Holm <= BH, and BY <= BH.
        assert (bonferroni(p, 0.05) <= holm(p, 0.05)).all()
        assert (holm(p, 0.05) <= benjamini_hochberg(p, 0.05)).all()
        assert (benjamini_yekutieli(p, 0.05) <= benjamini_hochberg(p, 0.05)).all()


def test_uncorrected_threshold_is_196():
    d = apply_corrections(np.array([1.95, 1.97, 2.5, 3.1]), 0.025)
    assert list(d["No correction (t > 1.96)"]) == [False, True, True, True]
    assert list(d["t > 3"]) == [False, False, False, True]


def test_expected_max_sharpe_matches_monte_carlo():
    rng = np.random.default_rng(1)
    for n in (10, 100, 1000):
        sims = rng.standard_normal((4000, n)).max(axis=1)
        approx = expected_max_sharpe(n, 1.0)
        assert abs(approx - sims.mean()) / sims.mean() < 0.04, (n, approx, sims.mean())
    assert expected_max_sharpe(1, 1.0) == 0.0


def test_probabilistic_and_deflated_sharpe():
    assert abs(probabilistic_sharpe(0.1, 0.1, 600) - 0.5) < 1e-12
    assert probabilistic_sharpe(0.2, 0.0, 600) > 0.999
    # Negative skew and fat tails widen the uncertainty, lowering the PSR.
    assert probabilistic_sharpe(0.1, 0.0, 120, skew=-1, kurt=8) < probabilistic_sharpe(0.1, 0.0, 120)
    # The best of 1,000 noise strategies should rarely pass the DSR.
    rng = np.random.default_rng(2)
    passes = 0
    for _ in range(40):
        R = rng.standard_normal((240, 1000))
        sr = R.mean(0) / R.std(0, ddof=1)
        passes += deflated_sharpe(sr.max(), 240, 1000, sr.var(ddof=1))["dsr"] > 0.95
    assert passes <= 4


def test_effective_trials():
    rng = np.random.default_rng(3)
    X = rng.standard_normal((2000, 100))
    assert 80 <= effective_trials(X) <= 95
    assert 90 <= effective_trials(X, "participation") <= 100
    # Duplicated and mirrored columns add no new trials.
    Y = np.hstack([X, X, -X])
    assert abs(effective_trials(Y) - effective_trials(X)) <= 2
    common = rng.standard_normal((2000, 1))
    Z = 0.95 * common + 0.31 * rng.standard_normal((2000, 100))
    assert effective_trials(Z, "participation") < 2


def _pbo_loop(R, S):
    T, N = R.shape
    L = T // S
    blocks = [R[i * L:(i + 1) * L] for i in range(S)]
    logits = []
    for c in itertools.combinations(range(S), S // 2):
        tr = np.vstack([blocks[i] for i in c])
        te = np.vstack([blocks[i] for i in range(S) if i not in c])
        sr_tr = tr.mean(0) / tr.std(0)
        sr_te = te.mean(0) / te.std(0)
        b = sr_tr.argmax()
        rank = (sr_te < sr_te[b]).sum() + 1
        w = rank / (N + 1)
        logits.append(np.log(w / (1 - w)))
    return np.mean(np.array(logits) < 0), np.array(logits)


def test_cscv_matches_loop_and_behaves():
    rng = np.random.default_rng(4)
    R = rng.standard_normal((240, 30))
    pbo, logits = _pbo_loop(R, 8)
    res = cscv_pbo(R, n_blocks=8)
    assert abs(res["pbo"] - pbo) < 1e-12 and np.allclose(np.sort(res["logits"]), np.sort(logits))
    noise = np.mean([cscv_pbo(rng.standard_normal((480, 50)), 10)["pbo"] for _ in range(10)])
    assert 0.35 < noise < 0.65
    signal = rng.standard_normal((480, 50))
    signal[:, 0] += 0.4
    assert cscv_pbo(signal, 10)["pbo"] < 0.05


def test_rules_have_no_look_ahead_and_mirrors_cancel():
    import lab04
    from fintest.data import simulated_market

    m = lab04.load_market("sim")
    pos = lab04.build_rules(m)
    k = 600
    m2 = m.copy()
    m2.iloc[k, m2.columns.get_loc("mkt_rf")] += 0.5  # a huge shock in month k
    pos2 = lab04.build_rules(m2)
    # Positions up to and including month k cannot know about month k's return.
    assert pos.iloc[:k + 1].fillna(-1).equals(pos2.iloc[:k + 1].fillna(-1))
    assert not pos.iloc[k + 1:].fillna(-1).equals(pos2.iloc[k + 1:].fillna(-1))
    # A contrarian rule's hedged return is exactly minus the original's.
    p = pos.iloc[36:].fillna(1.0)
    h, _ = lab04.hedged_returns(p, m.iloc[36:], m.index[36:400])
    assert np.allclose(h["NOT[MA3>MA12]"], -h["MA3>MA12"])
    assert len(pos.columns) % 2 == 0 and simulated_market is not None


def test_part_d_controls_false_discoveries():
    import lab04

    d = lab04.part_d(n_strategies=400, n_months=600, n_reps=40, seed=5).set_index("method")
    assert d.loc["No correction (t > 1.96)", "false_discovery_rate"] > 0.1
    assert d.loc["Benjamini-Hochberg", "false_discovery_rate"] < 0.05
    assert d.loc["Bonferroni", "power"] <= d.loc["Benjamini-Hochberg", "power"] <= d.loc[
        "No correction (t > 1.96)", "power"]


def test_full_lab_runs_on_simulated_data():
    import lab04

    with tempfile.TemporaryDirectory() as tmp:
        summary = lab04.main(["--source", "sim", "--sim-reps", "20", "--blocks", "10", "--out", tmp])
        out = Path(tmp)
        assert len(list(out.glob("fig4_*.png"))) == 5
        report = (out / "lab04_report.md").read_text()
        assert "Simulated market data" in report and "Your verdict" in report
        assert summary["simulated"] is True and summary["n_rules"] > 900
        assert 0 <= summary["pbo"] <= 1


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print(f"ok  {name}")
