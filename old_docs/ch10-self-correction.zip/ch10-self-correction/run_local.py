"""Run Lab 10 without Inspect.

Use this to test the pipeline with a simulated model, or to run the lab on
any OpenAI-compatible endpoint (including local models via Ollama).

Examples
--------
Smoke test with the simulated model (no API key, about a minute):
    python run_local.py --backend sim --model sim-standard --epochs 3

A local model through Ollama:
    python run_local.py --backend openai --base-url http://localhost:11434/v1 \\
        --model qwen2.5-coder:7b --epochs 10

OpenAI:
    export OPENAI_API_KEY=...
    python run_local.py --backend openai --base-url https://api.openai.com/v1 \\
        --model <model-name> --epochs 10

Each run writes one JSON line per (task, condition, epoch) to
results/<model>.jsonl. Analyse with:
    python analysis.py results/*.jsonl --out report/
"""

from __future__ import annotations

import argparse
import asyncio
import json
import re
import sys
import time
from pathlib import Path

from selfcorrect.backends import PROFILES, OpenAICompatLLM, SimulatedLLM
from selfcorrect.conditions import CONDITIONS, Settings, run_condition
from selfcorrect.execution import LocalExecutor
from selfcorrect.tasks import load_tasks

ROOT = Path(__file__).resolve().parent


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--backend", choices=["sim", "openai"], default="sim")
    ap.add_argument("--model", default="sim-standard",
                    help=f"model name; for --backend sim one of {sorted(PROFILES)}")
    ap.add_argument("--base-url", default="https://api.openai.com/v1")
    ap.add_argument("--api-key-env", default="OPENAI_API_KEY")
    ap.add_argument("--task-types", default="coding,math")
    ap.add_argument("--sources", default="fresh", help="fresh, public, or fresh,public")
    ap.add_argument("--conditions", default="A,B,C,D,E")
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--max-rounds", type=int, default=2)
    ap.add_argument("--vote-k", type=int, default=8)
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--max-tokens", type=int, default=2048)
    ap.add_argument("--limit", type=int, default=None, help="max tasks per task file")
    ap.add_argument("--concurrency", type=int, default=8, help="task attempts run in parallel")
    ap.add_argument("--seed", type=int, default=0, help="simulated model only")
    ap.add_argument("--out", default=None, help="output JSONL (default results/<model>.jsonl)")
    ap.add_argument("--yes", action="store_true", help="skip the confirmation prompt for paid APIs")
    return ap.parse_args(argv)


def _slug(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", s)


async def main_async(args) -> Path:
    task_types = [t.strip() for t in args.task_types.split(",") if t.strip()]
    sources = [s.strip() for s in args.sources.split(",") if s.strip()]
    conditions = [c.strip().upper() for c in args.conditions.split(",") if c.strip()]
    for c in conditions:
        if c not in CONDITIONS:
            raise SystemExit(f"unknown condition {c}; choose from {', '.join(CONDITIONS)}")

    tasks = load_tasks(task_types, sources, limit=args.limit)
    settings = Settings(max_rounds=args.max_rounds, vote_k=args.vote_k, temperature=args.temperature)

    if args.backend == "sim":
        llm = SimulatedLLM(tasks, profile=args.model, seed=args.seed)
    else:
        llm = OpenAICompatLLM(args.model, args.base_url, args.api_key_env, max_tokens=args.max_tokens)

    jobs = [(t, c, e) for t in tasks for c in conditions for e in range(args.epochs)
            if not (c == "C" and t.task_type != "coding")]

    if args.backend == "openai" and not args.yes:
        est_calls = sum({"A": 1, "B": 1 + 2 * args.max_rounds, "C": 1 + args.max_rounds,
                         "D": 1 + 2 * args.max_rounds, "E": args.vote_k}[c] for _, c, _ in jobs)
        print(f"{len(jobs)} task attempts, up to about {est_calls} model calls on {args.model}.")
        if input("Continue? [y/N] ").strip().lower() != "y":
            raise SystemExit("cancelled")

    out = Path(args.out) if args.out else ROOT / "results" / f"{_slug(args.model)}.jsonl"
    out.parent.mkdir(parents=True, exist_ok=True)
    executor = LocalExecutor(max_parallel=args.concurrency)
    sem = asyncio.Semaphore(args.concurrency)
    done = 0
    start = time.time()

    with open(out, "w") as f:
        async def one(task, cond, epoch):
            nonlocal done
            async with sem:
                try:
                    rec = await run_condition(cond, task, llm, executor, settings, epoch)
                except Exception as e:  # noqa: BLE001 - record the failure and keep going
                    rec = {"task_id": task.id, "task_type": task.task_type, "source": task.source,
                           "condition": cond, "epoch": epoch, "error": f"{type(e).__name__}: {e}"}
            rec["model"] = args.model
            rec["backend"] = args.backend
            f.write(json.dumps(rec) + "\n")
            f.flush()
            done += 1
            if done % 25 == 0 or done == len(jobs):
                print(f"  {done}/{len(jobs)} attempts  ({time.time() - start:.0f}s)", file=sys.stderr)

        await asyncio.gather(*(one(t, c, e) for t, c, e in jobs))

    print(f"wrote {len(jobs)} records to {out}")
    if args.backend == "sim":
        print("NOTE: simulated model. These results test the pipeline; they say nothing about real models.")
    return out


def main(argv=None):
    return asyncio.run(main_async(parse_args(argv)))


if __name__ == "__main__":
    main()
