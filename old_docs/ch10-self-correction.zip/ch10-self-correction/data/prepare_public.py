"""Download public tasks for Lab 10 and convert them to the lab's format.

Public sets are used alongside the fresh ones so you can compare results on
tasks a model may have seen in training (public) with tasks it has not
(fresh). See Chapter 4 on contamination.

  coding: MBPP (sanitized test split). The first test is shown to the agent
          as the visible test; the rest are hidden.
  math:   GSM8K (test split). The final answer after '####' is the target.

Requires the Hugging Face `datasets` package:
    pip install datasets

Usage:
    python data/prepare_public.py --n 40 --seed 0
writes data/public_coding.jsonl and data/public_math.jsonl.
"""

from __future__ import annotations

import argparse
import json
import random
import re
from pathlib import Path

HERE = Path(__file__).parent


def _entry_point_name(code: str) -> str | None:
    m = re.search(r"^def\s+([A-Za-z_]\w*)\s*\(", code, flags=re.MULTILINE)
    return m.group(1) if m else None


def prepare_mbpp(n: int, rng: random.Random) -> list[dict]:
    from datasets import load_dataset

    ds = load_dataset("google-research-datasets/mbpp", "sanitized", split="test")
    rows = []
    for ex in ds:
        tests = list(ex["test_list"])
        entry = _entry_point_name(ex["code"])
        if len(tests) < 2 or entry is None:
            continue
        setup = (ex.get("test_imports") or [])
        prefix = "\n".join(setup) + "\n" if setup else ""
        rows.append({
            "id": f"mbpp-{ex['task_id']}",
            "task_type": "coding",
            "source": "public",
            "entry_point": entry,
            "prompt": (
                f"{ex['prompt'].strip()} Name the function `{entry}`. "
                f"It must pass tests like: {tests[0]}"
            ),
            "visible_tests": [prefix + tests[0]],
            "hidden_tests": [prefix + t for t in tests[1:]],
            "reference": ex["code"],
            "buggy": None,
        })
    rng.shuffle(rows)
    return rows[:n]


def prepare_gsm8k(n: int, rng: random.Random) -> list[dict]:
    from datasets import load_dataset

    ds = load_dataset("openai/gsm8k", "main", split="test")
    rows = []
    for i, ex in enumerate(ds):
        raw = ex["answer"].split("####")[-1].strip().replace(",", "")
        try:
            answer = float(raw)
        except ValueError:
            continue
        rows.append({
            "id": f"gsm8k-{i}",
            "task_type": "math",
            "source": "public",
            "question": ex["question"],
            "answer": answer,
        })
    rng.shuffle(rows)
    return rows[:n]


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--n", type=int, default=20, help="tasks per set (default 20, matching the fresh sets)")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    rng = random.Random(args.seed)

    for name, rows in (("public_coding", prepare_mbpp(args.n, rng)),
                       ("public_math", prepare_gsm8k(args.n, rng))):
        path = HERE / f"{name}.jsonl"
        with open(path, "w") as f:
            for row in rows:
                f.write(json.dumps(row) + "\n")
        print(f"wrote {len(rows)} tasks to {path}")


if __name__ == "__main__":
    main()
