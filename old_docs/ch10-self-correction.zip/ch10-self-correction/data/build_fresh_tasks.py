"""Build and validate the fresh task sets for Lab 10.

Fresh tasks were written for this book rather than taken from a public
benchmark, so they are less likely to appear in a model's training data
(see Chapter 4 on contamination). Running this script:

  1. checks every coding task's reference solution passes all its tests,
  2. checks every coding task's buggy solution fails at least one hidden test,
  3. recomputes every math answer from its worked expression,
  4. writes data/fresh_coding.jsonl and data/fresh_math.jsonl.

The buggy solutions are used only by the simulated (mock) model, so the
whole pipeline can be tested without an API key.

Usage:  python data/build_fresh_tasks.py
"""

from __future__ import annotations

import json
import math
import textwrap
from pathlib import Path

HERE = Path(__file__).parent

# ---------------------------------------------------------------------------
# Coding tasks
# Each task: id, entry_point, prompt, visible_tests, hidden_tests,
# reference (correct solution), buggy (plausible wrong solution).
# Visible tests may be shown to the agent (condition C); hidden tests decide
# correctness and are never shown.
# ---------------------------------------------------------------------------

CODING = [
    dict(
        id="code-01-merge-intervals",
        entry_point="merge_intervals",
        prompt=(
            "Write a Python function `merge_intervals(intervals)` that takes a list of "
            "[start, end] pairs of integers (start <= end) in any order and returns a new "
            "list of merged intervals sorted by start. Intervals that overlap or touch "
            "(for example [1, 3] and [3, 5]) must be merged. An empty input returns []."
        ),
        visible_tests=[
            "assert merge_intervals([[1, 3], [2, 6], [8, 10]]) == [[1, 6], [8, 10]]",
        ],
        hidden_tests=[
            "assert merge_intervals([]) == []",
            "assert merge_intervals([[1, 3], [3, 5]]) == [[1, 5]]",
            "assert merge_intervals([[5, 7], [1, 2]]) == [[1, 2], [5, 7]]",
            "assert merge_intervals([[1, 10], [2, 3], [4, 5]]) == [[1, 10]]",
            "assert merge_intervals([[2, 2]]) == [[2, 2]]",
        ],
        reference='''
            def merge_intervals(intervals):
                out = []
                for s, e in sorted(intervals, key=lambda p: p[0]):
                    if out and s <= out[-1][1]:
                        out[-1][1] = max(out[-1][1], e)
                    else:
                        out.append([s, e])
                return out
        ''',
        buggy='''
            def merge_intervals(intervals):
                out = []
                for s, e in sorted(intervals, key=lambda p: p[0]):
                    if out and s < out[-1][1]:
                        out[-1][1] = max(out[-1][1], e)
                    else:
                        out.append([s, e])
                return out
        ''',
    ),
    dict(
        id="code-02-parse-duration",
        entry_point="parse_duration",
        prompt=(
            "Write a Python function `parse_duration(text)` that converts a duration string "
            "such as '1h30m15s', '45m', '2h' or '90s' into a total number of seconds (int). "
            "Units are h, m and s, each appearing at most once and always in that order. "
            "Surrounding whitespace is ignored. Raise ValueError for an empty string or any "
            "string that does not match this format."
        ),
        visible_tests=[
            "assert parse_duration('1h30m15s') == 5415",
        ],
        hidden_tests=[
            "assert parse_duration('45m') == 2700",
            "assert parse_duration(' 2h ') == 7200",
            "assert parse_duration('90s') == 90",
            "assert parse_duration('1h5s') == 3605",
            (
                "try:\n    parse_duration('')\n    raise AssertionError('no error')\n"
                "except ValueError:\n    pass"
            ),
            (
                "try:\n    parse_duration('5m1h')\n    raise AssertionError('no error')\n"
                "except ValueError:\n    pass"
            ),
        ],
        reference='''
            import re

            def parse_duration(text):
                t = text.strip()
                m = re.fullmatch(r"(?:(\\d+)h)?(?:(\\d+)m)?(?:(\\d+)s)?", t)
                if not t or m is None:
                    raise ValueError("bad duration")
                h, mi, s = (int(g) if g else 0 for g in m.groups())
                return h * 3600 + mi * 60 + s
        ''',
        buggy='''
            import re

            def parse_duration(text):
                t = text.strip()
                total = 0
                for num, unit in re.findall(r"(\\d+)([hms])", t):
                    total += int(num) * {"h": 3600, "m": 60, "s": 1}[unit]
                if total == 0:
                    raise ValueError("bad duration")
                return total
        ''',
    ),
    dict(
        id="code-03-excel-column",
        entry_point="column_title",
        prompt=(
            "Write a Python function `column_title(n)` that converts a positive integer "
            "to its spreadsheet column title: 1 -> 'A', 26 -> 'Z', 27 -> 'AA', 28 -> 'AB', "
            "702 -> 'ZZ', 703 -> 'AAA'. Raise ValueError if n < 1."
        ),
        visible_tests=["assert column_title(28) == 'AB'"],
        hidden_tests=[
            "assert column_title(1) == 'A'",
            "assert column_title(26) == 'Z'",
            "assert column_title(52) == 'AZ'",
            "assert column_title(702) == 'ZZ'",
            "assert column_title(703) == 'AAA'",
            (
                "try:\n    column_title(0)\n    raise AssertionError('no error')\n"
                "except ValueError:\n    pass"
            ),
        ],
        reference='''
            def column_title(n):
                if n < 1:
                    raise ValueError("n must be >= 1")
                out = []
                while n > 0:
                    n, r = divmod(n - 1, 26)
                    out.append(chr(ord("A") + r))
                return "".join(reversed(out))
        ''',
        buggy='''
            def column_title(n):
                if n < 1:
                    raise ValueError("n must be >= 1")
                out = []
                while n > 0:
                    n, r = divmod(n, 26)
                    out.append(chr(ord("A") + r - 1) if r else "Z")
                return "".join(reversed(out))
        ''',
    ),
    dict(
        id="code-04-normalize-path",
        entry_point="normalize_path",
        prompt=(
            "Write a Python function `normalize_path(path)` that simplifies an absolute "
            "Unix-style path. Collapse repeated slashes, remove '.' segments, and resolve "
            "'..' by removing the previous segment ('..' at the root stays at the root). "
            "The result starts with '/', has no trailing slash unless it is the root '/'."
        ),
        visible_tests=["assert normalize_path('/a/./b/../../c/') == '/c'"],
        hidden_tests=[
            "assert normalize_path('/') == '/'",
            "assert normalize_path('/../') == '/'",
            "assert normalize_path('//home//user/') == '/home/user'",
            "assert normalize_path('/a/b/c/../..') == '/a'",
            "assert normalize_path('/a/.../b') == '/a/.../b'",
        ],
        reference='''
            def normalize_path(path):
                stack = []
                for part in path.split("/"):
                    if part in ("", "."):
                        continue
                    if part == "..":
                        if stack:
                            stack.pop()
                    else:
                        stack.append(part)
                return "/" + "/".join(stack)
        ''',
        buggy='''
            def normalize_path(path):
                stack = []
                for part in path.split("/"):
                    if part in ("", "."):
                        continue
                    if part.startswith(".."):
                        if stack:
                            stack.pop()
                    else:
                        stack.append(part)
                return "/" + "/".join(stack)
        ''',
    ),
    dict(
        id="code-05-version-compare",
        entry_point="compare_versions",
        prompt=(
            "Write a Python function `compare_versions(a, b)` that compares two dotted "
            "version strings made of non-negative integers, such as '1.10' and '1.9'. "
            "Return 1 if a > b, -1 if a < b, and 0 if they are equal. Compare numerically "
            "segment by segment; missing segments count as 0, so '1.0' equals '1'."
        ),
        visible_tests=["assert compare_versions('1.10', '1.9') == 1"],
        hidden_tests=[
            "assert compare_versions('1.0', '1') == 0",
            "assert compare_versions('1.0.0.1', '1') == 1",
            "assert compare_versions('0.9', '0.10') == -1",
            "assert compare_versions('2', '10') == -1",
            "assert compare_versions('3.01', '3.1') == 0",
        ],
        reference='''
            def compare_versions(a, b):
                pa = [int(x) for x in a.split(".")]
                pb = [int(x) for x in b.split(".")]
                n = max(len(pa), len(pb))
                pa += [0] * (n - len(pa))
                pb += [0] * (n - len(pb))
                return (pa > pb) - (pa < pb)
        ''',
        buggy='''
            def compare_versions(a, b):
                pa = [int(x) for x in a.split(".")]
                pb = [int(x) for x in b.split(".")]
                return (pa > pb) - (pa < pb)
        ''',
    ),
    dict(
        id="code-06-top-words",
        entry_point="top_words",
        prompt=(
            "Write a Python function `top_words(text, k)` that returns the k most frequent "
            "words in text as a list of lowercase strings. Words are maximal runs of letters "
            "a-z (case-insensitive); everything else separates words. Order by descending "
            "count, breaking ties alphabetically. If there are fewer than k distinct words, "
            "return them all."
        ),
        visible_tests=["assert top_words('the cat and the hat', 1) == ['the']"],
        hidden_tests=[
            "assert top_words('b a b a c', 2) == ['a', 'b']",
            "assert top_words('Hello, hello! HELLO world', 2) == ['hello', 'world']",
            "assert top_words('', 3) == []",
            "assert top_words(\"don't stop\", 3) == ['don', 'stop', 't']",
            "assert top_words('x y z', 5) == ['x', 'y', 'z']",
        ],
        reference='''
            import re
            from collections import Counter

            def top_words(text, k):
                words = re.findall(r"[a-z]+", text.lower())
                counts = Counter(words)
                ranked = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
                return [w for w, _ in ranked[:k]]
        ''',
        buggy='''
            import re
            from collections import Counter

            def top_words(text, k):
                words = re.findall(r"[a-z]+", text.lower())
                return [w for w, _ in Counter(words).most_common(k)]
        ''',
    ),
    dict(
        id="code-07-flatten-dict",
        entry_point="flatten_dict",
        prompt=(
            "Write a Python function `flatten_dict(d, sep='.')` that flattens a nested "
            "dictionary into a single-level dictionary whose keys are paths joined by sep. "
            "Only dict values are flattened; lists and other values are kept as they are. "
            "An empty nested dict produces no keys."
        ),
        visible_tests=[
            "assert flatten_dict({'a': {'b': 1}, 'c': 2}) == {'a.b': 1, 'c': 2}",
        ],
        hidden_tests=[
            "assert flatten_dict({}) == {}",
            "assert flatten_dict({'a': {'b': {'c': 3}}}, sep='/') == {'a/b/c': 3}",
            "assert flatten_dict({'a': [1, {'b': 2}]}) == {'a': [1, {'b': 2}]}",
            "assert flatten_dict({'a': {}, 'b': 1}) == {'b': 1}",
        ],
        reference='''
            def flatten_dict(d, sep="."):
                out = {}

                def walk(prefix, value):
                    if isinstance(value, dict):
                        for k, v in value.items():
                            walk(f"{prefix}{sep}{k}" if prefix else str(k), v)
                    else:
                        out[prefix] = value

                for k, v in d.items():
                    walk(str(k), v)
                return out
        ''',
        buggy='''
            def flatten_dict(d, sep="."):
                out = {}
                for k, v in d.items():
                    if isinstance(v, dict) and v:
                        for k2, v2 in flatten_dict(v, sep).items():
                            out[f"{k}{sep}{k2}"] = v2
                    else:
                        out[k] = v
                return out
        ''',
    ),
    dict(
        id="code-08-isbn13",
        entry_point="is_valid_isbn13",
        prompt=(
            "Write a Python function `is_valid_isbn13(s)` that returns True if s is a valid "
            "ISBN-13 and False otherwise. Hyphens and spaces may appear anywhere and are "
            "ignored. After removing them there must be exactly 13 digits, and the weighted "
            "sum (weights alternate 1, 3, 1, 3, ... starting from the first digit) must be "
            "divisible by 10."
        ),
        visible_tests=["assert is_valid_isbn13('978-0-306-40615-7') is True"],
        hidden_tests=[
            "assert is_valid_isbn13('9780306406158') is False",
            "assert is_valid_isbn13('978 0 306 40615 7') is True",
            "assert is_valid_isbn13('978-0-306-40615') is False",
            "assert is_valid_isbn13('97803064061X7') is False",
            "assert is_valid_isbn13('979-8-9907810-9-2') is True",
        ],
        reference='''
            def is_valid_isbn13(s):
                digits = s.replace("-", "").replace(" ", "")
                if len(digits) != 13 or not digits.isdigit():
                    return False
                total = sum(int(c) * (1 if i % 2 == 0 else 3) for i, c in enumerate(digits))
                return total % 10 == 0
        ''',
        buggy='''
            def is_valid_isbn13(s):
                digits = s.replace("-", "").replace(" ", "")
                if len(digits) != 13 or not digits.isdigit():
                    return False
                total = sum(int(c) * (3 if i % 2 == 0 else 1) for i, c in enumerate(digits))
                return total % 10 == 0
        ''',
    ),
    dict(
        id="code-09-spiral",
        entry_point="spiral_order",
        prompt=(
            "Write a Python function `spiral_order(matrix)` that returns the elements of a "
            "rectangular 2-D list in clockwise spiral order, starting at the top-left. The "
            "matrix may be empty ([]) or have rows of length zero; return [] in that case."
        ),
        visible_tests=[
            "assert spiral_order([[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [1, 2, 3, 6, 9, 8, 7, 4, 5]",
        ],
        hidden_tests=[
            "assert spiral_order([]) == []",
            "assert spiral_order([[]]) == []",
            "assert spiral_order([[1, 2, 3, 4]]) == [1, 2, 3, 4]",
            "assert spiral_order([[1], [2], [3]]) == [1, 2, 3]",
            "assert spiral_order([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]]) == [1, 2, 3, 4, 8, 12, 11, 10, 9, 5, 6, 7]",
        ],
        reference='''
            def spiral_order(matrix):
                out = []
                if not matrix or not matrix[0]:
                    return out
                top, bottom, left, right = 0, len(matrix) - 1, 0, len(matrix[0]) - 1
                while top <= bottom and left <= right:
                    for c in range(left, right + 1):
                        out.append(matrix[top][c])
                    for r in range(top + 1, bottom + 1):
                        out.append(matrix[r][right])
                    if top < bottom:
                        for c in range(right - 1, left - 1, -1):
                            out.append(matrix[bottom][c])
                    if left < right:
                        for r in range(bottom - 1, top, -1):
                            out.append(matrix[r][left])
                    top, bottom, left, right = top + 1, bottom - 1, left + 1, right - 1
                return out
        ''',
        buggy='''
            def spiral_order(matrix):
                out = []
                if not matrix or not matrix[0]:
                    return out
                top, bottom, left, right = 0, len(matrix) - 1, 0, len(matrix[0]) - 1
                while top <= bottom and left <= right:
                    for c in range(left, right + 1):
                        out.append(matrix[top][c])
                    for r in range(top + 1, bottom + 1):
                        out.append(matrix[r][right])
                    for c in range(right - 1, left - 1, -1):
                        out.append(matrix[bottom][c])
                    for r in range(bottom - 1, top, -1):
                        out.append(matrix[r][left])
                    top, bottom, left, right = top + 1, bottom - 1, left + 1, right - 1
                return out
        ''',
    ),
    dict(
        id="code-10-rle",
        entry_point="rle_encode",
        prompt=(
            "Write a Python function `rle_encode(s)` that run-length encodes a string: each "
            "maximal run of a repeated character becomes the character followed by the run "
            "length, e.g. 'aaabcc' -> 'a3b1c2'. Encoding is case-sensitive. The empty "
            "string encodes to ''."
        ),
        visible_tests=["assert rle_encode('aaabcc') == 'a3b1c2'"],
        hidden_tests=[
            "assert rle_encode('') == ''",
            "assert rle_encode('a') == 'a1'",
            "assert rle_encode('aAaa') == 'a1A1a2'",
            "assert rle_encode('zzzzzzzzzzzz') == 'z12'",
            "assert rle_encode('abab') == 'a1b1a1b1'",
        ],
        reference='''
            def rle_encode(s):
                out = []
                i = 0
                while i < len(s):
                    j = i
                    while j < len(s) and s[j] == s[i]:
                        j += 1
                    out.append(f"{s[i]}{j - i}")
                    i = j
                return "".join(out)
        ''',
        buggy='''
            def rle_encode(s):
                out = []
                i = 0
                while i < len(s):
                    j = i
                    while j < len(s) and s[j].lower() == s[i].lower():
                        j += 1
                    out.append(f"{s[i]}{j - i}")
                    i = j
                return "".join(out)
        ''',
    ),
    dict(
        id="code-11-business-days",
        entry_point="business_days",
        prompt=(
            "Write a Python function `business_days(start, end)` that takes two "
            "datetime.date objects and returns the number of weekdays (Monday to Friday) "
            "in the half-open range [start, end): start is counted, end is not. If end <= "
            "start, return 0. Holidays are ignored."
        ),
        visible_tests=[
            "import datetime as dt\nassert business_days(dt.date(2026, 10, 19), dt.date(2026, 10, 26)) == 5",
        ],
        hidden_tests=[
            "import datetime as dt\nassert business_days(dt.date(2026, 10, 24), dt.date(2026, 10, 26)) == 0",
            "import datetime as dt\nassert business_days(dt.date(2026, 10, 23), dt.date(2026, 10, 27)) == 2",
            "import datetime as dt\nassert business_days(dt.date(2026, 10, 26), dt.date(2026, 10, 26)) == 0",
            "import datetime as dt\nassert business_days(dt.date(2026, 10, 30), dt.date(2026, 10, 1)) == 0",
            "import datetime as dt\nassert business_days(dt.date(2026, 1, 1), dt.date(2027, 1, 1)) == 261",
        ],
        reference='''
            import datetime as dt

            def business_days(start, end):
                if end <= start:
                    return 0
                days = (end - start).days
                weeks, rem = divmod(days, 7)
                count = weeks * 5
                for i in range(rem):
                    if (start + dt.timedelta(days=i)).weekday() < 5:
                        count += 1
                return count
        ''',
        buggy='''
            import datetime as dt

            def business_days(start, end):
                if end <= start:
                    return 0
                count = 0
                d = start
                while d <= end:
                    if d.weekday() < 5:
                        count += 1
                    d += dt.timedelta(days=1)
                return count
        ''',
    ),
    dict(
        id="code-12-loan-payment",
        entry_point="monthly_payment",
        prompt=(
            "Write a Python function `monthly_payment(principal, annual_rate, years)` that "
            "returns the fixed monthly payment for a fully amortizing loan, rounded to 2 "
            "decimal places. annual_rate is a percentage (6 means 6% per year, compounded "
            "monthly). If annual_rate is 0, the payment is principal divided by the number "
            "of months."
        ),
        visible_tests=["assert monthly_payment(200000, 6, 30) == 1199.10"],
        hidden_tests=[
            "assert monthly_payment(12000, 0, 1) == 1000.00",
            "assert monthly_payment(10000, 12, 1) == 888.49",
            "assert monthly_payment(350000, 7.25, 15) == 3195.02",
            "assert monthly_payment(5000, 4.5, 5) == 93.22",
        ],
        reference='''
            def monthly_payment(principal, annual_rate, years):
                n = int(round(years * 12))
                r = annual_rate / 100 / 12
                if r == 0:
                    return round(principal / n, 2)
                return round(principal * r / (1 - (1 + r) ** -n), 2)
        ''',
        buggy='''
            def monthly_payment(principal, annual_rate, years):
                n = int(round(years * 12))
                r = annual_rate / 12
                if r == 0:
                    return round(principal / n, 2)
                return round(principal * r / (1 - (1 + r) ** -n), 2)
        ''',
    ),
    dict(
        id="code-13-word-wrap",
        entry_point="word_wrap",
        prompt=(
            "Write a Python function `word_wrap(text, width)` that greedily wraps text into "
            "a list of lines. Words are separated by any whitespace. Each line holds as many "
            "words as fit within width characters, joined by single spaces. A word longer "
            "than width goes on its own line without being split. Empty or all-whitespace "
            "text returns []."
        ),
        visible_tests=[
            "assert word_wrap('the quick brown fox', 10) == ['the quick', 'brown fox']",
        ],
        hidden_tests=[
            "assert word_wrap('', 5) == []",
            "assert word_wrap('   ', 5) == []",
            "assert word_wrap('a bb ccc', 4) == ['a bb', 'ccc']",
            "assert word_wrap('extraordinary day', 5) == ['extraordinary', 'day']",
            "assert word_wrap('one  two\\nthree', 9) == ['one two', 'three']",
            "assert word_wrap('ab cd', 5) == ['ab cd']",
        ],
        reference='''
            def word_wrap(text, width):
                lines, cur = [], ""
                for w in text.split():
                    if not cur:
                        cur = w
                    elif len(cur) + 1 + len(w) <= width:
                        cur += " " + w
                    else:
                        lines.append(cur)
                        cur = w
                if cur:
                    lines.append(cur)
                return lines
        ''',
        buggy='''
            def word_wrap(text, width):
                lines, cur = [], ""
                for w in text.split():
                    if not cur:
                        cur = w
                    elif len(cur) + 1 + len(w) < width:
                        cur += " " + w
                    else:
                        lines.append(cur)
                        cur = w
                if cur:
                    lines.append(cur)
                return lines
        ''',
    ),
    dict(
        id="code-14-islands",
        entry_point="count_islands",
        prompt=(
            "Write a Python function `count_islands(grid)` that counts islands in a list of "
            "equal-length strings made of '1' (land) and '0' (water). An island is a group of "
            "land cells connected horizontally or vertically (not diagonally). An empty grid "
            "has 0 islands. Do not modify the input."
        ),
        visible_tests=["assert count_islands(['110', '010', '001']) == 2"],
        hidden_tests=[
            "assert count_islands([]) == 0",
            "assert count_islands(['000']) == 0",
            "assert count_islands(['101', '010', '101']) == 5",
            "assert count_islands(['111', '101', '111']) == 1",
            "assert count_islands(['1' * 60] * 60) == 1",
        ],
        reference='''
            def count_islands(grid):
                if not grid:
                    return 0
                rows, cols = len(grid), len(grid[0])
                seen = set()
                count = 0
                for r in range(rows):
                    for c in range(cols):
                        if grid[r][c] == "1" and (r, c) not in seen:
                            count += 1
                            stack = [(r, c)]
                            seen.add((r, c))
                            while stack:
                                y, x = stack.pop()
                                for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                                    ny, nx = y + dy, x + dx
                                    if 0 <= ny < rows and 0 <= nx < cols and grid[ny][nx] == "1" and (ny, nx) not in seen:
                                        seen.add((ny, nx))
                                        stack.append((ny, nx))
                return count
        ''',
        buggy='''
            def count_islands(grid):
                if not grid:
                    return 0
                rows, cols = len(grid), len(grid[0])
                seen = set()
                count = 0
                for r in range(rows):
                    for c in range(cols):
                        if grid[r][c] == "1" and (r, c) not in seen:
                            count += 1
                            stack = [(r, c)]
                            seen.add((r, c))
                            while stack:
                                y, x = stack.pop()
                                for dy in (-1, 0, 1):
                                    for dx in (-1, 0, 1):
                                        ny, nx = y + dy, x + dx
                                        if 0 <= ny < rows and 0 <= nx < cols and grid[ny][nx] == "1" and (ny, nx) not in seen:
                                            seen.add((ny, nx))
                                            stack.append((ny, nx))
                return count
        ''',
    ),
    dict(
        id="code-15-dedupe",
        entry_point="dedupe",
        prompt=(
            "Write a Python function `dedupe(items)` that removes duplicate strings from a "
            "list, comparing case-insensitively and ignoring leading and trailing "
            "whitespace, and keeps the first occurrence exactly as it appeared (original "
            "case and spacing). The order of kept items is preserved."
        ),
        visible_tests=["assert dedupe(['Apple', 'apple', 'Banana']) == ['Apple', 'Banana']"],
        hidden_tests=[
            "assert dedupe([]) == []",
            "assert dedupe([' Kiwi', 'kiwi ', 'KIWI']) == [' Kiwi']",
            "assert dedupe(['b', 'a', 'B', 'A', 'c']) == ['b', 'a', 'c']",
            "assert dedupe(['x', 'x ', 'y']) == ['x', 'y']",
        ],
        reference='''
            def dedupe(items):
                seen = set()
                out = []
                for item in items:
                    key = item.strip().lower()
                    if key not in seen:
                        seen.add(key)
                        out.append(item)
                return out
        ''',
        buggy='''
            def dedupe(items):
                seen = set()
                out = []
                for item in items:
                    key = item.lower()
                    if key not in seen:
                        seen.add(key)
                        out.append(item)
                return out
        ''',
    ),
    dict(
        id="code-16-sliding-median",
        entry_point="sliding_median",
        prompt=(
            "Write a Python function `sliding_median(nums, k)` that returns the list of "
            "medians of every contiguous window of length k in nums, as floats. For even k "
            "the median is the mean of the two middle values. If k is larger than len(nums) "
            "or k < 1, return []."
        ),
        visible_tests=["assert sliding_median([1, 3, -1, -3, 5], 3) == [1.0, -1.0, -1.0]"],
        hidden_tests=[
            "assert sliding_median([1, 2, 3, 4], 2) == [1.5, 2.5, 3.5]",
            "assert sliding_median([5], 1) == [5.0]",
            "assert sliding_median([1, 2], 3) == []",
            "assert sliding_median([1, 2, 3], 0) == []",
            "assert sliding_median([4, 1, 7, 1], 4) == [2.5]",
        ],
        reference='''
            def sliding_median(nums, k):
                if k < 1 or k > len(nums):
                    return []
                out = []
                for i in range(len(nums) - k + 1):
                    w = sorted(nums[i:i + k])
                    if k % 2:
                        out.append(float(w[k // 2]))
                    else:
                        out.append((w[k // 2 - 1] + w[k // 2]) / 2)
                return out
        ''',
        buggy='''
            def sliding_median(nums, k):
                if k < 1 or k > len(nums):
                    return []
                out = []
                for i in range(len(nums) - k + 1):
                    w = sorted(nums[i:i + k])
                    out.append(float(w[k // 2]))
                return out
        ''',
    ),
    dict(
        id="code-17-next-permutation",
        entry_point="next_permutation",
        prompt=(
            "Write a Python function `next_permutation(seq)` that returns a new list holding "
            "the next lexicographic permutation of the integers in seq. If seq is already the "
            "last permutation (non-increasing), return the first permutation (sorted "
            "ascending). Do not modify the input. Duplicates are allowed."
        ),
        visible_tests=["assert next_permutation([1, 2, 3]) == [1, 3, 2]"],
        hidden_tests=[
            "assert next_permutation([3, 2, 1]) == [1, 2, 3]",
            "assert next_permutation([1, 1, 5]) == [1, 5, 1]",
            "assert next_permutation([1, 5, 1]) == [5, 1, 1]",
            "assert next_permutation([1, 5, 5]) == [5, 1, 5]",
            "assert next_permutation([2, 2, 1]) == [1, 2, 2]",
            "assert next_permutation([]) == []",
            "s = [2, 3, 1]\nassert next_permutation(s) == [3, 1, 2] and s == [2, 3, 1]",
        ],
        reference='''
            def next_permutation(seq):
                a = list(seq)
                i = len(a) - 2
                while i >= 0 and a[i] >= a[i + 1]:
                    i -= 1
                if i < 0:
                    return sorted(a)
                j = len(a) - 1
                while a[j] <= a[i]:
                    j -= 1
                a[i], a[j] = a[j], a[i]
                a[i + 1:] = reversed(a[i + 1:])
                return a
        ''',
        buggy='''
            def next_permutation(seq):
                a = list(seq)
                i = len(a) - 2
                while i >= 0 and a[i] > a[i + 1]:
                    i -= 1
                if i < 0:
                    return sorted(a)
                j = len(a) - 1
                while a[j] <= a[i]:
                    j -= 1
                a[i], a[j] = a[j], a[i]
                a[i + 1:] = reversed(a[i + 1:])
                return a
        ''',
    ),
    dict(
        id="code-18-balanced-substring",
        entry_point="longest_balanced",
        prompt=(
            "Write a Python function `longest_balanced(s)` that returns the length of the "
            "longest contiguous substring of s that is a balanced parenthesis string, where "
            "s contains only '(' and ')'. For example, ')()())' -> 4."
        ),
        visible_tests=["assert longest_balanced(')()())') == 4"],
        hidden_tests=[
            "assert longest_balanced('') == 0",
            "assert longest_balanced('(()') == 2",
            "assert longest_balanced('()(()') == 2",
            "assert longest_balanced('()(())') == 6",
            "assert longest_balanced(')(') == 0",
        ],
        reference='''
            def longest_balanced(s):
                stack = [-1]
                best = 0
                for i, ch in enumerate(s):
                    if ch == "(":
                        stack.append(i)
                    else:
                        stack.pop()
                        if not stack:
                            stack.append(i)
                        else:
                            best = max(best, i - stack[-1])
                return best
        ''',
        buggy='''
            def longest_balanced(s):
                best = cur = depth = 0
                for ch in s:
                    if ch == "(":
                        depth += 1
                    elif depth > 0:
                        depth -= 1
                        cur += 2
                        best = max(best, cur)
                    else:
                        cur = 0
                return best
        ''',
    ),
    dict(
        id="code-19-group-anagrams",
        entry_point="group_anagrams",
        prompt=(
            "Write a Python function `group_anagrams(words)` that groups words that are "
            "anagrams of each other (case-sensitive). Return a list of groups; sort the words "
            "inside each group alphabetically, and sort the groups by their first word."
        ),
        visible_tests=[
            "assert group_anagrams(['eat', 'tea', 'tan', 'ate', 'nat', 'bat']) == [['ate', 'eat', 'tea'], ['bat'], ['nat', 'tan']]",
        ],
        hidden_tests=[
            "assert group_anagrams([]) == []",
            "assert group_anagrams(['a']) == [['a']]",
            "assert group_anagrams(['ab', 'ba', 'Ab']) == [['Ab'], ['ab', 'ba']]",
            "assert group_anagrams(['x', 'x']) == [['x', 'x']]",
        ],
        reference='''
            def group_anagrams(words):
                groups = {}
                for w in words:
                    groups.setdefault("".join(sorted(w)), []).append(w)
                return sorted((sorted(g) for g in groups.values()), key=lambda g: g[0])
        ''',
        buggy='''
            def group_anagrams(words):
                groups = {}
                for w in words:
                    groups.setdefault("".join(sorted(w.lower())), []).append(w)
                return sorted((sorted(g) for g in groups.values()), key=lambda g: g[0])
        ''',
    ),
    dict(
        id="code-20-int-to-roman",
        entry_point="to_roman",
        prompt=(
            "Write a Python function `to_roman(n)` that converts an integer from 1 to 3999 "
            "to a Roman numeral using standard subtractive notation (4 -> 'IV', 9 -> 'IX', "
            "40 -> 'XL', 90 -> 'XC', 400 -> 'CD', 900 -> 'CM'). Raise ValueError outside "
            "that range."
        ),
        visible_tests=["assert to_roman(1994) == 'MCMXCIV'"],
        hidden_tests=[
            "assert to_roman(4) == 'IV'",
            "assert to_roman(3999) == 'MMMCMXCIX'",
            "assert to_roman(444) == 'CDXLIV'",
            "assert to_roman(58) == 'LVIII'",
            (
                "try:\n    to_roman(4000)\n    raise AssertionError('no error')\n"
                "except ValueError:\n    pass"
            ),
        ],
        reference='''
            def to_roman(n):
                if not 1 <= n <= 3999:
                    raise ValueError("out of range")
                table = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"),
                         (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]
                out = []
                for value, sym in table:
                    q, n = divmod(n, value)
                    out.append(sym * q)
                return "".join(out)
        ''',
        buggy='''
            def to_roman(n):
                if not 1 <= n <= 3999:
                    raise ValueError("out of range")
                table = [(1000, "M"), (900, "CM"), (500, "D"), (100, "C"), (90, "XC"),
                         (50, "L"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]
                out = []
                for value, sym in table:
                    q, n = divmod(n, value)
                    out.append(sym * q)
                return "".join(out)
        ''',
    ),
]

# ---------------------------------------------------------------------------
# Math word problems
# Each has a worked expression evaluated here, so the stored answer is
# computed rather than typed. Answers are numbers; the grader allows a
# tolerance of 0.01.
# ---------------------------------------------------------------------------

MATH = [
    dict(id="math-01-paint",
         question=("A room is 5 m long, 4 m wide and 2.5 m high. The walls (not the ceiling or "
                   "floor) need two coats of paint. There is one door of 2 m by 0.9 m and two "
                   "windows of 1.2 m by 1 m that are not painted. One litre of paint covers 10 "
                   "square metres. How many litres of paint are needed?"),
         expr="2 * (2 * (5 + 4) * 2.5 - 2 * 0.9 - 2 * 1.2 * 1) / 10"),
    dict(id="math-02-fence-posts",
         question=("A straight fence is 84 metres long. Posts are placed every 6 metres, "
                   "including one post at each end. Each post costs $18 and each 6-metre panel "
                   "between posts costs $45. What is the total cost in dollars?"),
         expr="(84 // 6 + 1) * 18 + (84 // 6) * 45"),
    dict(id="math-03-discount-tax",
         question=("A jacket is priced at $160. It is discounted by 25%, and then an extra 10% "
                   "is taken off the discounted price at checkout. Sales tax of 8% is applied to "
                   "the final discounted price. How much does the customer pay, in dollars?"),
         expr="160 * 0.75 * 0.90 * 1.08"),
    dict(id="math-04-train-meet",
         question=("Two trains start toward each other at 9:00 a.m. from stations 300 km "
                   "apart. One travels at 80 km/h and the other at 70 km/h, but the slower train "
                   "leaves 30 minutes later, at 9:30 a.m. How many minutes after 9:00 a.m. do "
                   "the trains meet?"),
         expr="(30 + (300 - 80 * 0.5) / (80 + 70) * 60)"),
    dict(id="math-05-workers",
         question=("Six workers can build a wall in 10 days. After 4 days of work, 2 of the "
                   "workers leave. Working at the same rate, how many more days do the remaining "
                   "workers need to finish the wall?"),
         expr="(6 * 10 - 6 * 4) / 4"),
    dict(id="math-06-savings",
         question=("Maya saves $40 in the first week. Each following week she saves $5 more "
                   "than the week before. How much has she saved in total after 12 weeks, in "
                   "dollars?"),
         expr="sum(40 + 5 * i for i in range(12))"),
    dict(id="math-07-mixture",
         question=("A 20-litre container holds a juice mixture that is 30% orange juice. How "
                   "many litres of pure orange juice must be added to make the mixture 50% "
                   "orange juice?"),
         expr="(0.5 * 20 - 0.3 * 20) / (1 - 0.5)"),
    dict(id="math-08-calendar",
         question=("A library opens on Monday and is open every day except Sunday. Books are "
                   "due 18 open days after checkout, counting the day after checkout as open "
                   "day 1. If a book is checked out on a Monday, how many calendar days later is "
                   "it due?"),
         expr="next(d for d in range(1, 60) if sum(1 for x in range(1, d + 1) if x % 7 != 6) == 18)"),
    dict(id="math-09-percent-change",
         question=("A share price rises 20% on Monday, falls 20% on Tuesday, and rises 10% on "
                   "Wednesday. What is the overall percentage change from Monday's opening price "
                   "to Wednesday's close? Give the answer as a percentage (for example, -3.5 for "
                   "a 3.5% fall)."),
         expr="(1.2 * 0.8 * 1.1 - 1) * 100"),
    dict(id="math-10-tank",
         question=("A tank holds 1,200 litres. Pipe A fills it in 6 hours, pipe B fills it in 4 "
                   "hours, and a drain empties a full tank in 12 hours. Starting empty, with "
                   "both pipes and the drain open, how many hours does it take to fill the "
                   "tank?"),
         expr="1 / (1/6 + 1/4 - 1/12)"),
    dict(id="math-11-ages",
         question=("Today a mother is 4 times as old as her son. In 20 years she will be twice "
                   "as old as her son. How old is the mother today?"),
         expr="4 * next(s for s in range(1, 100) if 4 * s + 20 == 2 * (s + 20))"),
    dict(id="math-12-tickets",
         question=("A theatre sold 420 tickets. Adult tickets cost $15 and child tickets cost "
                   "$9. Total sales were $5,400. How many child tickets were sold?"),
         expr="next(c for c in range(0, 421) if 15 * (420 - c) + 9 * c == 5400)"),
    dict(id="math-13-recipe",
         question=("A recipe for 6 servings uses 450 g of flour and 2.5 eggs on average. A baker "
                   "makes 40 servings but can only use whole eggs, rounding up. How many grams "
                   "of flour plus how many eggs does she use? Give the sum of the grams of flour "
                   "and the number of eggs."),
         expr="450 / 6 * 40 + math.ceil(2.5 / 6 * 40)"),
    dict(id="math-14-commission",
         question=("A salesperson earns a base pay of $2,000 per month plus 5% commission on "
                   "sales up to $40,000 and 8% on sales above $40,000. Her sales this month were "
                   "$65,000. What is her total pay for the month, in dollars?"),
         expr="2000 + 0.05 * 40000 + 0.08 * (65000 - 40000)"),
    dict(id="math-15-average",
         question=("The average of 8 test scores is 76. When the lowest score is dropped, the "
                   "average of the remaining 7 scores is 80. What was the lowest score?"),
         expr="8 * 76 - 7 * 80"),
    dict(id="math-16-clock",
         question=("What is the smaller angle, in degrees, between the hour and minute hands of "
                   "a clock at 3:40?"),
         expr="min(abs((3 * 30 + 40 * 0.5) - 40 * 6), 360 - abs((3 * 30 + 40 * 0.5) - 40 * 6))"),
    dict(id="math-17-shipping",
         question=("A courier charges $6 for the first kilogram and $2.50 for each additional "
                   "kilogram or part of a kilogram. How much does it cost, in dollars, to ship "
                   "three parcels weighing 0.8 kg, 3.2 kg and 5.0 kg separately?"),
         expr="sum(6 + 2.5 * max(0, math.ceil(w) - 1) for w in (0.8, 3.2, 5.0))"),
    dict(id="math-18-interest",
         question=("An investor deposits $5,000 at 4% annual interest compounded quarterly. "
                   "After 3 years she withdraws $1,000, and the rest stays invested on the same "
                   "terms for 2 more years. What is the balance after the full 5 years, in "
                   "dollars, rounded to the nearest cent?"),
         expr="round((5000 * (1 + 0.04/4) ** 12 - 1000) * (1 + 0.04/4) ** 8, 2)"),
    dict(id="math-19-handshakes",
         question=("At a meeting, every person shakes hands exactly once with every other "
                   "person, except that the 3 members of one family do not shake hands with each "
                   "other. There are 15 people in total. How many handshakes take place?"),
         expr="15 * 14 // 2 - 3"),
    dict(id="math-20-fuel",
         question=("A car uses 6.5 litres of fuel per 100 km on the highway and 9 litres per "
                   "100 km in the city. A trip covers 240 km on the highway and 45 km in the "
                   "city. Fuel costs $1.80 per litre. What is the fuel cost of the trip, in "
                   "dollars?"),
         expr="(240 * 6.5 / 100 + 45 * 9 / 100) * 1.80"),
]


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def _run(code: str, tests: list[str]) -> list[bool]:
    results = []
    for t in tests:
        ns: dict = {}
        try:
            exec(textwrap.dedent(code), ns)  # noqa: S102 - trusted, author-written code
            exec(t, ns)  # noqa: S102
            results.append(True)
        except Exception:  # noqa: BLE001
            results.append(False)
    return results


def build() -> None:
    coding_rows = []
    for task in CODING:
        ref = textwrap.dedent(task["reference"]).strip() + "\n"
        bug = textwrap.dedent(task["buggy"]).strip() + "\n"
        all_tests = task["visible_tests"] + task["hidden_tests"]
        ref_ok = _run(ref, all_tests)
        if not all(ref_ok):
            failed = [t for t, ok in zip(all_tests, ref_ok) if not ok]
            raise SystemExit(f"{task['id']}: reference fails {failed}")
        bug_hidden = _run(bug, task["hidden_tests"])
        if all(bug_hidden):
            raise SystemExit(f"{task['id']}: buggy solution passes every hidden test")
        bug_visible = _run(bug, task["visible_tests"])
        coding_rows.append({
            "id": task["id"],
            "task_type": "coding",
            "source": "fresh",
            "entry_point": task["entry_point"],
            "prompt": task["prompt"],
            "visible_tests": task["visible_tests"],
            "hidden_tests": task["hidden_tests"],
            "reference": ref,
            "buggy": bug,
            "buggy_passes_visible": all(bug_visible),
        })

    math_rows = []
    for p in MATH:
        answer = eval(p["expr"], {"math": math})  # noqa: S307 - trusted expressions
        math_rows.append({
            "id": p["id"],
            "task_type": "math",
            "source": "fresh",
            "question": p["question"],
            "answer": round(float(answer), 4),
            "worked_expression": p["expr"],
        })

    with open(HERE / "fresh_coding.jsonl", "w") as f:
        for row in coding_rows:
            f.write(json.dumps(row) + "\n")
    with open(HERE / "fresh_math.jsonl", "w") as f:
        for row in math_rows:
            f.write(json.dumps(row) + "\n")

    n_vis = sum(r["buggy_passes_visible"] for r in coding_rows)
    print(f"coding tasks: {len(coding_rows)} (buggy solution passes visible tests in {n_vis})")
    print(f"math problems: {len(math_rows)}")
    for r in math_rows:
        print(f"  {r['id']}: {r['answer']}")


if __name__ == "__main__":
    build()
