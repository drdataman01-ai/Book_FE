"""Check the Inspect glue code (inspect_tasks.py) without installing Inspect.

If Inspect is not installed, this test injects a minimal stand-in for the
parts of its API the lab uses, then runs the solver and scorer with the
simulated model and a local "sandbox". It checks the lab's own wiring, not
Inspect itself: confirm with one real `inspect eval` run on your machine.
If Inspect is installed, the test is skipped.
"""

from __future__ import annotations

import asyncio
import importlib.util
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def _install_stub(llm, local_executor):
    from dataclasses import dataclass, field

    from selfcorrect.execution import HARNESS

    def passthrough_decorator(*dargs, **dkwargs):
        if dargs and callable(dargs[0]) and not dkwargs:
            return dargs[0]
        return lambda fn: fn

    root = types.ModuleType("inspect_ai")

    @dataclass
    class Task:
        dataset: object
        solver: object
        scorer: object
        sandbox: object = None
        metadata: dict = field(default_factory=dict)

    root.Task, root.task = Task, passthrough_decorator
    root.eval = lambda *a, **k: None

    dataset = types.ModuleType("inspect_ai.dataset")

    @dataclass
    class Sample:
        input: str
        target: str
        id: str
        metadata: dict

    class MemoryDataset(list):
        def __init__(self, samples, name=None):
            super().__init__(samples)
            self.name = name

    dataset.Sample, dataset.MemoryDataset = Sample, MemoryDataset

    model = types.ModuleType("inspect_ai.model")

    @dataclass
    class _Msg:
        content: str
        role: str = ""

    class ChatMessageSystem(_Msg):
        def __init__(self, content):
            super().__init__(content, "system")

    class ChatMessageUser(_Msg):
        def __init__(self, content):
            super().__init__(content, "user")

    class ChatMessageAssistant(_Msg):
        def __init__(self, content):
            super().__init__(content, "assistant")

    @dataclass
    class GenerateConfig:
        temperature: float = 0.0

    @dataclass
    class Usage:
        input_tokens: int
        output_tokens: int

    @dataclass
    class Output:
        completion: str
        usage: Usage

    class FakeModel:
        async def generate(self, chat, config):
            msgs = [{"role": m.role, "content": m.content} for m in chat]
            c = await llm(msgs, temperature=config.temperature, trace_id=str(hash(tuple(m["content"] for m in msgs))))
            return Output(c.text, Usage(c.input_tokens, c.output_tokens))

    model.ChatMessageSystem, model.ChatMessageUser, model.ChatMessageAssistant = (
        ChatMessageSystem, ChatMessageUser, ChatMessageAssistant)
    model.GenerateConfig = GenerateConfig
    model.get_model = lambda: FakeModel()

    scorer = types.ModuleType("inspect_ai.scorer")

    @dataclass
    class Score:
        value: str
        answer: str = ""
        explanation: str = ""
        metadata: dict | None = None

    scorer.CORRECT, scorer.INCORRECT, scorer.Score = "C", "I", Score
    scorer.Target = str
    scorer.accuracy = scorer.stderr = lambda: None
    scorer.scorer = passthrough_decorator

    solver = types.ModuleType("inspect_ai.solver")
    solver.Generate = object
    solver.solver = passthrough_decorator

    @dataclass
    class TaskState:
        metadata: dict
        epoch: int = 1

    solver.TaskState = TaskState

    util = types.ModuleType("inspect_ai.util")

    @dataclass
    class ExecResult:
        success: bool
        returncode: int
        stdout: str
        stderr: str

    class FakeSandbox:
        async def exec(self, cmd, input=None, timeout=None):
            assert cmd[:3] == ["python3", "-I", "-c"] and cmd[3] == HARNESS
            import json
            res = await local_executor.run_harness(json.loads(input), timeout or 20)
            return ExecResult(True, 0, "__RESULT__" + json.dumps(res), "")

    util.sandbox = lambda: FakeSandbox()

    for name, mod in {"inspect_ai": root, "inspect_ai.dataset": dataset, "inspect_ai.model": model,
                      "inspect_ai.scorer": scorer, "inspect_ai.solver": solver, "inspect_ai.util": util}.items():
        sys.modules[name] = mod
    return TaskState


def test_inspect_adapter_with_stub():
    if importlib.util.find_spec("inspect_ai") is not None and "inspect_ai" not in sys.modules:
        print("skip: real Inspect installed; run `inspect eval` instead")
        return

    from selfcorrect.backends import SimulatedLLM
    from selfcorrect.execution import LocalExecutor
    from selfcorrect.tasks import load_tasks

    lab_tasks = load_tasks(["coding", "math"], ["fresh"], limit=3)
    TaskState = _install_stub(SimulatedLLM(lab_tasks, "sim-standard"), LocalExecutor())
    sys.modules.pop("inspect_tasks", None)
    import inspect_tasks

    async def go():
        for task_type, conds in (("coding", "ABCDE"), ("math", "ABDE")):
            for cond in conds:
                t = inspect_tasks.self_correction(condition=cond, task_type=task_type, sandbox_type="local")
                assert t.metadata["lab"] == "chapter-10"
                for sample in list(t.dataset)[:3]:
                    state = TaskState(metadata=dict(sample.metadata))
                    state = await t.solver(state, None)
                    score = await t.scorer(state, sample.target)
                    assert score.value in ("C", "I")
                    assert score.metadata["condition"] == cond
                    assert score.metadata["final_correct"] == (score.value == "C")

    asyncio.run(go())

    try:
        inspect_tasks.self_correction(condition="C", task_type="math")
        raise AssertionError("expected ValueError")
    except ValueError:
        pass


if __name__ == "__main__":
    test_inspect_adapter_with_stub()
    print("ok  test_inspect_adapter_with_stub")
