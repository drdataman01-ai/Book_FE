"""End-to-end checks for Lab 10. Run with:  python -m pytest tests/  (or: python tests/test_pipeline.py)

These tests use the simulated model and the local executor, so they need no
API key and no Inspect installation.
"""

from __future__ import annotations

import asyncio
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from selfcorrect.conditions import Settings, filter_correct, run_condition, vote_correct  # noqa: E402
from selfcorrect.execution import LocalExecutor, probe_values, run_tests  # noqa: E402
from selfcorrect.extract import extract_code, extract_number, extract_verdict, probe_snippet  # noqa: E402
from selfcorrect.backends import SimulatedLLM  # noqa: E402
from selfcorrect.tasks import load_tasks  # noqa: E402


def test_extraction():
    assert extract_number("so the total is 1,234.5\nANSWER: 1,234.5") == 1234.5
    assert extract_number("ANSWER: $-3") == -3
    assert extract_number("no answer line, but 7 then 9") == 9
    assert extract_number("nothing") is None
    assert extract_verdict("blah\nVERDICT: **INCORRECT**") == "INCORRECT"
    assert extract_verdict("Verdict: correct") == "CORRECT"
    assert extract_verdict("no verdict here") is None
    assert extract_code("text\n```python\ndef f():\n    return 1\n```\nmore") == "def f():\n    return 1\n"
    assert probe_snippet("assert f(1) == 2") == "__probe__ = f(1)"
    assert probe_snippet("import x\nassert f(x) is True") == "import x\n__probe__ = f(x)"
    assert probe_snippet("try:\n    f('')\n    raise AssertionError('x')\nexcept ValueError:\n    pass") == "__probe__ = f('')"


def test_executor_handles_errors_and_hangs():
    ex = LocalExecutor()

    async def go():
        ok = await run_tests(ex, "def f(x):\n    return x + 1\n", ["assert f(1) == 2", "assert f(2) == 4"])
        assert not ok.passed and ok.n_passed == 1 and len(ok.failures) == 1
        broken = await run_tests(ex, "def f(x) return x\n", ["assert f(1) == 1"])
        assert not broken.passed and "SyntaxError" in broken.failures[0][1]
        hang = await run_tests(ex, "def f(x):\n    while True:\n        pass\n", ["assert f(1) == 1"], timeout=15)
        assert not hang.passed
        sig = await probe_values(ex, "def f(x):\n    return x * 2\n", ["assert f(3) == 6", "assert f(0) == 1"])
        assert sig == ("6", "0")

    asyncio.run(go())


def test_reference_solutions_pass_in_executor():
    ex = LocalExecutor()
    tasks = load_tasks(["coding"], ["fresh"])

    async def go():
        for t in tasks:
            outcome = await run_tests(ex, t.reference, t.all_tests)
            assert outcome.passed, (t.id, outcome.failures)

    asyncio.run(go())


def test_voting_rules():
    cands = [{"index": 0, "value": 5.0, "correct": False},
             {"index": 1, "value": 7.0, "correct": True},
             {"index": 2, "value": 7.0, "correct": True}]
    assert vote_correct(cands, 1, "math") is False
    assert vote_correct(cands, 2, "math") is False  # tie goes to the earliest answer
    assert vote_correct(cands, 3, "math") is True
    code = [{"index": 0, "signature": ["1"], "visible_pass": False, "correct": False},
            {"index": 1, "signature": ["2"], "visible_pass": True, "correct": True}]
    assert filter_correct(code, 2) is True
    assert filter_correct(code, 1) is False


def test_all_conditions_with_simulated_model():
    tasks = load_tasks(["coding", "math"], ["fresh"], limit=4)
    llm = SimulatedLLM(tasks, "sim-standard", seed=1)
    ex = LocalExecutor()
    settings = Settings(max_rounds=2, vote_k=4)

    async def go():
        recs = []
        for t in tasks:
            for c in "ABCDE":
                if c == "C" and t.task_type != "coding":
                    continue
                recs.append(await run_condition(c, t, llm, ex, settings, epoch=0))
        return recs

    recs = asyncio.run(go())
    for r in recs:
        assert len(r["correct_by_round"]) == 3
        assert r["calls"] >= 1
        if r["condition"] == "A":
            assert r["calls"] == 1
        if r["condition"] == "D" and r["stop_reason"] == "oracle_correct":
            assert r["final_correct"]
        if r["condition"] == "E":
            assert len(r["candidates"]) == 4 and r["calls"] == 4
    # Same seed and trace ids give the same results.
    again = asyncio.run(run_condition("B", tasks[0], llm, ex, settings, epoch=0))
    first = next(r for r in recs if r["condition"] == "B" and r["task_id"] == tasks[0].id)
    assert again["correct_by_round"] == first["correct_by_round"]


def test_run_and_analyse_end_to_end():
    import analysis
    import run_local

    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "sim.jsonl"
        run_local.main(["--backend", "sim", "--model", "sim-standard", "--epochs", "2",
                        "--limit", "3", "--out", str(out)])
        lines = [json.loads(x) for x in out.read_text().splitlines()]
        assert lines and not any("error" in x for x in lines)
        analysis.main([str(out), "--out", str(Path(tmp) / "report"), "--price-in", "1", "--price-out", "4"])
        report = Path(tmp) / "report"
        assert (report / "report.md").exists()
        assert len(list(report.glob("fig_*.png"))) == 4
        assert "Simulated model" in (report / "report.md").read_text()


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print(f"ok  {name}")
