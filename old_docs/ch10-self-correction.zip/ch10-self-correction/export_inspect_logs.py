"""Convert Inspect logs from Lab 10 into the JSONL records analysis.py reads.

Usage:
    python export_inspect_logs.py logs/ --out results/inspect.jsonl
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from inspect_ai.log import list_eval_logs, read_eval_log


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("log_dir", nargs="?", default="logs")
    ap.add_argument("--out", default="results/inspect.jsonl")
    args = ap.parse_args()

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    n_logs = n_records = 0
    with open(out, "w") as f:
        for info in list_eval_logs(args.log_dir):
            log = read_eval_log(getattr(info, "name", info))
            if (log.eval.metadata or {}).get("lab") != "chapter-10" or not log.samples:
                continue
            n_logs += 1
            for sample in log.samples:
                if not sample.scores:
                    continue
                score = next(iter(sample.scores.values()))
                if not score.metadata:
                    continue
                record = dict(score.metadata)
                record["epoch"] = sample.epoch
                record["model"] = log.eval.model
                record["backend"] = "inspect"
                f.write(json.dumps(record) + "\n")
                n_records += 1
    print(f"exported {n_records} records from {n_logs} logs to {out}")


if __name__ == "__main__":
    main()
