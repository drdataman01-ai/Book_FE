"""Run the whole of Lab 10 in Inspect: every condition on both task types.

Usage:
    python run_inspect.py --model <provider/model> --epochs 10
    python run_inspect.py --model <provider/model> --sources fresh,public --conditions A,B,E

Logs go to logs/ (one log per condition and task type). Convert them with
export_inspect_logs.py before running analysis.py.
"""

from __future__ import annotations

import argparse

from inspect_ai import eval as inspect_eval

from inspect_tasks import self_correction


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", required=True, help="Inspect model name, e.g. openai/<model>")
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--conditions", default="A,B,C,D,E")
    ap.add_argument("--task-types", default="coding,math")
    ap.add_argument("--sources", default="fresh")
    ap.add_argument("--max-rounds", type=int, default=2)
    ap.add_argument("--vote-k", type=int, default=8)
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--sandbox", default="docker", choices=["docker", "local"])
    ap.add_argument("--log-dir", default="logs")
    ap.add_argument("--max-connections", type=int, default=10)
    args = ap.parse_args()

    tasks = []
    for source in args.sources.split(","):
        for task_type in args.task_types.split(","):
            for condition in args.conditions.split(","):
                if condition == "C" and task_type != "coding":
                    continue
                tasks.append(self_correction(
                    condition=condition, task_type=task_type, source=source,
                    max_rounds=args.max_rounds, vote_k=args.vote_k,
                    temperature=args.temperature, sandbox_type=args.sandbox,
                ))

    inspect_eval(
        tasks,
        model=args.model,
        epochs=args.epochs,
        log_dir=args.log_dir,
        max_connections=args.max_connections,
    )


if __name__ == "__main__":
    main()
