"""Analysis for Lab 10: tables and figures from run records.

Reads the JSONL records written by run_local.py or export_inspect_logs.py and
produces, for each model and task type:

  Table 1  accuracy by condition, with 95% bootstrap confidence intervals
           (resampling tasks, since repeated epochs of one task are not
           independent), plus "all epochs correct" as a reliability measure
  Table 2  paired comparisons between conditions on the same tasks
  Table 3  flip tables: how often revision fixes or breaks an answer
  Table 4  cost: model calls, tokens, and tokens per correct answer
  Figure 1 accuracy by condition
  Figure 2 flips for the revising conditions
  Figure 3 accuracy by revision round
  Figure 4 accuracy against model calls, with majority voting at every budget

Condition E (voting) is evaluated at several budgets from the same samples:
  E@k   majority vote over all k samples
  E=B   majority vote using as many samples as B's average number of calls
  E=C   the same for C's average calls (coding)
  F=C   sample and filter at C's average calls: the first sample that passes
        the visible tests (coding). This is the equal-cost counterpart of C,
        since both use the visible tests.

Usage:
    python analysis.py results/*.jsonl --out report/
    python analysis.py results/*.jsonl --out report/ --price-in 2.5 --price-out 10
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

from selfcorrect.conditions import filter_correct, vote_correct

BOOTSTRAP_SAMPLES = 2000
CONDITION_LABELS = {
    "A": "A  single attempt",
    "B": "B  intrinsic self-correction",
    "C": "C  external feedback",
    "D": "D  oracle stopping (unrealistic)",
    "E@k": "E  majority vote, all samples",
    "E=B": "E  majority vote at B's cost",
    "E=C": "E  majority vote at C's cost",
    "F=C": "F  sample and filter at C's cost",
}

# ---------------------------------------------------------------------------
# Loading and expanding records
# ---------------------------------------------------------------------------


def load_records(paths: list[str]) -> tuple[pd.DataFrame, int]:
    rows, n_errors = [], 0
    for p in paths:
        with open(p) as f:
            for line in f:
                if not line.strip():
                    continue
                r = json.loads(line)
                if "error" in r:
                    n_errors += 1
                    continue
                rows.append(r)
    if not rows:
        raise SystemExit("no usable records found")
    return pd.DataFrame(rows), n_errors


def _mean_calls(df: pd.DataFrame, cond: str) -> float | None:
    sub = df[df["condition"] == cond]
    return float(sub["calls"].mean()) if len(sub) else None


def expand_voting(df: pd.DataFrame) -> pd.DataFrame:
    """Add rows for voting/filtering evaluated at equal-cost budgets.

    Budgets are computed per (model, task_type, source) from the average calls
    of B and C in the same group.
    """
    out = [df[df["condition"] != "E"].copy()]
    for (_model, task_type, _source), g in df.groupby(["model", "task_type", "source"]):
        e = g[g["condition"] == "E"]
        if e.empty:
            continue
        k = int(e["vote_k"].iloc[0])
        budgets = {"E@k": k}
        for cond in ("B", "C"):
            calls = _mean_calls(g, cond)
            if calls is not None:
                budgets[f"E={cond}"] = int(min(k, max(1, round(calls))))
        if task_type == "coding" and "E=C" in budgets:
            budgets["F=C"] = budgets["E=C"]
        for label, m in budgets.items():
            rows = e.copy()
            if label.startswith("F"):
                rows["final_correct"] = [filter_correct(c, m) for c in e["candidates"]]
            else:
                rows["final_correct"] = [vote_correct(c, m, task_type) for c in e["candidates"]]
            scale = m / k
            rows["condition"] = label
            rows["calls"] = m
            rows["input_tokens"] = e["input_tokens"] * scale
            rows["output_tokens"] = e["output_tokens"] * scale
            rows["budget"] = m
            out.append(rows)
    return pd.concat(out, ignore_index=True)


# ---------------------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------------------


def _task_means(df: pd.DataFrame, value: str = "final_correct") -> pd.Series:
    return df.groupby("task_id")[value].mean()


def bootstrap_ci(task_values: np.ndarray, rng: np.random.Generator, n: int = BOOTSTRAP_SAMPLES) -> tuple[float, float]:
    """95% percentile interval for the mean, resampling tasks with replacement."""
    if len(task_values) < 2:
        return (math.nan, math.nan)
    idx = rng.integers(0, len(task_values), size=(n, len(task_values)))
    means = task_values[idx].mean(axis=1)
    lo, hi = np.percentile(means, [2.5, 97.5])
    return float(lo), float(hi)


def accuracy_table(df: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    rows = []
    for (model, task_type, source, cond), g in df.groupby(["model", "task_type", "source", "condition"]):
        per_task = _task_means(g)
        lo, hi = bootstrap_ci(per_task.to_numpy(dtype=float), rng)
        all_epochs = g.groupby("task_id")["final_correct"].all().mean()
        rows.append({
            "model": model, "task_type": task_type, "source": source, "condition": cond,
            "label": CONDITION_LABELS.get(cond, cond),
            "tasks": len(per_task), "attempts": len(g),
            "accuracy": per_task.mean(), "ci_low": lo, "ci_high": hi,
            "all_epochs_correct": all_epochs,
            "mean_calls": g["calls"].mean(),
        })
    return pd.DataFrame(rows)


PAIRS = [
    ("B", "A", "Does intrinsic revision help at all?"),
    ("C", "A", "Does revision with test feedback help?"),
    ("C", "B", "Is the external signal what makes revision work?"),
    ("B", "E=B", "Does intrinsic revision beat voting at equal cost?"),
    ("C", "F=C", "Does feedback beat sample-and-filter at equal cost?"),
    ("D", "B", "How much does oracle stopping inflate the result?"),
]


def paired_table(df: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    """Difference in accuracy between two conditions on the same tasks."""
    rows = []
    for (model, task_type, source), g in df.groupby(["model", "task_type", "source"]):
        for a, b, question in PAIRS:
            ga, gb = g[g["condition"] == a], g[g["condition"] == b]
            if ga.empty or gb.empty:
                continue
            ma, mb = _task_means(ga), _task_means(gb)
            common = ma.index.intersection(mb.index)
            diff = (ma[common] - mb[common]).to_numpy(dtype=float)
            lo, hi = bootstrap_ci(diff, rng)
            rows.append({
                "model": model, "task_type": task_type, "source": source,
                "comparison": f"{a} - {b}", "question": question, "tasks": len(common),
                "difference": diff.mean(), "ci_low": lo, "ci_high": hi,
                "tasks_better": int((diff > 0).sum()), "tasks_worse": int((diff < 0).sum()),
            })
    return pd.DataFrame(rows)


def flip_table(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    revising = df[df["condition"].isin(["B", "C", "D"])]
    for (model, task_type, source, cond), g in revising.groupby(["model", "task_type", "source", "condition"]):
        i, f = g["initial_correct"].astype(bool), g["final_correct"].astype(bool)
        fixed, broken = int((~i & f).sum()), int((i & ~f).sum())
        rows.append({
            "model": model, "task_type": task_type, "source": source, "condition": cond,
            "attempts": len(g),
            "wrong_to_right": fixed, "right_to_wrong": broken,
            "stayed_right": int((i & f).sum()), "stayed_wrong": int((~i & ~f).sum()),
            "net_gain": fixed - broken,
            "revised_attempts": int((g["rounds_used"] > 0).sum()),
        })
    return pd.DataFrame(rows)


def rounds_table(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    sub = df[df["condition"].isin(["A", "B", "C", "D"])]
    for (model, task_type, source, cond), g in sub.groupby(["model", "task_type", "source", "condition"]):
        by_round = np.array(g["correct_by_round"].tolist(), dtype=float)
        for r in range(by_round.shape[1]):
            rows.append({"model": model, "task_type": task_type, "source": source,
                         "condition": cond, "round": r, "accuracy": by_round[:, r].mean()})
    return pd.DataFrame(rows)


def cost_table(df: pd.DataFrame, price_in: float | None, price_out: float | None) -> pd.DataFrame:
    rows = []
    for (model, task_type, source, cond), g in df.groupby(["model", "task_type", "source", "condition"]):
        acc = g["final_correct"].mean()
        tokens = (g["input_tokens"] + g["output_tokens"]).mean()
        row = {
            "model": model, "task_type": task_type, "source": source, "condition": cond,
            "accuracy": acc, "mean_calls": g["calls"].mean(),
            "mean_input_tokens": g["input_tokens"].mean(), "mean_output_tokens": g["output_tokens"].mean(),
            "tokens_per_correct": tokens / acc if acc > 0 else math.inf,
        }
        if price_in is not None and price_out is not None:
            dollars = (g["input_tokens"] * price_in + g["output_tokens"] * price_out).mean() / 1e6
            row["dollars_per_attempt"] = dollars
            row["dollars_per_correct"] = dollars / acc if acc > 0 else math.inf
        rows.append(row)
    return pd.DataFrame(rows)


def vote_curve(df_raw: pd.DataFrame) -> pd.DataFrame:
    """Accuracy of voting (and filtering, for coding) at every budget m = 1..k."""
    rows = []
    e_all = df_raw[df_raw["condition"] == "E"]
    for (model, task_type, source), e in e_all.groupby(["model", "task_type", "source"]):
        k = int(e["vote_k"].iloc[0])
        for m in range(1, k + 1):
            rows.append({"model": model, "task_type": task_type, "source": source, "method": "vote", "budget": m,
                         "accuracy": float(np.mean([vote_correct(c, m, task_type) for c in e["candidates"]]))})
            if task_type == "coding":
                rows.append({"model": model, "task_type": task_type, "source": source, "method": "filter",
                             "budget": m,
                             "accuracy": float(np.mean([filter_correct(c, m) for c in e["candidates"]]))})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Figures (matplotlib; light surface for print)
# ---------------------------------------------------------------------------

INK, INK_2, INK_3 = "#0b0b0b", "#52514e", "#8a8984"
GRID = "#e6e5e1"
SURFACE = "#fcfcfb"
SERIES = {"A": "#2a78d6", "B": "#eb6834", "C": "#1baf7a", "D": "#6250d6",
          "E": "#e87ba4", "F": "#008300"}


def _style(ax):
    ax.set_facecolor(SURFACE)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(INK_3)
    ax.tick_params(colors=INK_2, labelsize=9)
    ax.yaxis.label.set_color(INK_2)
    ax.xaxis.label.set_color(INK_2)
    ax.grid(axis="y", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def _figure(n_panels: int, width_per: float = 5.2, height: float = 3.8):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, n_panels, figsize=(width_per * n_panels, height), squeeze=False)
    fig.patch.set_facecolor(SURFACE)
    return fig, axes[0], plt


def _title(fig, text: str, sub: str):
    fig.text(0.01, 0.98, text, ha="left", va="top", fontsize=12, color=INK, fontweight="bold")
    fig.text(0.01, 0.92, sub, ha="left", va="top", fontsize=9, color=INK_2)


def _panel_title(ax, text):
    ax.set_title(text, loc="left", fontsize=10, color=INK, pad=8)


def fig_accuracy(acc: pd.DataFrame, model: str, source: str, path: Path, simulated: bool):
    order = ["A", "B", "C", "D", "E=B", "E=C", "F=C", "E@k"]
    groups = [t for t in ("coding", "math") if not acc[acc["task_type"] == t].empty]
    fig, axes, plt = _figure(len(groups))
    for ax, task_type in zip(axes, groups):
        sub = acc[acc["task_type"] == task_type].set_index("condition")
        conds = [c for c in order if c in sub.index]
        y = np.arange(len(conds))[::-1]
        for yi, c in zip(y, conds):
            r = sub.loc[c]
            color = SERIES[c[0]]
            ax.plot([r.ci_low, r.ci_high], [yi, yi], color=color, linewidth=2, solid_capstyle="round")
            ax.plot([r.accuracy], [yi], "o", markersize=8, color=color,
                    markeredgecolor=SURFACE, markeredgewidth=2)
            ax.text(min(r.ci_high + 0.03, 1.02), yi, f"{r.accuracy:.0%}", va="center", fontsize=9, color=INK)
        ax.set_yticks(y, [CONDITION_LABELS.get(c, c) for c in conds], fontsize=9, color=INK)
        ax.set_xlim(0, 1.1)
        ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0], ["0%", "25%", "50%", "75%", "100%"])
        ax.set_xlabel("Accuracy (dot) with 95% confidence interval (line)")
        _style(ax)
        ax.grid(axis="x", color=GRID, linewidth=0.8)
        ax.grid(axis="y", visible=False)
        _panel_title(ax, f"{task_type.capitalize()} tasks")
    _title(fig, "Figure 10.1  Accuracy by condition",
           f"{model} · {source} tasks" + ("  ·  SIMULATED MODEL: tests the pipeline only" if simulated else ""))
    fig.tight_layout(rect=(0, 0, 1, 0.88))
    fig.savefig(path, dpi=200)
    plt.close(fig)


def fig_flips(flips: pd.DataFrame, model: str, source: str, path: Path, simulated: bool):
    groups = [t for t in ("coding", "math") if not flips[flips["task_type"] == t].empty]
    fig, axes, plt = _figure(len(groups))
    for ax, task_type in zip(axes, groups):
        sub = flips[flips["task_type"] == task_type].set_index("condition")
        conds = [c for c in ("B", "C", "D") if c in sub.index]
        x = np.arange(len(conds))
        fixed = [sub.loc[c].wrong_to_right / sub.loc[c].attempts for c in conds]
        broken = [sub.loc[c].right_to_wrong / sub.loc[c].attempts for c in conds]
        ax.bar(x - 0.19, fixed, width=0.36, color="#1baf7a", label="wrong → right")
        ax.bar(x + 0.19, broken, width=0.36, color="#e34948", label="right → wrong")
        for xi, f_, b_ in zip(x, fixed, broken):
            ax.text(xi - 0.19, f_ + 0.01, f"{f_:.0%}", ha="center", fontsize=9, color=INK)
            ax.text(xi + 0.19, b_ + 0.01, f"{b_:.0%}", ha="center", fontsize=9, color=INK)
        ax.set_xticks(x, [CONDITION_LABELS[c].split("  ", 1)[1] for c in conds], fontsize=9, color=INK)
        top = max(fixed + broken + [0.1])
        ax.set_ylim(0, top * 1.25)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v * 100:g}%"))
        ax.set_ylabel("Share of attempts")
        ax.legend(frameon=False, fontsize=9, labelcolor=INK_2, loc="lower left",
                  bbox_to_anchor=(0, 1.0), ncol=2, borderaxespad=0.2, handlelength=1.2)
        _style(ax)
        ax.set_title(f"{task_type.capitalize()} tasks", loc="left", fontsize=10, color=INK, pad=26)
    _title(fig, "Figure 10.2  What revision does to answers",
           f"{model} · {source} tasks" + ("  ·  SIMULATED MODEL: tests the pipeline only" if simulated else ""))
    fig.tight_layout(rect=(0, 0, 1, 0.88))
    fig.savefig(path, dpi=200)
    plt.close(fig)


def fig_rounds(rounds: pd.DataFrame, model: str, source: str, path: Path, simulated: bool):
    groups = [t for t in ("coding", "math") if not rounds[rounds["task_type"] == t].empty]
    fig, axes, plt = _figure(len(groups))
    for ax, task_type in zip(axes, groups):
        sub = rounds[rounds["task_type"] == task_type]
        ends = []
        for cond in ("A", "B", "C", "D"):
            s = sub[sub["condition"] == cond].sort_values("round")
            if s.empty:
                continue
            style = "--" if cond == "D" else "-"
            ax.plot(s["round"], s["accuracy"], style, color=SERIES[cond], linewidth=2, marker="o",
                    markersize=8, markeredgecolor=SURFACE, markeredgewidth=2)
            ends.append([float(s["accuracy"].iloc[-1]), float(s["round"].iloc[-1]),
                         CONDITION_LABELS[cond].split("  ", 1)[1]])
        ends.sort()
        for i in range(1, len(ends)):  # keep end labels at least 6 points apart
            ends[i][0] = max(ends[i][0], ends[i - 1][0] + 0.06)
        for y_, x_, label in ends:
            ax.text(x_ + 0.08, y_, label, va="center", fontsize=9, color=INK)
        n_rounds = int(sub["round"].max()) if not sub.empty else 0
        ax.set_xticks(range(n_rounds + 1), ["first answer"] + [f"round {r}" for r in range(1, n_rounds + 1)])
        ax.set_xlim(-0.2, n_rounds + 1.6)
        ax.set_ylim(0, 1.05)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.0%}"))
        ax.set_ylabel("Accuracy")
        _style(ax)
        _panel_title(ax, f"{task_type.capitalize()} tasks")
    _title(fig, "Figure 10.3  Accuracy by revision round",
           f"{model} · {source} tasks · agents that stop early keep their last answer"
           + ("  ·  SIMULATED MODEL" if simulated else ""))
    fig.tight_layout(rect=(0, 0, 1, 0.88))
    fig.savefig(path, dpi=200)
    plt.close(fig)


def fig_budget(curve: pd.DataFrame, acc: pd.DataFrame, model: str, source: str, path: Path, simulated: bool):
    groups = [t for t in ("coding", "math") if not acc[acc["task_type"] == t].empty]
    fig, axes, plt = _figure(len(groups))
    for ax, task_type in zip(axes, groups):
        c = curve[curve["task_type"] == task_type] if not curve.empty else curve
        for method, color, name in (("vote", SERIES["E"], "majority vote"), ("filter", SERIES["F"], "sample and filter")):
            s = c[c["method"] == method] if not c.empty else c
            if s.empty:
                continue
            ax.plot(s["budget"], s["accuracy"], color=color, linewidth=2)
            ax.text(s["budget"].iloc[-1] + 0.15, s["accuracy"].iloc[-1], name, va="center", fontsize=9, color=INK)
        sub = acc[acc["task_type"] == task_type].set_index("condition")
        for cond in ("A", "B", "C", "D"):
            if cond not in sub.index:
                continue
            r = sub.loc[cond]
            ax.plot([r.mean_calls], [r.accuracy], "o", markersize=9, color=SERIES[cond],
                    markeredgecolor=SURFACE, markeredgewidth=2, zorder=3)
            ax.annotate(cond, (r.mean_calls, r.accuracy), textcoords="offset points", xytext=(6, -12),
                        fontsize=9, color=INK, fontweight="bold")
        ax.set_ylim(0, 1.05)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.0%}"))
        ax.set_xlabel("Model calls per task attempt")
        ax.set_ylabel("Accuracy")
        right = max([s for s in [c["budget"].max() if not c.empty else 1, sub["mean_calls"].max()]]) + 2.5
        ax.set_xlim(0, right)
        _style(ax)
        _panel_title(ax, f"{task_type.capitalize()} tasks")
    _title(fig, "Figure 10.4  Accuracy against cost",
           f"{model} · {source} tasks · dots: conditions A–D at their average cost · lines: voting at every budget"
           + ("  ·  SIMULATED" if simulated else ""))
    fig.tight_layout(rect=(0, 0, 1, 0.88))
    fig.savefig(path, dpi=200)
    plt.close(fig)


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------


def _pct(x):
    return "" if pd.isna(x) else f"{x:.1%}"


def _md_table(df: pd.DataFrame, cols: list[str], headers: list[str], fmt: dict) -> str:
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(fmt.get(c, str)(r[c]) for c in cols) + " |")
    return "\n".join(lines)


def write_report(out: Path, acc, pairs, flips, cost, n_errors: int, simulated: bool):
    md = ["# Lab 10 results", ""]
    if simulated:
        md += ["> **Simulated model.** These numbers test that the lab runs end to end. They are produced "
               "by scripted probabilities and say nothing about any real model.", ""]
    if n_errors:
        md += [f"{n_errors} attempts failed with errors and were excluded; check the raw records.", ""]
    for (model, source), _ in acc.groupby(["model", "source"]):
        slug = f"{_slug(model)}_{source}"
        md += [f"## {model} · {source} tasks", ""]
        for task_type in ("coding", "math"):
            a = acc[(acc.model == model) & (acc.source == source) & (acc.task_type == task_type)]
            if a.empty:
                continue
            order = {c: i for i, c in enumerate(CONDITION_LABELS)}
            a = a.sort_values("condition", key=lambda s: s.map(order))
            md += [f"### {task_type.capitalize()} tasks", "",
                   "**Table 1. Accuracy by condition**", "",
                   _md_table(a, ["label", "accuracy", "ci_low", "ci_high", "all_epochs_correct", "mean_calls", "tasks"],
                             ["Condition", "Accuracy", "95% CI low", "95% CI high", "All epochs correct",
                              "Calls per attempt", "Tasks"],
                             {"accuracy": _pct, "ci_low": _pct, "ci_high": _pct, "all_epochs_correct": _pct,
                              "mean_calls": lambda v: f"{v:.1f}", "label": str, "tasks": str}), ""]
            p = pairs[(pairs.model == model) & (pairs.source == source) & (pairs.task_type == task_type)]
            if not p.empty:
                md += ["**Table 2. Paired comparisons (same tasks)**", "",
                       _md_table(p, ["comparison", "question", "difference", "ci_low", "ci_high",
                                     "tasks_better", "tasks_worse"],
                                 ["Comparison", "Question", "Difference", "95% CI low", "95% CI high",
                                  "Tasks better", "Tasks worse"],
                                 {"difference": lambda v: f"{v:+.1%}", "ci_low": lambda v: f"{v:+.1%}",
                                  "ci_high": lambda v: f"{v:+.1%}", "tasks_better": str, "tasks_worse": str}),
                       "", "A confidence interval that includes zero means the data cannot tell the two "
                       "conditions apart.", ""]
            fl = flips[(flips.model == model) & (flips.source == source) & (flips.task_type == task_type)]
            if not fl.empty:
                md += ["**Table 3. Flip table**", "",
                       _md_table(fl, ["condition", "attempts", "revised_attempts", "wrong_to_right",
                                      "right_to_wrong", "net_gain"],
                                 ["Condition", "Attempts", "Attempts revised", "Wrong → right", "Right → wrong",
                                  "Net gain"], {}), ""]
            c = cost[(cost.model == model) & (cost.source == source) & (cost.task_type == task_type)]
            c = c.sort_values("condition", key=lambda s: s.map(order))
            cols = ["condition", "accuracy", "mean_calls", "mean_input_tokens", "mean_output_tokens",
                    "tokens_per_correct"]
            heads = ["Condition", "Accuracy", "Calls", "Input tokens", "Output tokens", "Tokens per correct answer"]
            fmts = {"accuracy": _pct, "mean_calls": lambda v: f"{v:.1f}",
                    "mean_input_tokens": lambda v: f"{v:,.0f}", "mean_output_tokens": lambda v: f"{v:,.0f}",
                    "tokens_per_correct": lambda v: "∞" if math.isinf(v) else f"{v:,.0f}"}
            if "dollars_per_correct" in c:
                cols.append("dollars_per_correct")
                heads.append("$ per correct answer")
                fmts["dollars_per_correct"] = lambda v: "∞" if math.isinf(v) else f"{v:.4f}"
            md += ["**Table 4. Cost**", "", _md_table(c, cols, heads, fmts), ""]
        md += ["**Figures**", ""]
        for name in ("accuracy", "flips", "rounds", "budget"):
            md.append(f"![{name}](fig_{name}_{slug}.png)")
        md.append("")
    (out / "report.md").write_text("\n".join(md))


def _slug(s: str) -> str:
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in s)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("records", nargs="+", help="JSONL files from run_local.py or export_inspect_logs.py")
    ap.add_argument("--out", default="report")
    ap.add_argument("--price-in", type=float, default=None, help="$ per million input tokens")
    ap.add_argument("--price-out", type=float, default=None, help="$ per million output tokens")
    ap.add_argument("--seed", type=int, default=0, help="bootstrap seed")
    args = ap.parse_args(argv)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    raw, n_errors = load_records(args.records)
    simulated = bool((raw.get("backend") == "sim").any()) if "backend" in raw else False
    df = expand_voting(raw)
    rng = np.random.default_rng(args.seed)

    acc = accuracy_table(df, rng)
    pairs = paired_table(df, rng)
    flips = flip_table(df)
    rounds = rounds_table(df)
    cost = cost_table(df, args.price_in, args.price_out)
    curve = vote_curve(raw)

    for name, table in (("accuracy", acc), ("paired", pairs), ("flips", flips),
                        ("rounds", rounds), ("cost", cost), ("vote_curve", curve)):
        table.to_csv(out / f"table_{name}.csv", index=False)

    for (model, source), _ in acc.groupby(["model", "source"]):
        sel = lambda t: t[(t.model == model) & (t.source == source)] if not t.empty else t  # noqa: E731
        slug = f"{_slug(model)}_{source}"
        fig_accuracy(sel(acc), model, source, out / f"fig_accuracy_{slug}.png", simulated)
        if not sel(flips).empty:
            fig_flips(sel(flips), model, source, out / f"fig_flips_{slug}.png", simulated)
        if not sel(rounds).empty:
            fig_rounds(sel(rounds), model, source, out / f"fig_rounds_{slug}.png", simulated)
        fig_budget(sel(curve), sel(acc), model, source, out / f"fig_budget_{slug}.png", simulated)

    write_report(out, acc, pairs, flips, cost, n_errors, simulated)
    print(f"wrote report, tables and figures to {out}/")


if __name__ == "__main__":
    main()
