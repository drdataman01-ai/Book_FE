"""Model backends for run_local.py.

* SimulatedLLM  - a scripted stand-in for a model, for testing the pipeline
                  without an API key. Its behaviour is controlled by a few
                  probabilities. ITS RESULTS ARE NOT EVIDENCE ABOUT ANY REAL
                  MODEL; they exist so readers can check that the code,
                  statistics and figures work before spending money.
* OpenAICompatLLM - any endpoint that speaks the OpenAI chat-completions
                  protocol: OpenAI itself, or local servers such as Ollama
                  (http://localhost:11434/v1), LM Studio or vLLM.

For other providers, use the Inspect front end (inspect_tasks.py), which
supports them natively.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import random
import time
import urllib.error
import urllib.request
from dataclasses import dataclass

from . import prompts
from .conditions import Completion
from .extract import extract_code, extract_number, numbers_match
from .tasks import Task

# ---------------------------------------------------------------------------
# Simulated model
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SimProfile:
    """Probabilities that drive the simulated model. All values are invented."""

    p_first_coding: float
    p_first_math: float
    p_detect_error: float  # says INCORRECT when its answer is wrong
    p_false_alarm: float  # says INCORRECT when its answer is right
    p_fix_after_critique: float  # a wrong answer becomes right after self-revision
    p_break_after_critique: float  # a right answer becomes wrong after self-revision
    p_fix_with_feedback: float  # a wrong answer becomes right after test feedback
    thinking_tokens: int  # extra output tokens per call, mimicking a reasoning model


PROFILES = {
    "sim-standard": SimProfile(0.55, 0.70, 0.35, 0.30, 0.25, 0.35, 0.65, 0),
    "sim-reasoning": SimProfile(0.75, 0.90, 0.55, 0.12, 0.45, 0.15, 0.80, 600),
}


def _tokens(text: str) -> int:
    return max(1, len(text) // 4)


def _norm_code(code: str) -> str:
    return "\n".join(line.rstrip() for line in code.strip().splitlines())


class SimulatedLLM:
    """Scripted model that answers right or wrong with set probabilities.

    It recognises which step it is at from the prompt text (first answer,
    critique, revision, or test feedback) and decides the outcome with a
    random draw seeded by the call's trace_id, so runs are reproducible.
    """

    def __init__(self, tasks: list[Task], profile: str = "sim-standard", seed: int = 0):
        self.profile = PROFILES[profile]
        self.name = profile
        self.seed = seed
        self._tasks = tasks

    def _task_for(self, messages: list[dict]) -> Task:
        opening = messages[1]["content"] if len(messages) > 1 else messages[0]["content"]
        for t in self._tasks:
            if (t.task_type == "coding" and t.prompt and t.prompt in opening) or \
               (t.task_type == "math" and t.question and t.question in opening):
                return t
        raise ValueError("simulated model: task not recognised")

    def _rng(self, trace_id: str) -> random.Random:
        h = hashlib.sha256(f"{self.seed}|{self.name}|{trace_id}".encode()).hexdigest()
        return random.Random(int(h[:16], 16))

    def _is_correct(self, task: Task, text: str) -> bool:
        if task.task_type == "coding":
            return task.reference is not None and _norm_code(extract_code(text)) == _norm_code(task.reference)
        return numbers_match(extract_number(text), task.answer)

    def _answer_text(self, task: Task, correct: bool, rng: random.Random) -> str:
        if task.task_type == "coding":
            if correct and task.reference:
                code = task.reference
            elif task.buggy and rng.random() < 0.7:
                code = task.buggy
            else:
                code = f"def {task.entry_point}(*args, **kwargs):\n    return None\n"
            return f"Here is the function.\n\n```python\n{code.strip()}\n```"
        # Wrong math answers come from a small, task-specific set of plausible
        # mistakes, so wrong samples sometimes agree with each other.
        wrong_rng = random.Random(task.id)
        wrong = [round(task.answer * f + d, 2) for f, d in ((1.1, 0), (0.9, 0), (1, 1))]
        wrong_rng.shuffle(wrong)
        value = task.answer if correct else wrong[0 if rng.random() < 0.6 else rng.randrange(3)]
        return f"Working through the problem step by step.\n\nANSWER: {value:g}"

    async def __call__(self, messages: list[dict], temperature: float, trace_id: str) -> Completion:
        p = self.profile
        rng = self._rng(trace_id)
        task = self._task_for(messages)
        last_user = messages[-1]["content"]
        prev_answer = next((m["content"] for m in reversed(messages)
                            if m["role"] == "assistant" and ("```" in m["content"] or "ANSWER" in m["content"])), None)

        if last_user == prompts.CRITIQUE:
            right = self._is_correct(task, prev_answer)
            says_wrong = rng.random() < (p.p_false_alarm if right else p.p_detect_error)
            text = ("I re-checked each step of the answer against the problem statement.\n"
                    f"VERDICT: {'INCORRECT' if says_wrong else 'CORRECT'}")
        elif last_user in (prompts.REVISE_CODING, prompts.REVISE_MATH):
            right = self._is_correct(task, prev_answer)
            now_right = (rng.random() >= p.p_break_after_critique) if right else (rng.random() < p.p_fix_after_critique)
            text = self._answer_text(task, now_right, rng)
        elif last_user.startswith(prompts.FEEDBACK_CODING.split("{")[0][:40]):
            text = self._answer_text(task, rng.random() < p.p_fix_with_feedback, rng)
        else:
            first = p.p_first_coding if task.task_type == "coding" else p.p_first_math
            text = self._answer_text(task, rng.random() < first, rng)

        in_tok = sum(_tokens(m["content"]) for m in messages)
        return Completion(text, in_tok, _tokens(text) + p.thinking_tokens)


# ---------------------------------------------------------------------------
# OpenAI-compatible endpoint
# ---------------------------------------------------------------------------


class OpenAICompatLLM:
    """Calls /chat/completions on any OpenAI-compatible server.

    Examples:
      OpenAI:  base_url="https://api.openai.com/v1", api key in OPENAI_API_KEY
      Ollama:  base_url="http://localhost:11434/v1", no key needed
    """

    def __init__(self, model: str, base_url: str, api_key_env: str = "OPENAI_API_KEY",
                 max_tokens: int = 2048, max_retries: int = 5, timeout: float = 300):
        self.name = model
        self.model = model
        self.url = base_url.rstrip("/") + "/chat/completions"
        self.api_key = os.environ.get(api_key_env, "")
        self.max_tokens = max_tokens
        self.max_retries = max_retries
        self.timeout = timeout

    def _post(self, body: dict) -> dict:
        data = json.dumps(body).encode()
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        delay = 2.0
        for attempt in range(self.max_retries + 1):
            req = urllib.request.Request(self.url, data=data, headers=headers, method="POST")
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    return json.loads(resp.read())
            except urllib.error.HTTPError as e:
                if e.code in (429, 500, 502, 503, 504) and attempt < self.max_retries:
                    time.sleep(delay)
                    delay = min(delay * 2, 60)
                    continue
                raise RuntimeError(f"HTTP {e.code} from {self.url}: {e.read()[:500]!r}") from e
            except urllib.error.URLError:
                if attempt < self.max_retries:
                    time.sleep(delay)
                    delay = min(delay * 2, 60)
                    continue
                raise
        raise RuntimeError("unreachable")

    async def __call__(self, messages: list[dict], temperature: float, trace_id: str) -> Completion:
        body = {"model": self.model, "messages": messages, "temperature": temperature,
                "max_tokens": self.max_tokens}
        data = await asyncio.to_thread(self._post, body)
        text = data["choices"][0]["message"].get("content") or ""
        usage = data.get("usage") or {}
        return Completion(text, int(usage.get("prompt_tokens", 0)), int(usage.get("completion_tokens", 0)))
