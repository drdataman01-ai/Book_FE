"""Prompts for every condition.

The critique and revision prompts follow the style used in the
self-correction literature re-examined by Huang et al. (2024): the model is
asked to find problems with its own answer, then to improve it. Keep these
prompts fixed across conditions so that differences in results come from
the condition, not the wording. Changing them is a good exercise.
"""

SYSTEM_CODING = "You are a careful Python programmer."
SYSTEM_MATH = "You are a careful problem solver."

CODING_TASK = (
    "{prompt}\n\n"
    "Reply with the complete function in a single ```python code block. Include any "
    "imports it needs. Do not include tests or example usage."
)

MATH_TASK = (
    "{question}\n\n"
    "Solve the problem step by step. On the last line, write the final answer as a "
    "number in the form 'ANSWER: <number>' with no units."
)

# Used by conditions B (intrinsic) and D (oracle stopping).
CRITIQUE = (
    "Review your previous answer and find problems with it. Check the reasoning and the "
    "result carefully. Then, on the last line, write 'VERDICT: CORRECT' if the answer is "
    "correct or 'VERDICT: INCORRECT' if it is not."
)

REVISE_CODING = (
    "Based on the problems you found, write an improved solution. Reply with the complete "
    "function in a single ```python code block."
)

REVISE_MATH = (
    "Based on the problems you found, write an improved solution. On the last line, write "
    "the final answer in the form 'ANSWER: <number>'."
)

# Used by condition C (external feedback).
FEEDBACK_CODING = (
    "Your function was run against the following tests and some failed.\n\n"
    "{failures}\n\n"
    "Fix the function. Reply with the complete corrected function in a single ```python "
    "code block."
)
