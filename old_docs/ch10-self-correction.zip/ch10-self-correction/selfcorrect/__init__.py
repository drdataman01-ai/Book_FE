"""Lab 10: Can agents catch and fix their own mistakes?

Companion code for Chapter 10 of *Evaluating Agentic AI Systems: Methods,
Evidence, and Replication for AI Engineering*.

The package is framework-independent: the five experimental conditions in
`conditions.py` call a model through a small `LLM` interface and run code
through an `Executor` interface. Two front ends use it:

* `inspect_tasks.py` runs the conditions inside Inspect (the book's main
  lab engine), with Inspect's model providers and sandboxes.
* `run_local.py` runs them without Inspect, using a simulated model (for
  testing the pipeline) or any OpenAI-compatible endpoint, including local
  models served by Ollama, LM Studio or vLLM.

Both produce the same per-run records, which `analysis.py` turns into the
chapter's tables and figures.
"""

__version__ = "1.0.0"
