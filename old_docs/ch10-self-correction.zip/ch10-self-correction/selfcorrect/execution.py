"""Running model-written code against tests.

The same small harness script runs in every environment: a local
subprocess (run_local.py) or an Inspect sandbox (inspect_tasks.py). It reads
a JSON payload on stdin, executes the candidate code, runs each snippet in a
fresh copy of the namespace with a per-snippet time limit, and prints one
JSON line of results.

Safety: model-written code is untrusted. The local executor runs it in a
separate Python process with a timeout, which protects against hangs but not
against malicious code. For real models, prefer the Inspect front end with
a Docker sandbox.
"""

from __future__ import annotations

import asyncio
import json
import sys
from dataclasses import dataclass, field
from typing import Protocol

from .extract import probe_snippet

HARNESS = r'''
import contextlib, io, json, signal, sys

payload = json.loads(sys.stdin.read())
per_snippet = float(payload.get("per_snippet_timeout", 3))
out = {"compile_error": None, "results": []}

class _Timeout(Exception):
    pass

def _alarm(signum, frame):
    raise _Timeout("time limit exceeded")

has_alarm = hasattr(signal, "setitimer")
if has_alarm:
    signal.signal(signal.SIGALRM, _alarm)

ns = {"__name__": "__candidate__"}
try:
    if has_alarm:
        signal.setitimer(signal.ITIMER_REAL, per_snippet)
    with contextlib.redirect_stdout(io.StringIO()):
        exec(payload["code"], ns)
except BaseException as e:
    out["compile_error"] = (type(e).__name__ + (": " + str(e) if str(e) else ""))[:300]
finally:
    if has_alarm:
        signal.setitimer(signal.ITIMER_REAL, 0)

if out["compile_error"] is None:
    for snippet in payload["snippets"]:
        local = dict(ns)
        try:
            if has_alarm:
                signal.setitimer(signal.ITIMER_REAL, per_snippet)
            with contextlib.redirect_stdout(io.StringIO()):
                exec(snippet, local)
            if has_alarm:
                signal.setitimer(signal.ITIMER_REAL, 0)
            if payload["mode"] == "probe":
                out["results"].append({"ok": True, "value": repr(local.get("__probe__"))[:300]})
            else:
                out["results"].append({"ok": True})
        except BaseException as e:
            if has_alarm:
                signal.setitimer(signal.ITIMER_REAL, 0)
            if payload["mode"] == "probe":
                out["results"].append({"ok": False, "value": "<" + type(e).__name__ + ">"})
            else:
                out["results"].append({"ok": False, "error": (type(e).__name__ + (": " + str(e) if str(e) else ""))[:300]})

sys.stdout.write("\n__RESULT__" + json.dumps(out) + "\n")
'''


class Executor(Protocol):
    """Runs the harness with a JSON payload and returns its parsed result."""

    async def run_harness(self, payload: dict, timeout: float) -> dict: ...


def _parse(stdout: str, n: int, mode: str) -> dict:
    for line in reversed(stdout.splitlines()):
        if line.startswith("__RESULT__"):
            return json.loads(line[len("__RESULT__"):])
    return _failed(n, mode, "no result (process crashed or was killed)")


def _failed(n: int, mode: str, reason: str) -> dict:
    if mode == "probe":
        return {"compile_error": reason, "results": [{"ok": False, "value": "<Timeout>"}] * n}
    return {"compile_error": reason, "results": [{"ok": False, "error": reason}] * n}


class LocalExecutor:
    """Runs the harness in a separate local Python process (isolated mode, -I)."""

    def __init__(self, python: str = sys.executable, max_parallel: int = 8):
        self.python = python
        self._sem = asyncio.Semaphore(max_parallel)

    async def run_harness(self, payload: dict, timeout: float) -> dict:
        n, mode = len(payload["snippets"]), payload["mode"]
        async with self._sem:
            proc = await asyncio.create_subprocess_exec(
                self.python, "-I", "-c", HARNESS,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                stdout, _ = await asyncio.wait_for(
                    proc.communicate(json.dumps(payload).encode()), timeout=timeout
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                return _failed(n, mode, "Timeout: the code did not finish in time")
        return _parse(stdout.decode(errors="replace"), n, mode)


@dataclass
class TestOutcome:
    passed: bool
    n_passed: int
    n_total: int
    failures: list[tuple[str, str]] = field(default_factory=list)  # (test source, error)


async def run_tests(executor: Executor, code: str, tests: list[str], timeout: float = 20) -> TestOutcome:
    if not tests:
        return TestOutcome(True, 0, 0)
    payload = {"code": code, "snippets": tests, "mode": "tests", "per_snippet_timeout": 3}
    res = await executor.run_harness(payload, timeout)
    if res.get("compile_error"):
        err = res["compile_error"]
        return TestOutcome(False, 0, len(tests), [(t, err) for t in tests])
    results = res["results"]
    failures = [(t, r.get("error", "")) for t, r in zip(tests, results) if not r["ok"]]
    n_passed = sum(r["ok"] for r in results)
    return TestOutcome(n_passed == len(tests), n_passed, len(tests), failures)


async def probe_values(executor: Executor, code: str, tests: list[str], timeout: float = 20) -> tuple | None:
    """Record what the code returns on each test's inputs, without checking outputs.

    Returns None if the code does not compile; otherwise a tuple of repr
    strings (or exception names) used as the candidate's behavioural
    signature for majority voting.
    """
    snippets = [s for s in (probe_snippet(t) for t in tests) if s]
    if not snippets:
        return None
    payload = {"code": code, "snippets": snippets, "mode": "probe", "per_snippet_timeout": 3}
    res = await executor.run_harness(payload, timeout)
    if res.get("compile_error"):
        return None
    return tuple(r["value"] for r in res["results"])


async def describe_failures(executor: Executor, code: str, failures: list[tuple[str, str]], limit: int = 3) -> str:
    """Format failing tests for the agent, including what the code returned."""
    parts = []
    for test, error in failures[:limit]:
        got = ""
        snippet = probe_snippet(test)
        if snippet:
            payload = {"code": code, "snippets": [snippet], "mode": "probe", "per_snippet_timeout": 3}
            res = await executor.run_harness(payload, 20)
            if not res.get("compile_error") and res["results"]:
                got = res["results"][0]["value"]
        msg = f"Test:\n{test}\nResult: {error or 'AssertionError'}"
        if got:
            msg += f"\nYour function returned: {got}"
        parts.append(msg)
    return "\n\n".join(parts)
