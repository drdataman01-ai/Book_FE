"""The five experimental conditions of Lab 10.

  A  single     Answer once.
  B  intrinsic  Critique own answer and revise, up to `max_rounds` rounds.
                Stops when the model judges its answer correct.
  C  external   Run the visible tests and revise using the failures, up to
                `max_rounds` rounds. Stops when the visible tests pass.
                Coding tasks only.
  D  oracle     Same critique and revise prompts as B, but stops only when the
                answer is actually correct. Uses the answer key, so it is not
                available in practice; included to reproduce the artifact
                described in Section 10.3.
  E  vote       Sample `vote_k` independent answers. The analysis selects by
                majority vote using the first m samples for any budget m, so
                it can be compared with B and C at equal cost. For coding it
                also reports "sample and filter" (pick the first sample that
                passes the visible tests), the equal-cost counterpart of C.

Every condition returns one record (a dict) per task attempt. Correctness is
checked after every round for analysis only; the agent never sees it except
in condition D, where it decides when to stop.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from . import prompts
from .execution import Executor, describe_failures, probe_values, run_tests
from .extract import extract_code, extract_number, extract_verdict, numbers_match
from .tasks import Task

CONDITIONS = {
    "A": "single",
    "B": "intrinsic",
    "C": "external",
    "D": "oracle",
    "E": "vote",
}


@dataclass
class Completion:
    text: str
    input_tokens: int = 0
    output_tokens: int = 0


class LLM(Protocol):
    """Any chat model: takes a message list, returns a Completion.

    `trace_id` identifies the call (task, condition, epoch, step). Real
    backends ignore it; the simulated model uses it for reproducible
    randomness.
    """

    async def __call__(self, messages: list[dict], temperature: float, trace_id: str) -> Completion: ...


@dataclass
class Settings:
    max_rounds: int = 2
    vote_k: int = 8
    temperature: float = 0.7
    exec_timeout: float = 20.0


@dataclass
class _Meter:
    """Counts model calls and tokens for one task attempt."""

    llm: LLM
    temperature: float
    calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    log: list[dict] = field(default_factory=list)

    async def __call__(self, messages: list[dict], trace_id: str) -> str:
        c = await self.llm(messages, temperature=self.temperature, trace_id=trace_id)
        self.calls += 1
        self.input_tokens += c.input_tokens
        self.output_tokens += c.output_tokens
        return c.text


def _opening(task: Task) -> list[dict]:
    if task.task_type == "coding":
        return [
            {"role": "system", "content": prompts.SYSTEM_CODING},
            {"role": "user", "content": prompts.CODING_TASK.format(prompt=task.prompt)},
        ]
    return [
        {"role": "system", "content": prompts.SYSTEM_MATH},
        {"role": "user", "content": prompts.MATH_TASK.format(question=task.question)},
    ]


def _answer_of(task: Task, text: str):
    return extract_code(text) if task.task_type == "coding" else extract_number(text)


async def _grade(task: Task, answer, executor: Executor, settings: Settings) -> bool:
    """True if the answer is correct (all visible and hidden tests, or the right number)."""
    if task.task_type == "coding":
        outcome = await run_tests(executor, answer, task.all_tests, settings.exec_timeout)
        return outcome.passed
    return numbers_match(answer, task.answer)


def _short(answer) -> str:
    s = answer if isinstance(answer, str) else repr(answer)
    return s if len(s) <= 4000 else s[:4000] + "\n...[truncated]"


def _record(task: Task, condition: str, epoch: int, meter: _Meter, rounds: list[dict], stop_reason: str,
            settings: Settings) -> dict:
    # Correctness after each round, carried forward once the agent stops.
    by_round = [r["correct"] for r in rounds]
    by_round += [by_round[-1]] * (settings.max_rounds + 1 - len(by_round))
    return {
        "task_id": task.id,
        "task_type": task.task_type,
        "source": task.source,
        "condition": condition,
        "condition_name": CONDITIONS[condition],
        "epoch": epoch,
        "initial_correct": rounds[0]["correct"],
        "final_correct": rounds[-1]["correct"],
        "correct_by_round": by_round,
        "rounds_used": len(rounds) - 1,
        "stop_reason": stop_reason,
        "calls": meter.calls,
        "input_tokens": meter.input_tokens,
        "output_tokens": meter.output_tokens,
        "rounds": rounds,
        "max_rounds": settings.max_rounds,
    }


async def run_single(task, llm, executor, settings, epoch=0) -> dict:
    meter = _Meter(llm, settings.temperature)
    trace = f"{task.id}|A|{epoch}"
    text = await meter(_opening(task), f"{trace}|answer0")
    answer = _answer_of(task, text)
    rounds = [{"round": 0, "correct": await _grade(task, answer, executor, settings), "answer": _short(answer)}]
    return _record(task, "A", epoch, meter, rounds, "single_attempt", settings)


async def _critique_revise_loop(task, llm, executor, settings, epoch, condition: str) -> dict:
    """Shared by B (stop on self-verdict) and D (stop on the answer key)."""
    meter = _Meter(llm, settings.temperature)
    trace = f"{task.id}|{condition}|{epoch}"
    messages = _opening(task)
    text = await meter(messages, f"{trace}|answer0")
    answer = _answer_of(task, text)
    correct = await _grade(task, answer, executor, settings)
    rounds = [{"round": 0, "correct": correct, "answer": _short(answer)}]
    stop_reason = "max_rounds"
    revise = prompts.REVISE_CODING if task.task_type == "coding" else prompts.REVISE_MATH

    for r in range(1, settings.max_rounds + 1):
        if condition == "D" and correct:
            stop_reason = "oracle_correct"
            break
        messages = messages + [{"role": "assistant", "content": text},
                               {"role": "user", "content": prompts.CRITIQUE}]
        critique = await meter(messages, f"{trace}|critique{r}")
        verdict = extract_verdict(critique)
        if condition == "B" and verdict != "INCORRECT":
            stop_reason = "self_judged_correct" if verdict == "CORRECT" else "no_verdict"
            rounds[-1]["next_verdict"] = verdict
            break
        messages = messages + [{"role": "assistant", "content": critique},
                               {"role": "user", "content": revise}]
        text = await meter(messages, f"{trace}|answer{r}")
        answer = _answer_of(task, text)
        correct = await _grade(task, answer, executor, settings)
        rounds[-1]["next_verdict"] = verdict
        rounds.append({"round": r, "correct": correct, "answer": _short(answer)})
    else:
        if condition == "D" and correct:
            stop_reason = "oracle_correct"

    return _record(task, condition, epoch, meter, rounds, stop_reason, settings)


async def run_intrinsic(task, llm, executor, settings, epoch=0) -> dict:
    return await _critique_revise_loop(task, llm, executor, settings, epoch, "B")


async def run_oracle(task, llm, executor, settings, epoch=0) -> dict:
    return await _critique_revise_loop(task, llm, executor, settings, epoch, "D")


async def run_external(task, llm, executor, settings, epoch=0) -> dict:
    if task.task_type != "coding":
        raise ValueError("Condition C (external feedback) applies to coding tasks only.")
    meter = _Meter(llm, settings.temperature)
    trace = f"{task.id}|C|{epoch}"
    messages = _opening(task)
    text = await meter(messages, f"{trace}|answer0")
    code = extract_code(text)
    rounds = [{"round": 0, "correct": await _grade(task, code, executor, settings), "answer": _short(code)}]
    stop_reason = "max_rounds"

    for r in range(1, settings.max_rounds + 1):
        visible = await run_tests(executor, code, task.visible_tests, settings.exec_timeout)
        if visible.passed:
            stop_reason = "visible_tests_pass"
            break
        feedback = await describe_failures(executor, code, visible.failures)
        rounds[-1]["feedback"] = feedback[:2000]
        messages = messages + [{"role": "assistant", "content": text},
                               {"role": "user", "content": prompts.FEEDBACK_CODING.format(failures=feedback)}]
        text = await meter(messages, f"{trace}|answer{r}")
        code = extract_code(text)
        rounds.append({"round": r, "correct": await _grade(task, code, executor, settings), "answer": _short(code)})
    else:
        visible = await run_tests(executor, code, task.visible_tests, settings.exec_timeout)
        if visible.passed:
            stop_reason = "visible_tests_pass"

    return _record(task, "C", epoch, meter, rounds, stop_reason, settings)


async def run_vote(task, llm, executor, settings, epoch=0) -> dict:
    meter = _Meter(llm, settings.temperature)
    trace = f"{task.id}|E|{epoch}"
    candidates = []
    for i in range(settings.vote_k):
        text = await meter(_opening(task), f"{trace}|sample{i}")
        answer = _answer_of(task, text)
        cand = {"index": i, "correct": await _grade(task, answer, executor, settings)}
        if task.task_type == "coding":
            visible = await run_tests(executor, answer, task.visible_tests, settings.exec_timeout)
            sig = await probe_values(executor, answer, task.all_tests, settings.exec_timeout)
            cand["visible_pass"] = visible.passed
            cand["signature"] = list(sig) if sig is not None else None
        else:
            cand["value"] = answer
        candidates.append(cand)

    final_correct = vote_correct(candidates, settings.vote_k, task.task_type)
    rounds = [{"round": 0, "correct": candidates[0]["correct"], "answer": "(sample 0)"}]
    rec = _record(task, "E", epoch, meter, rounds, "vote", settings)
    rec["final_correct"] = final_correct
    rec["correct_by_round"] = [final_correct] * (settings.max_rounds + 1)
    rec["candidates"] = candidates
    rec["vote_k"] = settings.vote_k
    return rec


def _key(c: dict, task_type: str):
    if task_type == "coding":
        return tuple(c["signature"]) if c.get("signature") is not None else None
    v = c.get("value")
    return None if v is None else round(float(v), 4)


def vote_correct(candidates: list[dict], m: int, task_type: str) -> bool:
    """Majority vote over the first m candidates; ties go to the earliest answer."""
    pool = candidates[:m]
    counts: dict = {}
    first_seen: dict = {}
    for c in pool:
        k = _key(c, task_type)
        if k is None:
            continue
        counts[k] = counts.get(k, 0) + 1
        first_seen.setdefault(k, c)
    if not counts:
        return bool(pool and pool[0]["correct"])
    best = max(counts, key=lambda k: (counts[k], -first_seen[k]["index"]))
    return bool(first_seen[best]["correct"])


def filter_correct(candidates: list[dict], m: int) -> bool:
    """Sample and filter: first of the first m candidates that passes the visible tests."""
    pool = candidates[:m]
    for c in pool:
        if c.get("visible_pass"):
            return bool(c["correct"])
    return vote_correct(candidates, m, "coding")


RUNNERS = {
    "A": run_single,
    "B": run_intrinsic,
    "C": run_external,
    "D": run_oracle,
    "E": run_vote,
}


async def run_condition(condition: str, task: Task, llm: LLM, executor: Executor,
                        settings: Settings, epoch: int = 0) -> dict:
    return await RUNNERS[condition](task, llm, executor, settings, epoch)
