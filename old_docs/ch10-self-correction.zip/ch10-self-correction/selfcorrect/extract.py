"""Extract code, numeric answers and verdicts from model text."""

from __future__ import annotations

import ast
import re

_CODE_BLOCK = re.compile(r"```(?:python|py)?[ \t]*\n(.*?)```", re.DOTALL | re.IGNORECASE)
_ANSWER = re.compile(r"ANSWER\s*[:=]\s*\$?\s*(-?[\d,]*\.?\d+)", re.IGNORECASE)
_NUMBER = re.compile(r"-?\d[\d,]*\.?\d*|-?\.\d+")
_VERDICT = re.compile(r"VERDICT\s*[:=]\s*\**\s*(CORRECT|INCORRECT)", re.IGNORECASE)


def extract_code(text: str) -> str:
    """Return the last fenced code block, or the whole text if there is none."""
    blocks = _CODE_BLOCK.findall(text or "")
    return (blocks[-1] if blocks else (text or "")).strip() + "\n"


def extract_number(text: str) -> float | None:
    """Return the number after the last 'ANSWER:', else the last number in the text."""
    text = text or ""
    matches = _ANSWER.findall(text)
    raw = matches[-1] if matches else None
    if raw is None:
        numbers = _NUMBER.findall(text)
        raw = numbers[-1] if numbers else None
    if raw is None:
        return None
    try:
        return float(raw.replace(",", ""))
    except ValueError:
        return None


def extract_verdict(text: str) -> str | None:
    """Return 'CORRECT', 'INCORRECT' or None if the model gave no verdict."""
    matches = _VERDICT.findall(text or "")
    return matches[-1].upper() if matches else None


def numbers_match(a: float | None, b: float | None, abs_tol: float = 0.01, rel_tol: float = 1e-4) -> bool:
    if a is None or b is None:
        return False
    return abs(a - b) <= max(abs_tol, rel_tol * abs(b))


def probe_snippet(test: str) -> str | None:
    """Turn a test into a snippet that records what the function returns.

    'assert f(x) == y'  ->  '__probe__ = f(x)'
    A try/except test   ->  '__probe__ = <first call in the try body>'

    Probes record behaviour without using the expected output, so voting on
    probe results (condition E) does not use the answer key.
    """
    try:
        tree = ast.parse(test)
    except SyntaxError:
        return None
    setup: list[str] = []
    for node in tree.body:
        if isinstance(node, ast.Assert):
            expr = node.test
            if isinstance(expr, ast.Compare):
                expr = expr.left
            elif isinstance(expr, ast.BoolOp) and expr.values and isinstance(expr.values[0], ast.Compare):
                expr = expr.values[0].left
            return "\n".join(setup + [f"__probe__ = {ast.unparse(expr)}"])
        if isinstance(node, ast.Try) and node.body and isinstance(node.body[0], ast.Expr):
            return "\n".join(setup + [f"__probe__ = {ast.unparse(node.body[0].value)}"])
        setup.append(ast.unparse(node))
    return None
