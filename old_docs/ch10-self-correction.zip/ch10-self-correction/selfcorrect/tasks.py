"""Load task sets from the JSONL files in data/."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"

TASK_FILES = {
    ("coding", "fresh"): "fresh_coding.jsonl",
    ("math", "fresh"): "fresh_math.jsonl",
    ("coding", "public"): "public_coding.jsonl",
    ("math", "public"): "public_math.jsonl",
}


@dataclass
class Task:
    id: str
    task_type: str  # "coding" or "math"
    source: str  # "fresh" or "public"
    prompt: str = ""  # coding
    entry_point: str = ""  # coding
    visible_tests: list[str] = field(default_factory=list)  # coding: may be shown to the agent
    hidden_tests: list[str] = field(default_factory=list)  # coding: never shown
    reference: str | None = None  # coding: correct solution (used by the mock model only)
    buggy: str | None = None  # coding: plausible wrong solution (mock model only)
    question: str = ""  # math
    answer: float | None = None  # math

    @property
    def all_tests(self) -> list[str]:
        return self.visible_tests + self.hidden_tests

    @classmethod
    def from_dict(cls, d: dict) -> "Task":
        keys = cls.__dataclass_fields__.keys()
        return cls(**{k: v for k, v in d.items() if k in keys})

    def to_dict(self) -> dict:
        return {k: getattr(self, k) for k in self.__dataclass_fields__}


def load_tasks(
    task_types: list[str] | tuple[str, ...] = ("coding", "math"),
    sources: list[str] | tuple[str, ...] = ("fresh",),
    limit: int | None = None,
    data_dir: Path = DATA_DIR,
) -> list[Task]:
    """Load tasks. `limit` caps the number of tasks per (type, source) file."""
    tasks: list[Task] = []
    for task_type in task_types:
        for source in sources:
            path = data_dir / TASK_FILES[(task_type, source)]
            if not path.exists():
                hint = (
                    "run `python data/prepare_public.py`" if source == "public"
                    else "run `python data/build_fresh_tasks.py`"
                )
                raise FileNotFoundError(f"{path} not found; {hint}")
            with open(path) as f:
                rows = [json.loads(line) for line in f if line.strip()]
            if limit is not None:
                rows = rows[:limit]
            tasks.extend(Task.from_dict(r) for r in rows)
    return tasks
