# Lab 10: Can Agents Catch and Fix Their Own Mistakes?

Companion lab for **Chapter 10** of *Evaluating Agentic AI Systems: Methods, Evidence, and Replication for AI Engineering*.

**Question.** Does revision improve an agent's accuracy at equal cost, and does it matter whether the corrective signal comes from the model itself or from the outside world?

The lab runs the same model under five conditions on two kinds of tasks:

- **Coding tasks with unit tests.** The outside world can check the agent's work.
- **Math word problems with no checker.** The agent has only its own judgment.

Comparing the two task types separates the source of the corrective signal, which is the central idea of the chapter.

## Quick start (simulated model, no API key, about 1 minute)

```bash
pip install -r requirements.txt
python data/build_fresh_tasks.py          # validates and writes the fresh task sets
python run_local.py --backend sim --model sim-standard --epochs 10
python analysis.py results/sim-standard.jsonl --out report/
```

Open `report/report.md` to see the tables and figures.

> **The simulated model is not evidence.** It answers right or wrong with fixed, invented probabilities so you can check that the code, statistics and figures work before spending money. Every simulated chart is labeled as such.

## The five conditions

| | Condition | What the agent does | Stops when |
|---|---|---|---|
| A | Single attempt | Answers once | — |
| B | Intrinsic self-correction | Critiques its own answer and revises, up to 2 rounds | It judges its answer correct |
| C | External feedback (coding only) | Runs the visible tests and revises using the failures, up to 2 rounds | The visible tests pass |
| D | Oracle stopping | Same prompts as B | The answer is actually correct (uses the answer key; **not available in practice**) |
| E | Majority vote | Samples 8 independent answers and votes | — |

Condition E is scored at several budgets from the same samples, so it can be compared with B and C **at equal cost**:

- **E@k:** vote over all 8 samples.
- **E=B and E=C:** vote using as many samples as B or C used calls on average.
- **F=C** (coding only): *sample and filter*. Take the first sample that passes the visible tests. This is the fair equal-cost counterpart of C, because both use the visible tests.

F is an addition to the five conditions listed in the chapter draft. Without it, the comparison of C against E would pit an agent that sees test results against one that doesn't.

For coding, "voting" groups candidates by what their functions **return** on the test inputs, without looking at the expected outputs. No answer key is used.

## What you get

`analysis.py` writes `report/report.md`, CSV tables and four figures for each model:

| Output | What it answers |
|---|---|
| Table 1 / Figure 10.1: accuracy by condition, with 95% confidence intervals | How accurate is each condition? |
| Table 2: paired comparisons on the same tasks | Is the difference between two conditions real? |
| Table 3 / Figure 10.2: flip table | How often does revision turn wrong answers right, and right answers wrong? |
| Figure 10.3: accuracy by revision round | Where do the gains level off? |
| Table 4 / Figure 10.4: cost, and accuracy against model calls | Is revision worth what it costs, compared with voting at every budget? |

Confidence intervals come from a bootstrap that resamples **tasks**, because repeated epochs of one task are not independent (Chapter 5). The "all epochs correct" column is a reliability measure in the spirit of pass^k.

Add `--price-in` and `--price-out` (dollars per million tokens) to get dollars per correct answer.

## Running on real models

### With Inspect (recommended)

[Inspect](https://inspect.aisi.org.uk/) is the book's main lab engine. It supports most model providers and runs model-written code in a Docker sandbox (`compose.yaml`: no network, 1 GB memory).

```bash
pip install inspect-ai
# set your provider's API key, e.g. export OPENAI_API_KEY=...

# one condition
inspect eval inspect_tasks.py@self_correction -T condition=B -T task_type=coding \
    --model <provider/model> --epochs 10

# the whole lab
python run_inspect.py --model <provider/model> --epochs 10

# convert logs and analyse
python export_inspect_logs.py logs/ --out results/inspect.jsonl
python analysis.py results/inspect.jsonl --out report/
```

`inspect view` lets you read every conversation and model call. Use it to check failures by hand before trusting any number.

### Without Inspect (any OpenAI-compatible endpoint)

`run_local.py` works with OpenAI or with local models served by Ollama, LM Studio or vLLM:

```bash
# local model through Ollama
python run_local.py --backend openai --base-url http://localhost:11434/v1 \
    --model qwen2.5-coder:7b --epochs 10
```

Model-written code runs in a separate local Python process with time limits. That guards against hangs, **not** against harmful code. Prefer the Inspect route with Docker for anything you don't fully trust.

### Cost and time

Per model and epoch, a coding task uses up to 22 calls across all conditions (A 1, B up to 5, C up to 3, D up to 5, E 8) and a math task up to 19. The full lab (40 fresh tasks, 10 epochs) is therefore at most about 8,200 calls per model. Start small:

```bash
python run_inspect.py --model <provider/model> --epochs 3   # or: run_local.py ... --epochs 3 --limit 5
```

`run_local.py` prints an estimate and asks for confirmation before calling a paid API.

## Stress tests (Section 10.5)

| Stress test | How to run it |
|---|---|
| 1. Equal compute | Already built in: Figure 10.4 plots voting at every budget from 1 to 8 calls. |
| 2. Cost per correct answer | Table 4; add `--price-in` and `--price-out` for dollars. |
| 3. Diminishing returns | Re-run B, C and D with `--max-rounds 5` (`run_local.py`) or `-T max_rounds=5` (Inspect). |
| 4. Model generation and task freshness | Run several models (a standard model, a reasoning model, a small local model). Add public tasks with `python data/prepare_public.py` and `--sources fresh,public`. |

## Task sets

- `data/fresh_coding.jsonl` has 20 Python functions written for this book. Each has one visible test (the agent may see it in condition C) and 4–7 hidden tests (never shown). Each task's reference solution is checked against all its tests, and each buggy solution, used only by the simulated model, must fail at least one hidden test.
- `data/fresh_math.jsonl` has 20 multi-step word problems. Each answer is computed from a worked expression rather than typed by hand.
- `data/prepare_public.py` downloads public counterparts (MBPP for coding, GSM8K for math) with the Hugging Face `datasets` package. Public tasks may be in a model's training data, which is why the lab compares them with fresh ones.

To add tasks, edit `data/build_fresh_tasks.py` and re-run it; the script refuses tasks whose reference solution fails a test.

## Folder contents

```text
ch10-self-correction/
├── README.md
├── requirements.txt
├── compose.yaml               # Docker sandbox for Inspect
├── inspect_tasks.py           # the lab as an Inspect task
├── run_inspect.py             # run every condition in Inspect
├── export_inspect_logs.py     # Inspect logs -> JSONL records
├── run_local.py               # run without Inspect (simulated or OpenAI-compatible)
├── analysis.py                # tables, figures and report
├── data/
│   ├── build_fresh_tasks.py   # fresh tasks, with validation
│   ├── fresh_coding.jsonl
│   ├── fresh_math.jsonl
│   └── prepare_public.py      # MBPP and GSM8K
├── selfcorrect/
│   ├── conditions.py          # the five conditions (framework-independent)
│   ├── prompts.py             # all prompts, fixed across conditions
│   ├── execution.py           # test harness and executors
│   ├── extract.py             # parsing code, answers and verdicts
│   ├── backends.py            # simulated model, OpenAI-compatible client
│   └── tasks.py
└── tests/
    ├── test_pipeline.py       # end-to-end checks with the simulated model
    └── test_inspect_adapter.py
```

## Verification status

| Part | Status |
|---|---|
| Fresh task sets (references pass, buggy versions fail) | Tested |
| Five conditions, test harness, voting and filtering rules | Tested with the simulated model |
| Analysis, tables and figures | Tested with the simulated model |
| `inspect_tasks.py` wiring | Tested against a stand-in for Inspect's API; **confirm with one real `inspect eval` run** |
| `prepare_public.py` (MBPP, GSM8K download) | Not yet run; confirm the dataset names and fields on first use |
| OpenAI-compatible client | Not yet run against a live endpoint |

Run the tests with `python tests/test_pipeline.py` and `python tests/test_inspect_adapter.py` (or `pytest tests/`).

## Exercises

Chapter 10's exercises 6–10 extend this lab:

6. Compare A, B and E at three budgets.
7. Report flip tables for 5 rounds.
8. Use a different model as the critic: add an `LLM` that routes critique prompts elsewhere.
9. Give the math tasks a calculator tool.
10. Repeat the lab on 20 tasks from your own domain.
