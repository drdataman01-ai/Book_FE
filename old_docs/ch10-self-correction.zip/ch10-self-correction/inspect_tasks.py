"""Lab 10 as Inspect tasks.

Inspect (https://inspect.aisi.org.uk/) is the book's main lab engine. This
file wraps the five conditions in `selfcorrect/conditions.py` as an Inspect
task, so you can use any model provider Inspect supports and run model-written
code in a Docker sandbox.

Run one condition:
    inspect eval inspect_tasks.py@self_correction \\
        -T condition=B -T task_type=coding --model <provider/model> --epochs 10

Run the whole lab (all conditions, both task types):
    python run_inspect.py --model <provider/model> --epochs 10

Then convert the logs and analyse them:
    python export_inspect_logs.py logs/ --out results/inspect.jsonl
    python analysis.py results/inspect.jsonl --out report/

Coding tasks run in the Docker sandbox defined in compose.yaml (no network,
1 GB memory). Use -T sandbox_type=local only for trusted, local testing.
"""

from __future__ import annotations

import json

from inspect_ai import Task, task
from inspect_ai.dataset import MemoryDataset, Sample
from inspect_ai.model import (
    ChatMessageAssistant,
    ChatMessageSystem,
    ChatMessageUser,
    GenerateConfig,
    get_model,
)
from inspect_ai.scorer import CORRECT, INCORRECT, Score, Target, accuracy, scorer, stderr
from inspect_ai.solver import Generate, TaskState, solver
from inspect_ai.util import sandbox

from selfcorrect.conditions import CONDITIONS, Completion, Settings, run_condition
from selfcorrect.execution import HARNESS, _failed, _parse
from selfcorrect.tasks import Task as LabTask
from selfcorrect.tasks import load_tasks

_ROLE = {"system": ChatMessageSystem, "user": ChatMessageUser, "assistant": ChatMessageAssistant}


class InspectLLM:
    """Adapts Inspect's model API to the lab's LLM interface."""

    def __init__(self, model):
        self.model = model

    async def __call__(self, messages: list[dict], temperature: float, trace_id: str) -> Completion:
        chat = [_ROLE[m["role"]](content=m["content"]) for m in messages]
        output = await self.model.generate(chat, config=GenerateConfig(temperature=temperature))
        usage = output.usage
        return Completion(
            output.completion,
            getattr(usage, "input_tokens", 0) or 0,
            getattr(usage, "output_tokens", 0) or 0,
        )


class SandboxExecutor:
    """Runs the test harness inside the task's Inspect sandbox."""

    async def run_harness(self, payload: dict, timeout: float) -> dict:
        n, mode = len(payload["snippets"]), payload["mode"]
        try:
            result = await sandbox().exec(
                ["python3", "-I", "-c", HARNESS], input=json.dumps(payload), timeout=int(timeout)
            )
        except TimeoutError:
            return _failed(n, mode, "Timeout: the code did not finish in time")
        return _parse(result.stdout, n, mode)


class _NoExecutor:
    async def run_harness(self, payload: dict, timeout: float) -> dict:
        raise RuntimeError("math tasks do not execute code")


@solver
def lab10_condition(condition: str, settings: Settings):
    async def solve(state: TaskState, generate: Generate) -> TaskState:
        lab_task = LabTask.from_dict(state.metadata["task"])
        executor = SandboxExecutor() if lab_task.task_type == "coding" else _NoExecutor()
        record = await run_condition(
            condition, lab_task, InspectLLM(get_model()), executor, settings,
            epoch=getattr(state, "epoch", 0),
        )
        state.metadata["record"] = record
        return state

    return solve


@scorer(metrics=[accuracy(), stderr()])
def lab10_scorer():
    async def score(state: TaskState, target: Target) -> Score:
        record = state.metadata.get("record")
        if record is None:
            return Score(value=INCORRECT, explanation="condition did not produce a record")
        return Score(
            value=CORRECT if record["final_correct"] else INCORRECT,
            answer=str(record["rounds"][-1]["answer"])[:500],
            explanation=f"stop reason: {record['stop_reason']}; calls: {record['calls']}",
            metadata=record,
        )

    return score


@task
def self_correction(
    condition: str = "B",
    task_type: str = "coding",
    source: str = "fresh",
    max_rounds: int = 2,
    vote_k: int = 8,
    temperature: float = 0.7,
    sandbox_type: str = "docker",
):
    condition = condition.upper()
    if condition not in CONDITIONS:
        raise ValueError(f"condition must be one of {list(CONDITIONS)}")
    if condition == "C" and task_type != "coding":
        raise ValueError("condition C (external feedback) applies to coding tasks only")

    lab_tasks = load_tasks([task_type], [source])
    samples = [
        Sample(
            id=t.id,
            input=t.prompt if t.task_type == "coding" else t.question,
            target="all tests pass" if t.task_type == "coding" else str(t.answer),
            metadata={"task": t.to_dict()},
        )
        for t in lab_tasks
    ]
    settings = Settings(max_rounds=max_rounds, vote_k=vote_k, temperature=temperature)
    return Task(
        dataset=MemoryDataset(samples, name=f"lab10-{task_type}-{source}"),
        solver=lab10_condition(condition, settings),
        scorer=lab10_scorer(),
        sandbox=sandbox_type if task_type == "coding" else None,
        metadata={"lab": "chapter-10", "condition": condition, "task_type": task_type, "source": source},
    )
