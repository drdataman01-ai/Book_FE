"""Lab 23: Can Language Models Read the News and Earn Returns?

Chapter 23 of *Financial Engineering and the Evidence: A Claim-Verify
Approach to Quantitative Finance*.

CLAIM ON TRIAL
  "Text-based signals predict stock returns, and large language models
   extract them best."

WHAT THE LAB DOES
  Part A  Dictionaries: score every headline with the Loughran-McDonald
          finance dictionary and with a general-purpose word list; show
          which everyday words mislabel financial text.
  Part B  Returns: abnormal returns on the first tradable day and over the
          following month by score; daily long-short portfolios; daily
          cross-sectional regressions. Optional scorers: an LLM (Anthropic
          or any OpenAI-compatible endpoint, including a local model) and
          FinBERT.
  Part C  Look-ahead: results before and after the model's knowledge
          cutoff; named versus anonymized headlines; a deliberately leaky
          scorer shows what look-ahead looks like.
  Part D  Costs and decay: net of 5-20 bp, and year by year.

DATA
  Headlines: any CSV with a date or timestamp, a ticker and a headline
  (see README for free sources). Daily prices: Stooq (free, no key) or your
  own file. Market return: Kenneth R. French daily factors.
  Loughran-McDonald Master Dictionary: free from the Software Repository
  for Accounting and Finance, University of Notre Dame.

USAGE
  python lab23.py --news-file data/headlines.csv --lm-file data/LM_MasterDictionary.csv
  python lab23.py --news-file ... --llm-provider anthropic --llm-model MODEL_ID --cutoff 2025-01-01
  python lab23.py --source sim
"""

from __future__ import annotations

import argparse
import io
import json
import math
import time
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd

from fintest import plots
from fintest.data import DataUnavailable, load_french_factors
from fintest.text import (Dictionary, FinBERTScorer, LLMScorer, assign_trade_date, daily_cross_section,
                          event_returns, general_dictionary, leaky_scores, long_short_daily, ls_stats,
                          misclassification, read_lm_dictionary, simulated_llm_scores, simulated_news)

ROOT = Path(__file__).resolve().parent
LEAKY = "Leaky scorer (look-ahead demo)"
PALETTE = [plots.INK, plots.INK_3, plots.BLUE, plots.VIOLET, plots.GREEN, plots.ORANGE, plots.RED]


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------


def _pick(cols, *names):
    low = {c.lower().strip(): c for c in cols}
    for n in names:
        if n in low:
            return low[n]
    return None


def read_news(path) -> pd.DataFrame:
    df = pd.read_csv(path)
    tcol = _pick(df.columns, "timestamp", "datetime", "published", "date", "time")
    hcol = _pick(df.columns, "headline", "title", "text")
    kcol = _pick(df.columns, "ticker", "stock", "symbol")
    ccol = _pick(df.columns, "company", "name", "company_name")
    if not (tcol and hcol and kcol):
        raise DataUnavailable(f"The news file needs date/timestamp, ticker and headline columns; found {list(df.columns)}")
    try:
        ts = pd.to_datetime(df[tcol], errors="coerce")
        if not pd.api.types.is_datetime64_any_dtype(ts):
            raise ValueError
    except (ValueError, TypeError):                       # mixed UTC offsets
        ts = pd.to_datetime(df[tcol], errors="coerce", utc=True)
    if getattr(ts.dt, "tz", None) is not None:          # time-zone aware: convert to New York time
        ts = ts.dt.tz_convert("America/New_York").dt.tz_localize(None)
    out = pd.DataFrame({"timestamp": ts, "ticker": df[kcol].astype(str).str.upper().str.strip(),
                        "headline": df[hcol].astype(str)})
    if ccol:
        out["company"] = df[ccol].astype(str)
    return out.dropna(subset=["timestamp"]).drop_duplicates(subset=["timestamp", "ticker", "headline"])


def stooq_returns(tickers, cache: Path, pause: float = 0.3) -> pd.DataFrame:
    """Daily close-to-close returns from Stooq (https://stooq.com), cached as CSV per ticker. US tickers only."""
    cache.mkdir(parents=True, exist_ok=True)
    out = {}
    for tk in tickers:
        f = cache / f"{tk.lower()}.csv"
        if not f.exists():
            url = f"https://stooq.com/q/d/l/?s={tk.lower().replace('.', '-')}.us&i=d"
            try:
                with urllib.request.urlopen(url, timeout=30) as r:
                    f.write_bytes(r.read())
                time.sleep(pause)
            except Exception as e:  # noqa: BLE001
                print(f"  {tk}: download failed ({e})")
                continue
        try:
            px = pd.read_csv(f, parse_dates=["Date"]).set_index("Date")["Close"]
            out[tk] = px.pct_change()
        except Exception:  # noqa: BLE001
            continue
    if not out:
        raise DataUnavailable("No prices could be downloaded from Stooq; pass --returns-file instead.")
    return pd.DataFrame(out).sort_index()


def read_returns(path) -> pd.DataFrame:
    """Long (date, ticker, ret) or wide (date x tickers) daily returns in decimals."""
    df = pd.read_csv(path)
    dcol = _pick(df.columns, "date")
    if _pick(df.columns, "ticker") and _pick(df.columns, "ret", "return"):
        df = df.pivot_table(index=dcol, columns=_pick(df.columns, "ticker"), values=_pick(df.columns, "ret", "return"))
    else:
        df = df.set_index(dcol)
    df.index = pd.to_datetime(df.index)
    return df.sort_index()


def load(args) -> dict:
    if args.source == "sim":
        d = simulated_news(seed=args.sim_seed)
        return {**d, "finance_dict": d["dictionary"], "notes": []}
    if not args.news_file:
        raise DataUnavailable("Pass --news-file (see README), or use --source sim to test the code.")
    news = read_news(args.news_file)
    tickers = news["ticker"].value_counts().index[:args.max_tickers]
    news = news[news["ticker"].isin(tickers)]
    ret = read_returns(args.returns_file) if args.returns_file else stooq_returns(tickers, ROOT / "data" / "stooq")
    notes = []
    try:
        dd = load_french_factors("ff3_daily", path=args.ff3d_file)
        col = lambda n: dd[[c for c in dd.columns if c.strip().upper() == n][0]]  # noqa: E731
        mkt = (col("MKT-RF") + col("RF"))
        mkt.index = pd.to_datetime(mkt.index)
        abret = ret.sub(mkt.reindex(ret.index), axis=0)
    except DataUnavailable as e:
        notes.append(f"daily market return not loaded ({str(e).splitlines()[0]}); using raw returns minus the "
                     "cross-sectional average")
        abret = ret.sub(ret.mean(axis=1), axis=0)
    fin = None
    if args.lm_file:
        fin = read_lm_dictionary(args.lm_file)
    else:
        notes.append("no Loughran-McDonald file given; finance dictionary skipped")
    return {"news": news, "abret": abret, "finance_dict": fin, "simulated": False, "notes": notes}


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------


def score(d: dict, args) -> tuple[pd.DataFrame, list[str]]:
    news = d["news"].copy()
    names = []
    gen = general_dictionary()
    if d.get("finance_dict") is not None:
        news[d["finance_dict"].name] = d["finance_dict"].score_many(news["headline"])
        names.append(d["finance_dict"].name)
    news[gen.name] = gen.score_many(news["headline"])
    names.append(gen.name)
    if d["simulated"]:
        n = "LLM stand-in (simulation; not a language model)"
        news[n] = simulated_llm_scores(news)
        names.append(n)
        news[LEAKY] = leaky_scores(news, d["abret"], args.cutoff, fallback=news[names[0]].to_numpy())
        names.append(LEAKY)
    if args.finbert:
        try:
            fb = FinBERTScorer()
            news[fb.name] = fb.score_many(news["headline"].tolist())
            names.append(fb.name)
        except Exception as e:  # noqa: BLE001
            d["notes"].append(f"FinBERT not run ({e})")
    if args.llm_provider:
        sub = news.sort_values("timestamp").tail(args.max_llm) if args.max_llm else news
        comp = sub["company"].tolist() if "company" in sub else None
        for anon in ([False, True] if args.anonymize_too else [False]):
            try:
                sc = LLMScorer(args.llm_provider, args.llm_model, ROOT / "data" / "llm_cache.json",
                               base_url=args.llm_base_url, anonymize=anon)
                news.loc[sub.index, sc.name] = sc.score_many(sub["headline"].tolist(), comp, sub["ticker"].tolist())
                names.append(sc.name)
            except Exception as e:  # noqa: BLE001
                d["notes"].append(f"LLM scorer not run ({e})")
    return news, names


# ---------------------------------------------------------------------------
# Parts
# ---------------------------------------------------------------------------


def part_a(d, news, names) -> dict:
    gen = general_dictionary()
    out = {"corr": news[names].corr().round(3), "zero_share": (news[names] == 0).mean().rename("share_scored_zero")}
    if d.get("finance_dict") is not None:
        out["misclassified"] = misclassification(gen, d["finance_dict"], news["headline"]).head(15)
    return out


def part_b(news, names, abret) -> dict:
    news = news.copy()
    news["first_day"] = assign_trade_date(news["timestamp"], abret.index)
    cars = event_returns(news, abret)
    news = news.join(cars)
    rows, ls = [], {}
    for n in names:
        sgn = np.sign(news[n])
        r = {"scorer": n, "events": int(news[n].notna().sum())}
        for lab, v in (("positive", 1), ("negative", -1), ("zero", 0)):
            m = sgn == v
            r[f"car1_{lab}"] = news.loc[m, "car_1_1"].mean()
            r[f"car2_21_{lab}"] = news.loc[m, "car_2_21"].mean()
        cs = daily_cross_section(news, n, "car_1_1")
        r["fm_slope_day1"], r["fm_t_day1"] = cs["slope"], cs["t"]
        ls[n] = long_short_daily(news, n, abret)
        st = ls_stats(ls[n])
        r.update({"ls_mean_daily_bp": st["mean_daily_bp"], "ls_t": st["t"], "ls_sharpe": st["sharpe"]})
        rows.append(r)
    return {"table": pd.DataFrame(rows), "ls": ls, "events": news}


def part_c(b, names, cutoff) -> pd.DataFrame:
    c = pd.Timestamp(cutoff)
    rows = []
    for n in names:
        x = b["ls"][n]
        for lab, part in (("before cutoff", x[x.index < c]), ("after cutoff", x[x.index >= c])):
            st = ls_stats(part)
            rows.append({"scorer": n, "window": lab, "ls_sharpe": st["sharpe"], "ls_mean_daily_bp": st["mean_daily_bp"],
                         "days": st["days"]})
    return pd.DataFrame(rows)


def part_d(b, names, abret, costs=(0, 5, 10, 20)) -> dict:
    crow = []
    for n in names:
        row = {"scorer": n, "turnover": float(b["ls"][n]["turnover"].mean())}
        for cbp in costs:
            row[f"sharpe_{cbp}bp"] = ls_stats(long_short_daily(b["events"], n, abret, cost_bp=cbp))["sharpe"]
        crow.append(row)
    yrow = []
    for n in names:
        x = b["ls"][n]
        for y, g in x.groupby(x.index.year):
            st = ls_stats(g)
            yrow.append({"scorer": n, "year": int(y), "ls_sharpe": st["sharpe"], "days": st["days"]})
    return {"costs": pd.DataFrame(crow), "years": pd.DataFrame(yrow)}


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------


def _sub(sim, text):
    return text + ("  ·  SIMULATED DATA: tests the code only" if sim else "")


def _col(names):
    return {n: PALETTE[i % len(PALETTE)] for i, n in enumerate(names)}


def fig_cars(b, names, out, sim):
    import matplotlib.pyplot as plt

    names = [n for n in names if n != LEAKY]       # the look-ahead demo is shown in Figure 23.3
    t = b["table"].set_index("scorer").loc[names]
    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.6), sharey=False)
    fig.patch.set_facecolor(plots.SURFACE)
    for ax, (pre, lab) in zip(axes, (("car1", "First tradable day"), ("car2_21", "Following 20 trading days"))):
        plots.style_axes(ax)
        y = np.arange(len(names))[::-1]
        ax.barh(y + 0.2, 1e4 * t[f"{pre}_positive"], 0.4, color=plots.BLUE, label="Scored positive")
        ax.barh(y - 0.2, 1e4 * t[f"{pre}_negative"], 0.4, color=plots.RED, label="Scored negative")
        ax.axvline(0, color=plots.INK_3, linewidth=0.8)
        ax.set_yticks(y, [n if len(n) < 34 else n[:32] + "…" for n in names], fontsize=8)
        ax.set_title(lab, loc="left", fontsize=9.5, color=plots.INK)
        ax.set_xlabel("Average abnormal return (basis points)")
        ax.grid(axis="y", visible=False)
    axes[1].set_yticks([])
    axes[0].legend(frameon=False, fontsize=8, loc="lower right")
    plots.titles(fig, "Figure 23.1  Returns after positive and negative news",
                 _sub(sim, "Abnormal return from the first close at which the news could be traded"))
    plots.finish(fig, out / "fig23_1_cars.png")
    plt.close(fig)


def fig_cumulative(b, names, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 4.6)
    cols = _col(names)
    for n in names:
        x = b["ls"][n]["ls"].fillna(0)
        ax.plot(x.index, np.cumsum(np.log1p(x)), color=cols[n], linewidth=1.4, label=n,
                linestyle="--" if n == LEAKY else "-")
    ax.axhline(0, color=plots.INK_3, linewidth=0.8)
    ax.set_ylabel("Cumulative log return")
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    plots.titles(fig, "Figure 23.2  Daily long–short portfolios by scorer",
                 _sub(sim, "Buy stocks with positive news, sell those with negative news, hold one day, before costs"))
    plots.finish(fig, out / "fig23_2_cumulative.png")
    plt.close(fig)


def fig_cutoff(c, out, sim, cutoff):
    fig, ax, plt = plots.new_figure(9.0, 4.4)
    piv = c.pivot_table(index="scorer", columns="window", values="ls_sharpe", sort=False)
    if "before cutoff" not in piv or "after cutoff" not in piv:
        plt.close(fig)
        return
    y = np.arange(len(piv))[::-1]
    ax.barh(y + 0.2, piv["before cutoff"], 0.4, color=plots.INK_3, label=f"Before {cutoff}")
    ax.barh(y - 0.2, piv["after cutoff"], 0.4, color=plots.BLUE, label=f"From {cutoff}")
    ax.axvline(0, color=plots.INK, linewidth=0.8)
    ax.set_yticks(y, piv.index, fontsize=8.5)
    ax.set_xlabel("Long–short Sharpe ratio (annualized, before costs)")
    ax.grid(axis="y", visible=False)
    ax.legend(frameon=False, fontsize=8.5, loc="lower right")
    plots.titles(fig, "Figure 23.3  Before and after the model's knowledge cutoff",
                 _sub(sim, "A model that has read what happened next looks brilliant before its cutoff · the leaky "
                           "scorer is a demonstration"))
    plots.finish(fig, out / "fig23_3_cutoff.png")
    plt.close(fig)


def fig_years(dd, names, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 4.4)
    cols = _col(names)
    y = dd["years"]
    for n in names:
        if n == LEAKY:
            continue
        g = y[y.scorer == n]
        ax.plot(g["year"], g["ls_sharpe"], marker="o", color=cols[n], linewidth=1.4, label=n)
    ax.axhline(0, color=plots.INK_3, linewidth=0.8)
    ax.set_ylabel("Long–short Sharpe ratio")
    ax.legend(frameon=False, fontsize=8, loc="upper right")
    plots.titles(fig, "Figure 23.4  Does the signal decay?", _sub(sim, "Year-by-year Sharpe ratio, before costs"))
    plots.finish(fig, out / "fig23_4_years.png")
    plt.close(fig)


def fig_costs(dd, names, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 4.4)
    t = dd["costs"].set_index("scorer").loc[[n for n in names if n != LEAKY]]
    cols = [c for c in t.columns if c.startswith("sharpe_")]
    x = np.array([int(c.split("_")[1][:-2]) for c in cols])
    colmap = _col(names)
    for n, row in t.iterrows():
        ax.plot(x, row[cols].to_numpy(float), marker="o", color=colmap[n], linewidth=1.4, label=n)
    ax.axhline(0, color=plots.INK_3, linewidth=0.8)
    ax.set_xlabel("Cost per round trip (basis points)")
    ax.set_ylabel("Long–short Sharpe ratio")
    ax.legend(frameon=False, fontsize=8, loc="upper right")
    plots.titles(fig, "Figure 23.5  What trading costs leave", _sub(sim, "Daily rebalancing, one-day holding period"))
    plots.finish(fig, out / "fig23_5_costs.png")
    plt.close(fig)


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------


def _md(df, fmt):
    cols = list(df.columns)
    lines = ["| " + " | ".join(str(c) for c in cols) + " |", "| " + " | ".join("---" for _ in cols) + " |"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(fmt[c](r[c]) if c in fmt else str(r[c]) for c in cols) + " |")
    return "\n".join(lines)


def _num(spec):
    return lambda v: "" if (v is None or (isinstance(v, float) and math.isnan(v))) else format(v, spec)


def write_report(out, a, b, c, dd, sim, notes, args):
    bp = lambda v: "" if v is None or (isinstance(v, float) and math.isnan(v)) else f"{1e4 * v:+.1f}"  # noqa: E731
    md = ["# Lab 23 results: Can Language Models Read the News and Earn Returns?", ""]
    if sim:
        md += ["> **Simulated data.** These results test that the code runs; they say nothing about real markets.", ""]
    if notes:
        md += ["Notes: " + "; ".join(notes), ""]
    md += ["**Claim on trial:** text-based signals predict stock returns, and large language models extract them best.",
           "", "## Part A: Dictionaries", "", "**Correlation between scorers**", "",
           _md(a["corr"].reset_index().rename(columns={"index": "scorer"}),
               {k: _num("+.2f") for k in a["corr"].columns}), "",
           "**Share of headlines scored exactly zero**", "",
           _md(a["zero_share"].reset_index().rename(columns={"index": "scorer"}), {"share_scored_zero": _num(".0%")}), ""]
    if "misclassified" in a:
        md += ["**General-list words that the finance dictionary does not classify the same way**", "",
               _md(a["misclassified"], {}), ""]
    t = b["table"]
    fmt = {k: bp for k in t.columns if k.startswith("car")}
    fmt.update({"fm_slope_day1": bp, "fm_t_day1": _num("+.2f"), "ls_mean_daily_bp": _num("+.1f"), "ls_t": _num("+.2f"),
                "ls_sharpe": _num(".2f")})
    md += ["## Part B: Returns after the news", "", "Abnormal returns in basis points; day 1 is the first close-to-close "
           "return an investor could earn after the news.", "", _md(t, fmt), "", "![Figure 23.1](fig23_1_cars.png)", "",
           "![Figure 23.2](fig23_2_cumulative.png)", "", f"## Part C: Before and after the cutoff ({args.cutoff})", "",
           _md(c, {"ls_sharpe": _num(".2f"), "ls_mean_daily_bp": _num("+.1f")}), "", "![Figure 23.3](fig23_3_cutoff.png)",
           "", "## Part D: Costs and decay", "", "Sharpe ratios net of the cost per round trip shown; turnover is the "
           "average daily sum of weight changes (4 = the whole book replaced).", "",
           _md(dd["costs"], {k: _num(".2f") for k in dd["costs"].columns if k != "scorer"}), "",
           "![Figure 23.4](fig23_4_years.png)", "", "![Figure 23.5](fig23_5_costs.png)", "", "## Your verdict", "",
           "1. Do any scores predict returns after the first tradable close, and which scorer is best?",
           "2. Does the result hold after the model's knowledge cutoff?",
           "3. What is left after trading costs, and is it shrinking over time?", ""]
    (out / "lab23_report.md").write_text("\n".join(md))


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", choices=["files", "sim"], default="files")
    ap.add_argument("--news-file")
    ap.add_argument("--returns-file", help="daily returns (long: date,ticker,ret; or wide); default: download from Stooq")
    ap.add_argument("--lm-file", help="Loughran-McDonald Master Dictionary CSV")
    ap.add_argument("--ff3d-file", dest="ff3d_file")
    ap.add_argument("--max-tickers", type=int, default=300)
    ap.add_argument("--finbert", action="store_true", help="also score with FinBERT (needs transformers and torch)")
    ap.add_argument("--llm-provider", choices=["anthropic", "openai"])
    ap.add_argument("--llm-model", help="model identifier for the provider")
    ap.add_argument("--llm-base-url", help="OpenAI-compatible endpoint, e.g. http://localhost:11434/v1 for Ollama")
    ap.add_argument("--anonymize-too", action="store_true", help="also score with company names removed")
    ap.add_argument("--max-llm", type=int, default=5000, help="score at most this many (most recent) headlines with the LLM")
    ap.add_argument("--cutoff", default="2021-01-01", help="the language model's knowledge cutoff (YYYY-MM-DD)")
    ap.add_argument("--sim-seed", type=int, default=0)
    ap.add_argument("--out", default=str(ROOT / "report"))
    return ap.parse_args(argv)


def run(args) -> dict:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    try:
        d = load(args)
    except DataUnavailable as err:
        raise SystemExit(str(err)) from None
    sim = d["simulated"]
    news, names = score(d, args)
    print(f"{len(news)} headlines, {news['ticker'].nunique()} tickers; scorers: {names}")
    a = part_a(d, news, names)
    b = part_b(news, names, d["abret"])
    c = part_c(b, names, args.cutoff)
    dd = part_d(b, names, d["abret"])
    fig_cars(b, names, out, sim)
    fig_cumulative(b, names, out, sim)
    fig_cutoff(c, out, sim, args.cutoff)
    fig_years(dd, names, out, sim)
    fig_costs(dd, names, out, sim)
    b["table"].to_csv(out / "table_returns.csv", index=False)
    c.to_csv(out / "table_cutoff.csv", index=False)
    dd["costs"].to_csv(out / "table_costs.csv", index=False)
    dd["years"].to_csv(out / "table_years.csv", index=False)
    b["events"].drop(columns=["headline"]).to_csv(out / "events_scored.csv", index=False)
    write_report(out, a, b, c, dd, sim, d.get("notes", []), args)
    summary = {"simulated": sim, "scorers": names, "returns": b["table"].to_dict(orient="records"),
               "cutoff": c.to_dict(orient="records"), "costs": dd["costs"].to_dict(orient="records")}
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=float))
    print(b["table"][["scorer", "car1_positive", "car1_negative", "ls_sharpe"]].round(4).to_string(index=False))
    print(f"Report: {out / 'lab23_report.md'}")
    if sim:
        print("NOTE: simulated data. These results test the code only.")
    return summary


def main(argv=None):
    return run(parse_args(argv))


if __name__ == "__main__":
    main()
