# Lab 8: Is Value Still Worth Waiting For?

Companion lab for **Chapter 8** of *Financial Engineering and the Evidence: A Claim-Verify Approach to Quantitative Finance*.

**Claim on trial:** cheap stocks earn higher returns than expensive ones.

## Quick start

```bash
pip install -r requirements.txt
python lab08.py
```

The first run downloads up to twelve files from the Kenneth R. French Data Library and caches them in `data/`. The lab runs in under a minute. Open `report/lab08_report.md`. For a guided version, open `lab08_walkthrough.ipynb`.

If an international file cannot be downloaded, the lab reports it and carries on without that region.

### If a download fails

Download the CSV versions from the [Kenneth R. French Data Library](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html), save them in `data/`, or pass them with the options below.

| Library page title | File | Option |
|---|---|---|
| Fama/French 3 Factors | `F-F_Research_Data_Factors_CSV.zip` | `--ff3-file` |
| 6 Portfolios Formed on Size and Book-to-Market (2 x 3) | `6_Portfolios_2x3_CSV.zip` | `--six-file` |
| Portfolios Formed on Book-to-Market | `Portfolios_Formed_on_BE-ME_CSV.zip` | `--bm-file` |
| Portfolios Formed on Earnings/Price | `Portfolios_Formed_on_E-P_CSV.zip` | `--ep-file` |
| Portfolios Formed on Cashflow/Price | `Portfolios_Formed_on_CF-P_CSV.zip` | `--cfp-file` |
| Portfolios Formed on Dividend Yield | `Portfolios_Formed_on_D-P_CSV.zip` | `--dp-file` |
| International 3 factors: North America, Europe, Japan, Asia Pacific ex Japan, Developed ex US | `North_America_3_Factors_CSV.zip`, `Europe_3_Factors_CSV.zip`, `Japan_3_Factors_CSV.zip`, `Asia_Pacific_ex_Japan_3_Factors_CSV.zip`, `Developed_ex_US_3_Factors_CSV.zip` | `--north-america-ff3-file`, `--europe-ff3-file`, `--japan-ff3-file`, `--asia-pacific-ex-japan-ff3-file`, `--developed-ex-us-ff3-file` |

The U.S. file names were checked against the library's archived listing. The international file names follow the library's naming pattern but could not be checked from the build environment; if one fails, download it from the library page and pass it with its option.

**Optional, many countries:** the Jensen–Kelly–Pedersen global factor data (https://jkpfactors.com). Download a CSV of country factor returns with columns `location`, `name`, `date` and `ret`, and pass it with `--jkp-file`. The lab keeps the book-to-market factor (`be_me`).

### Testing the code without real data

```bash
python lab08.py --source sim
```

**Results from simulated data are not evidence about markets.** The simulated value premium is deliberately set to shrink after 2007.

## What the lab does

| Part | Question | Method | Output |
|---|---|---|---|
| A. Replication | Has value beaten growth? | HML from July 1926: mean, t, Sharpe ratio, CAPM alpha with Newey–West t, in four eras (including the Fama–French 1963–1990 sample and 2007 onward); test of the post-2007 change | Figures 8.1–8.2 |
| B. Stress tests | Is it about book value, small stocks, or costs? | High-minus-low spreads (top 30% minus bottom 30%, value-weighted) on book-to-market, earnings, cash flow and dividends; value among large and small stocks (2 × 3 portfolios); net of trading costs | Figure 8.3 |
| C. Other markets | Is it a U.S. accident? | Kenneth French international HML factors from 1990, before and after 2007; optional JKP country factors | Figure 8.4 |
| D. Living with value | Could you hold it? | Drawdowns and time under water; worst rolling 10 years; stationary bootstrap of 10-year outcomes (24-month blocks) from the full history and from 1991; the largest tilt whose bad-case 10-year shortfall stays within a tolerance | Figures 8.5–8.6 |

### Design notes

- **HML** is the Fama–French value factor: the average of small and big value portfolios minus the average of small and big growth portfolios, rebalanced each June.
- **Large and small value** use the 2 × 3 portfolios: BIG HiBM − BIG LoBM and SMALL HiBM − SMALL LoBM.
- **Alternative measures** use the univariate portfolio files' value-weighted "Hi 30" minus "Lo 30" columns. Earnings and cash-flow sorts begin in 1951.
- **Costs** use one-sided turnover of 2.9% a month (Novy-Marx and Velikov 2016) and cost = 4 × turnover × one-way cost.
- **Tilt sizing.** A tilt of w adds w × HML to the market portfolio, so its return relative to the market is w × HML. The bad case is the 5th percentile of 10-year cumulative HML from the bootstrap; the lab takes the worse of the full-history and post-1991 bootstraps and reports the largest w whose bad case stays within `--tolerance` (default 10%).
- **Intangible-adjusted book equity** is discussed in the chapter but not replicated: it requires firm-level accounting data that is not freely available. See the exercises.

## Options

```text
--source {french,sim}
--ff3-file, --six-file, --bm-file, --ep-file, --cfp-file, --dp-file PATH
--north-america-ff3-file, --europe-ff3-file, --japan-ff3-file,
--asia-pacific-ex-japan-ff3-file, --developed-ex-us-ff3-file PATH
--jkp-file PATH          optional Jensen-Kelly-Pedersen CSV
--tolerance X            bad-case 10-year shortfall an investor accepts (default 0.10)
--n-boot N               bootstrap samples (default 5000)
--seed N / --sim-seed N
--out DIR
```

## Outputs (`report/`)

- `lab08_report.md`, `fig8_1_cumulative.png` to `fig8_6_ten_year.png`
- `table_eras.csv`, `table_robustness.csv`, `table_international.csv`, `table_tilts.csv`, `summary.json`

## Verification status

| Part | Status |
|---|---|
| Portfolio-file parsers (BE-ME layout with several tables; 2 × 3 portfolios) | Tested on files in the library's published layouts; **confirm on the live files at first run** |
| Drawdown statistics | Tested on a series with a known drawdown and time under water |
| Bootstrap and tilt sizing | Tested: bad cases scale with the tilt |
| JKP reader | Tested on a file in the JKP long format; not tested on a live download |
| Missing international files | Tested: reported and skipped, not fatal |
| Full lab and notebook | Run end to end on simulated data |
| Live downloads | Not tested from the build environment (network blocked) |

Run the tests with `python tests/test_lab08.py` (or `pytest tests/`).

## Exercises

1. Split the sample at 1990 instead of 2007. Which break looks more like a change in the premium and which more like bad luck?
2. Compare value among large and small stocks after 2007. What does the comparison say about who could have earned the premium?
3. Compute the correlation between HML and the market in each era. Did value become a bet on interest rates or on technology stocks after 2007?
4. Using the JKP data, count the countries in which the value premium has a t-statistic above 2. How many would you expect by chance (Chapter 4)?
5. With firm-level data, if you have access to it, rebuild book equity by capitalizing research and development and part of selling, general and administrative expenses (Eisfeldt, Kim and Papanikolaou 2022). Does the post-2007 shortfall shrink?

## Data citation

Kenneth R. French Data Library, https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html. Jensen, Kelly and Pedersen global factor data, https://jkpfactors.com.
