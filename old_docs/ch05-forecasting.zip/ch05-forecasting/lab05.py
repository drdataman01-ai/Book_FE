"""Lab 5: Does It Forecast, or Did It Fit?

Chapter 5 of *Financial Engineering and the Evidence: A Claim-Verify
Approach to Quantitative Finance*.

CLAIM ON TRIAL
  "A predictor that fits well in-sample will forecast well out of sample."

WHAT THE LAB DOES
  Part A  Fourteen classic predictors of the monthly U.S. equity premium
          (Goyal and Welch 2008). Full-sample fit against walk-forward
          forecasts that use only past data, judged against the historical
          mean with the out-of-sample R-squared and the Clark-West test.
          Also: before and after each predictor's publication, a
          kitchen-sink regression and an equal-weight combination.
  Part B  Design choices: expanding versus rolling windows, and the
          Campbell-Thompson restrictions.
  Part C  Leakage: what happens when the evaluation borrows from the future
          (full-sample coefficients, choosing the predictor with hindsight,
          overlapping annual targets without purging).
  Part D  Economic and probabilistic value: the certainty-equivalent gain of
          a mean-variance investor, the log score and the CRPS.
  Part E  Known truth: a simulated predictor that truly works, and one that
          does not. How often does each pass each test?

DATA
  Goyal-Welch monthly predictor data (Amit Goyal's website; see README).

USAGE
  python lab05.py --data-file data/PredictorData2025.xlsx
  python lab05.py --source sim              # fake data, to test the code

OUTPUT
  report/lab05_report.md, five figures (PNG), CSV tables and summary.json.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

from fintest import plots
from fintest.data import DataUnavailable
from fintest.forecast import (
    certainty_equivalent,
    clark_west,
    crps_gaussian,
    cumulative_sse_difference,
    diebold_mariano,
    expanding_univariate,
    gaussian_log_score,
    interval_coverage,
    lagged_pairs,
    mean_variance_weights,
    oos_r2,
    rolling_variance,
    walk_forward,
)
from fintest.predictors import PREDICTORS, PUBLICATION_YEAR, load_predictors, simulated_predictors
from fintest.stats import ols_newey_west

ROOT = Path(__file__).resolve().parent
NAMES = list(PREDICTORS)


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------


def load(source: str, data_file=None, start="1927-01", end=None, sim_seed: int = 0) -> pd.DataFrame:
    df = simulated_predictors(seed=sim_seed) if source == "sim" else load_predictors(data_file)
    sim = df.attrs.get("simulated", False)
    df = df.loc[pd.Period(start, "M"):] if start else df
    if end:
        df = df.loc[:pd.Period(end, "M")]
    df = df[df["eqp"].notna()].copy()
    df.attrs["simulated"] = sim
    return df


def _first_index(df: pd.DataFrame, oos_start: str) -> int:
    return int(np.searchsorted(df.index.astype(str), oos_start))


def _forecast_set(df, name, first, **kw):
    z, X = lagged_pairs(df["eqp"].to_numpy(), df[name].to_numpy())
    return walk_forward(z, X, first, **kw)


# ---------------------------------------------------------------------------
# Part A: fit versus forecast
# ---------------------------------------------------------------------------


def part_a(df: pd.DataFrame, oos_start: str, min_train: int = 240) -> dict:
    first = _first_index(df, oos_start)
    dates = df.index
    rows, fc = [], {}
    for name in NAMES:
        z, x = lagged_pairs(df["eqp"].to_numpy(), df[name].to_numpy())
        ok = np.isfinite(z) & np.isfinite(x)
        reg = ols_newey_west(z[ok], x[ok])
        resid_var = np.var(z[ok] - reg["coef"][0, 0] - reg["coef"][1, 0] * x[ok])
        r2_in = 1 - resid_var / np.var(z[ok])
        w = walk_forward(z, x, first, min_train=min_train)
        fc[name] = w
        v = w["valid"]
        pub = PUBLICATION_YEAR[name]
        pre = v & (dates.year <= pub)
        post = v & (dates.year > pub)
        rows.append({
            "predictor": name, "description": PREDICTORS[name][0],
            "slope_t_in": float(reg["t"][1, 0]), "r2_in": float(r2_in),
            "r2_oos": oos_r2(z[v], w["model"][v], w["bench"][v]),
            "cw_stat": clark_west(z[v], w["model"][v], w["bench"][v])["stat"],
            "cw_p": clark_west(z[v], w["model"][v], w["bench"][v])["p_value"],
            "dm_p": diebold_mariano(z[v], w["bench"][v], w["model"][v])["p_value"],
            "published": pub,
            "r2_oos_before_pub": oos_r2(z[pre], w["model"][pre], w["bench"][pre]) if pre.sum() >= 60 else float("nan"),
            "r2_oos_after_pub": oos_r2(z[post], w["model"][post], w["bench"][post]) if post.sum() >= 60 else float("nan"),
            "n_oos": int(v.sum()),
        })
    table = pd.DataFrame(rows)

    # Kitchen sink: all predictors in one regression.
    z, X = lagged_pairs(df["eqp"].to_numpy(), df[NAMES].to_numpy())
    ks = walk_forward(z, X, first, min_train=min_train)
    # Combination: equal-weight average of the individual forecasts (Rapach, Strauss and Zhou 2010).
    M = np.column_stack([fc[n]["model"] for n in NAMES])
    comb_model = np.where(np.isfinite(M).all(axis=1), M.mean(axis=1), np.nan)
    bench = fc["dp"]["bench"]
    comb = {"actual": z, "model": comb_model, "bench": bench,
            "valid": np.isfinite(comb_model) & np.isfinite(bench) & np.isfinite(z)}
    extra = []
    for label, w in (("Kitchen sink (all 14)", ks), ("Combination (average of 14)", comb)):
        v = w["valid"]
        extra.append({"predictor": label, "description": "", "slope_t_in": float("nan"), "r2_in": float("nan"),
                      "r2_oos": oos_r2(z[v], w["model"][v], w["bench"][v]),
                      "cw_stat": clark_west(z[v], w["model"][v], w["bench"][v])["stat"],
                      "cw_p": clark_west(z[v], w["model"][v], w["bench"][v])["p_value"],
                      "dm_p": diebold_mariano(z[v], w["bench"][v], w["model"][v])["p_value"],
                      "published": float("nan"), "r2_oos_before_pub": float("nan"),
                      "r2_oos_after_pub": float("nan"), "n_oos": int(v.sum())})
    fc["kitchen"] = ks
    fc["combination"] = comb
    return {"table": table, "extra": pd.DataFrame(extra), "forecasts": fc, "first": first, "dates": dates,
            "oos_start": str(dates[first]), "oos_end": str(dates[-2])}


# ---------------------------------------------------------------------------
# Part B: design choices
# ---------------------------------------------------------------------------


def part_b(df: pd.DataFrame, oos_start: str, min_train: int = 240) -> pd.DataFrame:
    first = _first_index(df, oos_start)
    designs = {
        "Expanding": {},
        "Rolling 10 years": {"window": 120, "min_train": 120},
        "Rolling 20 years": {"window": 240},
        "Expanding + Campbell-Thompson": {"sign": None, "nonneg": True},
    }
    rows = []
    for name in NAMES:
        z, x = lagged_pairs(df["eqp"].to_numpy(), df[name].to_numpy())
        row = {"predictor": name}
        for label, kw in designs.items():
            kw = dict(kw)
            kw.setdefault("min_train", min_train)
            if "sign" in kw:
                kw["sign"] = PREDICTORS[name][1]
            w = walk_forward(z, x, first, **kw)
            v = w["valid"]
            row[label] = oos_r2(z[v], w["model"][v], w["bench"][v])
        rows.append(row)
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Part C: leakage
# ---------------------------------------------------------------------------


def part_c(df: pd.DataFrame, a: dict, oos_start: str, focus: str = "dp", min_train: int = 240) -> dict:
    first = _first_index(df, oos_start)
    y = df["eqp"].to_numpy()
    rows = []

    def add(label, kind, w, z):
        v = w["valid"]
        rows.append({"evaluation": label, "kind": kind, "r2_oos": oos_r2(z[v], w["model"][v], w["bench"][v])})

    z, x = lagged_pairs(y, df[focus].to_numpy())
    add(f"{focus}: honest walk-forward", "honest", a["forecasts"][focus], z)
    ok = np.isfinite(z) & np.isfinite(x)
    full = np.linalg.lstsq(np.column_stack([np.ones(ok.sum()), x[ok]]), z[ok], rcond=None)[0]
    add(f"{focus}: full-sample coefficients", "leak", walk_forward(z, x, first, coef_fixed=full, min_train=min_train),
        z)

    # Choosing the predictor: with hindsight versus in real time.
    best_full = a["table"].sort_values("r2_in", ascending=False)["predictor"].iloc[0]
    zb, _ = lagged_pairs(y, df[best_full].to_numpy())
    add(f"Best predictor chosen with hindsight ({best_full})", "leak", a["forecasts"][best_full], zb)
    rt_model = np.full(len(y), np.nan)
    rt_bench = a["forecasts"]["dp"]["bench"]
    picks = []
    for t in range(first, len(y)):
        best, best_r2 = None, -np.inf
        for name in NAMES:
            zz, xx = lagged_pairs(y[:t + 1], df[name].to_numpy()[:t + 1])
            m = np.isfinite(zz[:t]) & np.isfinite(xx[:t])
            if m.sum() < min_train:
                continue
            c = np.corrcoef(xx[:t][m], zz[:t][m])[0, 1] ** 2
            if c > best_r2:
                best, best_r2 = name, c
        if best is not None:
            rt_model[t] = a["forecasts"][best]["model"][t]
            picks.append(best)
    wrt = {"model": rt_model, "bench": rt_bench,
           "valid": np.isfinite(rt_model) & np.isfinite(rt_bench) & np.isfinite(zb)}
    add("Best predictor chosen in real time", "honest", wrt, zb)

    # Annual horizon: overlapping 12-month targets with and without purging.
    z12, x12 = lagged_pairs(y, df[focus].to_numpy(), horizon=12)
    add(f"{focus}, 12-month horizon, purged (gap 11)", "honest", walk_forward(z12, x12, first, gap=11,
                                                                            min_train=min_train), z12)
    add(f"{focus}, 12-month horizon, not purged", "leak", walk_forward(z12, x12, first, gap=0, min_train=min_train),
        z12)
    pick_share = pd.Series(picks).value_counts(normalize=True) if picks else pd.Series(dtype=float)
    return {"table": pd.DataFrame(rows), "best_full": best_full, "picks": pick_share}


# ---------------------------------------------------------------------------
# Part D: economic and probabilistic value
# ---------------------------------------------------------------------------


def part_d(df: pd.DataFrame, a: dict, gamma: float = 3.0, var_window: int = 60) -> pd.DataFrame:
    y = df["eqp"].to_numpy()
    rf_next = np.append(df["rf"].to_numpy()[1:], np.nan)
    var = rolling_variance(y, var_window)  # known at the end of t, used for t+1
    sig = np.sqrt(var)
    rows = []
    for name in NAMES + ["combination"]:
        w = a["forecasts"][name]
        z = w["actual"]
        v = w["valid"] & np.isfinite(var) & np.isfinite(rf_next)
        wm = mean_variance_weights(w["model"][v], var[v], gamma)
        wb = mean_variance_weights(w["bench"][v], var[v], gamma)
        ce_m = certainty_equivalent(z[v], rf_next[v], wm, gamma)
        ce_b = certainty_equivalent(z[v], rf_next[v], wb, gamma)
        rows.append({
            "predictor": name,
            "ce_gain": ce_m - ce_b,
            "avg_weight": float(wm.mean()),
            "log_score_gain": float(np.mean(gaussian_log_score(z[v], w["model"][v], sig[v])
                                            - gaussian_log_score(z[v], w["bench"][v], sig[v]))),
            "crps_gain": float(np.mean(crps_gaussian(z[v], w["bench"][v], sig[v])
                                       - crps_gaussian(z[v], w["model"][v], sig[v]))),
            "coverage_90": interval_coverage(z[v], w["model"][v], sig[v], 0.9),
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Part E: known truth
# ---------------------------------------------------------------------------


def part_e(n_reps: int = 500, n_months: int = 1100, first: int = 456, true_r2: float = 0.005, phi: float = 0.985,
           rho: float = -0.9, seed: int = 0) -> dict:
    """Simulated predictors that do and do not work, evaluated like real ones.

    Returns follow r[t+1] = mu + b x[t] + e[t+1]; x is AR(1) with persistence
    phi and innovations correlated rho with e (Stambaugh 1999). b is chosen so
    the true R-squared is true_r2 (0 for the null case).
    """
    rng = np.random.default_rng(seed)
    out = {}
    for label, r2 in (("No predictive power", 0.0), (f"True R-squared {true_r2:.1%}", true_r2)):
        b = math.sqrt(r2 / (1 - r2))  # x has unit variance, shocks unit variance
        res = {"t_in": [], "r2_oos": [], "cw_p": [], "dm_p": [], "r2_in": []}
        for _ in range(n_reps):
            e = rng.standard_normal(n_months)
            u = rho * e + math.sqrt(1 - rho ** 2) * rng.standard_normal(n_months)
            x = np.empty(n_months)
            x[0] = rng.standard_normal()
            for t in range(1, n_months):
                x[t] = phi * x[t - 1] + math.sqrt(1 - phi ** 2) * u[t]
            r = np.empty(n_months)
            r[0] = 0
            r[1:] = b * x[:-1] + e[1:]
            z, xx = lagged_pairs(r, x)
            reg = ols_newey_west(z[:-1], xx[:-1])
            res["t_in"].append(float(reg["t"][1, 0]))
            res["r2_in"].append(float(np.corrcoef(z[:-1], xx[:-1])[0, 1] ** 2))
            w = expanding_univariate(z, xx, first)
            v = w["valid"]
            res["r2_oos"].append(oos_r2(z[v], w["model"][v], w["bench"][v]))
            res["cw_p"].append(clark_west(z[v], w["model"][v], w["bench"][v])["p_value"])
            res["dm_p"].append(diebold_mariano(z[v], w["bench"][v], w["model"][v])["p_value"])
        out[label] = {k: np.array(v_) for k, v_ in res.items()}
    rows = []
    for label, r in out.items():
        rows.append({"truth": label,
                     "in-sample |t| > 1.96": float((np.abs(r["t_in"]) > 1.96).mean()),
                     "OOS R2 > 0": float((r["r2_oos"] > 0).mean()),
                     "Clark-West p < 0.05": float((r["cw_p"] < 0.05).mean()),
                     "Diebold-Mariano p < 0.05": float((r["dm_p"] < 0.05).mean()),
                     "median OOS R2": float(np.median(r["r2_oos"])),
                     "median in-sample R2": float(np.median(r["r2_in"]))})
    return {"draws": out, "table": pd.DataFrame(rows),
            "meta": {"n_reps": n_reps, "n_months": n_months, "first": first, "true_r2": true_r2, "phi": phi,
                     "rho": rho}}


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------


def _sub(sim: bool, text: str) -> str:
    return text + ("  ·  SIMULATED DATA: tests the code only" if sim else "")


def _place_labels(ax, xs, ys, labels, fontsize=9, line_h_pt=11, char_w_pt=5.4):
    """Label points without overlaps: try positions around each point, then further out with a leader line."""
    fig = ax.figure
    fig.canvas.draw()
    to_disp, to_data = ax.transData.transform, ax.transData.inverted().transform
    box = ax.get_window_extent()
    sc = fig.dpi / 72
    h = line_h_pt * sc
    pts = [to_disp((x, y)) for x, y in zip(xs, ys)]
    placed = [(px - 4 * sc, py - 4 * sc, 8 * sc, 8 * sc) for px, py in pts]  # the markers themselves

    def free(b):
        x, y, w, hh = b
        if x < box.x0 or x + w > box.x1 or y < box.y0 or y + hh > box.y1:
            return False
        return all(x + w < bx or x > bx + bw or y + hh < by or y > by + bh for bx, by, bw, bh in placed)

    for i in np.argsort(-np.asarray(ys)):
        px, py = pts[i]
        w = len(labels[i]) * char_w_pt * sc
        near = [(6, -h / 2), (-w - 6, -h / 2), (-w / 2, 5), (-w / 2, -h - 5), (6, 3), (6, -h - 3),
                (-w - 6, 3), (-w - 6, -h - 3)]
        far = [(dx * sc, dy * h) for dx in (22, 40, 60, 80) for dy in (0, 1, -1, 2, -2, 3, -3)]
        choice, moved = None, False
        for k, (dx, dy) in enumerate(near + far):
            off = (dx, dy) if k < len(near) else (dx, dy - h / 2)
            b = (px + off[0], py + off[1], w, h)
            if free(b):
                choice, moved = b, k >= len(near)
                break
        if choice is None:
            choice, moved = (px + 6, py - h / 2, w, h), False
        placed.append(choice)
        tx, ty = to_data((choice[0], choice[1] + h / 2))
        ax.annotate(labels[i], (xs[i], ys[i]), xytext=(tx, ty), textcoords="data", fontsize=fontsize,
                    color=plots.INK, va="center", ha="left",
                    arrowprops={"arrowstyle": "-", "color": plots.INK_3, "lw": 0.6, "shrinkA": 0, "shrinkB": 3}
                    if moved else None)


def _spread(values, gap):
    """Spread 1-D label positions so neighbours are at least `gap` apart, keeping their order."""
    v = np.asarray(values, dtype=float)
    order = np.argsort(v)
    out = v.copy()
    for k in range(1, len(order)):
        a, b = order[k - 1], order[k]
        if out[b] - out[a] < gap:
            out[b] = out[a] + gap
    return out


def fig_fit_vs_forecast(a, out, sim):
    fig, ax, plt = plots.new_figure(8.8, 5.4)
    t = a["table"]
    ax.axhline(0, color=plots.INK_3, linewidth=1)
    colors = [plots.BLUE if r > 0 else plots.RED for r in t["r2_oos"]]
    ax.scatter(t["r2_in"], t["r2_oos"], s=55, color=colors, edgecolor=plots.SURFACE, linewidth=1.5, zorder=3)
    plots.percent_axis(ax, "x")
    plots.percent_axis(ax)
    x0, x1 = ax.get_xlim()
    ax.set_xlim(x0, x1 + (x1 - x0) * 0.08)
    _place_labels(ax, t["r2_in"].to_numpy(), t["r2_oos"].to_numpy(), t["predictor"].tolist())
    ax.set_xlabel("In-sample R² (full sample, all data used)")
    ax.set_ylabel("Out-of-sample R² vs historical mean")
    ax.grid(axis="x", color=plots.GRID, linewidth=0.8)
    plots.titles(fig, "Figure 5.1  Fitting the past is not forecasting the future",
                 _sub(sim, f"Monthly equity premium, 14 predictors · walk-forward forecasts {a['oos_start']} to "
                           f"{a['oos_end']} · red: worse than the historical mean"))
    plots.finish(fig, out / "fig5_1_fit_vs_forecast.png")
    plt.close(fig)


def fig_cumulative(a, out, sim, names=None):
    fig, ax, plt = plots.new_figure(9.0, 5.0)
    t = a["table"].sort_values("r2_in", ascending=False)
    names = names or list(t["predictor"].iloc[:3]) + ["kitchen", "combination"]
    colors = [plots.BLUE, plots.AQUA, plots.VIOLET, plots.RED, plots.ORANGE]
    labels = {"kitchen": "kitchen sink", "combination": "combination"}
    dates = a["dates"].to_timestamp()
    first = a["first"]
    ends = []
    for name, color in zip(names, colors):
        w = a["forecasts"][name]
        c = cumulative_sse_difference(w["actual"], w["model"], w["bench"])
        ax.plot(dates[first:], c[first:] * 1e4, color=color, linewidth=1.8)
        ends.append(c[-1] * 1e4)
    y0, y1 = ax.get_ylim()
    for name, color, yv in zip(names, colors, _spread(ends, (y1 - y0) * 0.045)):
        ax.text(dates[-1], yv, "  " + labels.get(name, name), va="center", fontsize=9, color=color)
    ax.axhline(0, color=plots.INK_3, linewidth=1)
    ax.set_xlim(dates[first], dates[-1] + pd.Timedelta(days=365 * 7))
    ax.set_ylabel("Cumulative SSE(mean) − SSE(model), ×10⁴")
    plots.titles(fig, "Figure 5.2  When did the predictors beat the historical mean?",
                 _sub(sim, "Rising line: the predictor is forecasting better than the mean; falling: worse · the "
                           "three best in-sample predictors, the kitchen sink and the combination"))
    plots.finish(fig, out / "fig5_2_cumulative_sse.png")
    plt.close(fig)


def fig_designs(b, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 5.6)
    cols = [c for c in b.columns if c != "predictor"]
    order = b.sort_values("Expanding")["predictor"].tolist()
    y = np.arange(len(order))
    markers = ["o", "s", "D", "^"]
    colors = [plots.BLUE, plots.ORANGE, plots.VIOLET, plots.GREEN]
    lo = max(-0.06, float(b[cols].min().min()) - 0.002)
    for c, m, color in zip(cols, markers, colors):
        vals = b.set_index("predictor").loc[order, c].to_numpy()
        ax.scatter(np.maximum(vals, lo), y, marker=m, s=42, color=color, label=c, zorder=3,
                   edgecolor=plots.SURFACE, linewidth=0.8)
    ax.axvline(0, color=plots.INK_3, linewidth=1)
    ax.set_yticks(y, order, fontsize=9, color=plots.INK)
    plots.percent_axis(ax, "x")
    ax.set_xlim(lo - 0.002, max(0.02, float(b[cols].max().max()) + 0.005))
    ax.grid(axis="x", color=plots.GRID, linewidth=0.8)
    ax.grid(axis="y", visible=False)
    ax.legend(loc="lower right", frameon=True, facecolor=plots.SURFACE, edgecolor=plots.GRID, fontsize=8.5)
    ax.set_xlabel(f"Out-of-sample R² (values below {lo:.0%} drawn at the edge)")
    plots.titles(fig, "Figure 5.3  The verdict depends on design choices made before the test",
                 _sub(sim, "Same predictors, same period · Campbell-Thompson: use the mean if the slope has the wrong "
                           "sign; never forecast a negative premium"))
    plots.finish(fig, out / "fig5_3_designs.png")
    plt.close(fig)


def fig_leakage(c, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 4.6)
    t = c["table"].iloc[::-1]
    y = np.arange(len(t))
    colors = [plots.RED if k == "leak" else plots.BLUE for k in t["kind"]]
    ax.barh(y, t["r2_oos"], color=colors, height=0.6)
    span = float(t["r2_oos"].abs().max())
    for yi, v in zip(y, t["r2_oos"]):
        ax.text(v + (span * 0.02 if v >= 0 else -span * 0.02), yi, f"{v:+.2%}", va="center",
                ha="left" if v >= 0 else "right", fontsize=9, color=plots.INK)
    ax.axvline(0, color=plots.INK_3, linewidth=1)
    ax.set_yticks(y, t["evaluation"], fontsize=9, color=plots.INK)
    ax.set_xlim(min(0, t["r2_oos"].min()) - span * 0.3, max(0, t["r2_oos"].max()) + span * 0.3)
    plots.percent_axis(ax, "x")
    ax.grid(axis="x", color=plots.GRID, linewidth=0.8)
    ax.grid(axis="y", visible=False)
    ax.set_xlabel("Out-of-sample R²")
    plots.titles(fig, "Figure 5.4  Borrowing from the future makes forecasts look better",
                 _sub(sim, "Red: evaluations that use information not available at the forecast date · blue: honest "
                           "versions of the same comparison"))
    plots.finish(fig, out / "fig5_4_leakage.png")
    plt.close(fig)


def fig_known_truth(e, out):
    fig, ax, plt = plots.new_figure(9.0, 4.8)
    draws = e["draws"]
    allv = np.concatenate([d["r2_oos"] for d in draws.values()])
    lo, hi = np.percentile(allv, 0.5), np.percentile(allv, 99.5)
    bins = np.linspace(lo, hi, 50)
    for (label, d), color in zip(draws.items(), (plots.INK_3, plots.BLUE)):
        ax.hist(np.clip(d["r2_oos"], lo, hi), bins=bins, color=color, alpha=0.55, label=label)
    ax.axvline(0, color=plots.INK, linewidth=1)
    plots.percent_axis(ax, "x")
    ax.set_xlabel("Out-of-sample R² vs historical mean")
    ax.set_ylabel("Simulated samples")
    ax.legend(frameon=False, fontsize=9)
    m = e["meta"]
    tr = e["table"].set_index("truth")
    share = tr["OOS R2 > 0"].iloc[1]
    plots.titles(fig, f"Figure 5.5  A predictor that truly works beats the mean in only {share:.0%} of samples",
                 f"{m['n_reps']} simulated histories of {m['n_months']} months, first forecast at month {m['first']}"
                 f" · persistence {m['phi']}, correlation with return shocks {m['rho']}")
    plots.finish(fig, out / "fig5_5_known_truth.png")
    plt.close(fig)


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------


def _md(df: pd.DataFrame, fmt: dict) -> str:
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join("---" for _ in cols) + " |"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(fmt[c](r[c]) if c in fmt else str(r[c]) for c in cols) + " |")
    return "\n".join(lines)


def _num(spec):
    return lambda v: "" if (v is None or (isinstance(v, float) and math.isnan(v))) else format(v, spec)


def write_report(out, df, a, b, c, d, e, sim):
    md = ["# Lab 5 results: Does It Forecast, or Did It Fit?", ""]
    if sim:
        md += ["> **Simulated predictor data.** Parts A–D test that the code runs; they say nothing about real markets. "
               "In the simulated data only `dp` has (weak) predictive power. Part E is a simulation by design.", ""]
    md += ["**Claim on trial:** a predictor that fits well in-sample will forecast well out of sample.", "",
           f"Sample {df.index[0]} to {df.index[-1]}; walk-forward forecasts {a['oos_start']} to {a['oos_end']} "
           "(expanding window, at least 20 years of training data). Benchmark: the historical mean of the equity "
           "premium up to the forecast date.", ""]
    t = pd.concat([a["table"], a["extra"]], ignore_index=True)
    show = t[["predictor", "slope_t_in", "r2_in", "r2_oos", "cw_p", "dm_p", "published", "r2_oos_before_pub",
              "r2_oos_after_pub"]].rename(columns={
        "predictor": "Predictor", "slope_t_in": "In-sample t (NW)", "r2_in": "In-sample R²", "r2_oos": "OOS R²",
        "cw_p": "Clark-West p", "dm_p": "DM p", "published": "Published", "r2_oos_before_pub": "OOS R² to publication",
        "r2_oos_after_pub": "OOS R² after"})
    md += ["## Part A: Fit versus forecast", "",
           _md(show, {"In-sample t (NW)": _num(".2f"), "In-sample R²": _num(".2%"), "OOS R²": _num("+.2%"),
                      "Clark-West p": _num(".3f"), "DM p": _num(".3f"), "Published": _num(".0f"),
                      "OOS R² to publication": _num("+.2%"), "OOS R² after": _num("+.2%")}), "",
           "NW = Newey–West. OOS R² > 0 means the predictor beat the historical mean. Clark–West and DM p-values are "
           "one-sided (small favors the predictor). 'Published': year of an early paper proposing the predictor, as "
           "credited by Goyal and Welch (2008); before/after columns need at least 60 forecasts.", "",
           f"- Predictors with in-sample |t| > 1.96 (Newey–West): "
           f"{int((a['table']['slope_t_in'].abs() > 1.96).sum())} of 14.",
           f"- Predictors with OOS R² > 0: {int((a['table']['r2_oos'] > 0).sum())} of 14; Clark–West p < 0.05: "
           f"{int((a['table']['cw_p'] < 0.05).sum())} of 14.",
           f"- Rank correlation between in-sample and out-of-sample R²: "
           f"{a['table'][['r2_in', 'r2_oos']].corr(method='spearman').iloc[0, 1]:+.2f}.", "",
           "![Figure 5.1](fig5_1_fit_vs_forecast.png)", "", "![Figure 5.2](fig5_2_cumulative_sse.png)", ""]
    md += ["## Part B: Design choices", "",
           _md(b.rename(columns={"predictor": "Predictor"}), {col: _num("+.2%") for col in b.columns if col != "predictor"}), "",
           "![Figure 5.3](fig5_3_designs.png)", ""]
    md += ["## Part C: Leakage", "",
           _md(c["table"].drop(columns="kind").rename(columns={"evaluation": "Evaluation", "r2_oos": "OOS R²"}),
               {"OOS R²": _num("+.2%")}), "",
           "The real-time selection picked: " + ", ".join(f"{k} {v:.0%}" for k, v in c["picks"].head(5).items())
           + " of months.", "", "![Figure 5.4](fig5_4_leakage.png)", ""]
    md += ["## Part D: Economic and probabilistic value", "",
           "Mean-variance investor with risk aversion 3, equity weight between 0 and 150%, variance from the past 60 "
           "months. Predictive densities: normal, centered on each forecast, with the same 60-month volatility for "
           "the predictor and the benchmark.", "",
           _md(d.rename(columns={"predictor": "Predictor", "ce_gain": "CE gain (per year)",
                                 "avg_weight": "Average weight", "log_score_gain": "Log score gain",
                                 "crps_gain": "CRPS gain", "coverage_90": "90% interval coverage"}),
               {"CE gain (per year)": _num("+.2%"), "Average weight": _num(".0%"), "Log score gain": _num("+.5f"),
                "CRPS gain": _num("+.6f"), "90% interval coverage": _num(".1%")}), "",
           "Gains are relative to the historical mean; positive is better for all three.", ""]
    m = e["meta"]
    md += ["## Part E: Known truth (simulation)", "",
           f"{m['n_reps']} histories of {m['n_months']} months; first forecast at month {m['first']}; predictor "
           f"persistence {m['phi']}; correlation between predictor and return shocks {m['rho']}.", "",
           _md(e["table"].rename(columns={"truth": "Truth"}),
               {k: _num(".1%") for k in e["table"].columns if k != "truth" and "median" not in k}
               | {"median OOS R2": _num("+.2%"), "median in-sample R2": _num(".2%")}), "",
           "![Figure 5.5](fig5_5_known_truth.png)", ""]
    md += ["## Your verdict", "",
           "1. Does in-sample fit predict out-of-sample performance? Use Figure 5.1 and the rank correlation.",
           "2. Is any predictor a reliable forecaster? Weigh OOS R², Clark–West, the design choices in Part B, the "
           "economic value in Part D and the before/after-publication split.",
           "3. Part E shows that a predictor that truly works can still fail out of sample. What does that imply for "
           "how you read Part A? What would change your mind?", ""]
    (out / "lab05_report.md").write_text("\n".join(md))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", choices=["goyal", "sim"], default="goyal")
    ap.add_argument("--data-file", default=None, help="Goyal-Welch spreadsheet (.xlsx) or CSV export of its Monthly sheet")
    ap.add_argument("--start", default="1927-01", help="first month of the sample")
    ap.add_argument("--end", default=None, help="last month of the sample")
    ap.add_argument("--oos-start", default="1965-01", help="first forecast month")
    ap.add_argument("--min-train", type=int, default=240, help="minimum training months")
    ap.add_argument("--focus", default="dp", help="predictor used in the leakage experiments")
    ap.add_argument("--gamma", type=float, default=3.0, help="risk aversion in Part D")
    ap.add_argument("--sim-reps", type=int, default=500, help="Part E repetitions")
    ap.add_argument("--sim-true-r2", type=float, default=0.005, help="Part E true R-squared")
    ap.add_argument("--sim-phi", type=float, default=0.985, help="Part E predictor persistence")
    ap.add_argument("--sim-rho", type=float, default=-0.9, help="Part E correlation of predictor and return shocks")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--sim-seed", type=int, default=0, help="seed for simulated predictor data (--source sim)")
    ap.add_argument("--out", default=str(ROOT / "report"))
    return ap.parse_args(argv)


def run(args) -> dict:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    try:
        df = load(args.source, args.data_file, args.start, args.end, args.sim_seed)
    except DataUnavailable as err:
        raise SystemExit(str(err)) from None
    sim = df.attrs.get("simulated", False)

    a = part_a(df, args.oos_start, args.min_train)
    b = part_b(df, args.oos_start, args.min_train)
    c = part_c(df, a, args.oos_start, args.focus, args.min_train)
    d = part_d(df, a, args.gamma)
    e = part_e(args.sim_reps, true_r2=args.sim_true_r2, phi=args.sim_phi, rho=args.sim_rho, seed=args.seed)

    fig_fit_vs_forecast(a, out, sim)
    fig_cumulative(a, out, sim)
    fig_designs(b, out, sim)
    fig_leakage(c, out, sim)
    fig_known_truth(e, out)

    pd.concat([a["table"], a["extra"]]).to_csv(out / "table_fit_vs_forecast.csv", index=False)
    b.to_csv(out / "table_designs.csv", index=False)
    c["table"].to_csv(out / "table_leakage.csv", index=False)
    d.to_csv(out / "table_value.csv", index=False)
    e["table"].to_csv(out / "table_known_truth.csv", index=False)
    write_report(out, df, a, b, c, d, e, sim)

    tab = a["table"]
    summary = {
        "simulated": sim, "sample": [str(df.index[0]), str(df.index[-1])], "oos": [a["oos_start"], a["oos_end"]],
        "n_in_sample_significant": int((tab["slope_t_in"].abs() > 1.96).sum()),
        "n_oos_positive": int((tab["r2_oos"] > 0).sum()), "n_clark_west": int((tab["cw_p"] < 0.05).sum()),
        "rank_corr_in_oos": float(tab[["r2_in", "r2_oos"]].corr(method="spearman").iloc[0, 1]),
        "kitchen_sink_r2_oos": float(a["extra"]["r2_oos"].iloc[0]),
        "combination_r2_oos": float(a["extra"]["r2_oos"].iloc[1]),
        "leakage": c["table"].set_index("evaluation")["r2_oos"].to_dict(),
        "known_truth": e["table"].to_dict(orient="records"),
        "predictors": tab.to_dict(orient="records"),
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=float))

    print(f"A  in-sample |t| > 1.96: {summary['n_in_sample_significant']} of 14; OOS R2 > 0: "
          f"{summary['n_oos_positive']}; Clark-West p < 0.05: {summary['n_clark_west']}")
    print(f"   rank correlation of in-sample and OOS R2: {summary['rank_corr_in_oos']:+.2f}; kitchen sink "
          f"{summary['kitchen_sink_r2_oos']:+.2%}; combination {summary['combination_r2_oos']:+.2%}")
    for k, v in summary["leakage"].items():
        print(f"C  {k}: {v:+.2%}")
    et = e["table"].set_index("truth")
    print("E  OOS R2 > 0: " + "; ".join(f"{k} {v:.0%}" for k, v in et["OOS R2 > 0"].items()))
    print(f"Report: {out / 'lab05_report.md'}")
    if sim:
        print("NOTE: simulated predictor data for Parts A-D. These results test the code only.")
    return summary


def main(argv=None):
    return run(parse_args(argv))


if __name__ == "__main__":
    main()
