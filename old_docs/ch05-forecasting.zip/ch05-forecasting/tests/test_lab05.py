"""Tests for Lab 5. Run with:  python tests/test_lab05.py   (or: pytest tests/)

Runs offline. The Goyal-Welch parser is checked on a file in the published
layout (CSV and Excel), the forecasting code against direct calculations and
for leakage, the scoring rules against numerical integration, and the full
lab on simulated data.
"""

from __future__ import annotations

import math
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fintest.forecast import (  # noqa: E402
    certainty_equivalent,
    clark_west,
    crps_gaussian,
    diebold_mariano,
    expanding_univariate,
    gaussian_log_score,
    lagged_pairs,
    oos_r2,
    walk_forward,
)
from fintest.predictors import build_predictors, parse_goyal_welch, read_goyal_welch  # noqa: E402

GW_SAMPLE = """yyyymm,Index,D12,E12,b/m,tbl,AAA,BAA,lty,ntis,Rfree,infl,ltr,corpr,svar,csp,CRSP_SPvw,CRSP_SPvwx
202301,"4,076.60",66.92,187.08,0.21,0.0454,0.0436,0.0547,0.0362,-0.003,0.0035,0.0080,0.0750,0.0560,0.0021,,0.0650,0.0640
202302,"3,970.15",67.21,182.20,0.22,0.0464,0.0464,0.0575,0.0392,-0.004,0.0034,0.0056,-0.0480,-0.0410,0.0016,,-0.0240,-0.0260
202303,"4,109.31",67.48,177.65,0.21,0.0469,0.0453,0.0568,0.0366,-0.004,0.0036,0.0033,0.0470,0.0350,0.0038,,0.0350,0.0330
"""


def test_parse_goyal_welch_layout_and_predictors():
    raw = parse_goyal_welch(GW_SAMPLE)
    assert str(raw.index[0]) == "2023-01" and abs(raw.loc["2023-02", "index"] - 3970.15) < 1e-9
    p = build_predictors(raw)
    r = raw.loc["2023-03"]
    assert abs(p.loc["2023-03", "dp"] - (math.log(r["d12"]) - math.log(r["index"]))) < 1e-12
    assert abs(p.loc["2023-03", "dy"] - (math.log(r["d12"]) - math.log(raw.loc["2023-02", "index"]))) < 1e-12
    assert abs(p.loc["2023-03", "tms"] - (0.0366 - 0.0469)) < 1e-12
    assert abs(p.loc["2023-03", "dfy"] - (0.0568 - 0.0453)) < 1e-12
    assert abs(p.loc["2023-03", "dfr"] - (0.035 - 0.047)) < 1e-12
    assert abs(p.loc["2023-03", "infl"] - 0.0056) < 1e-12  # one-month publication lag
    assert abs(p.loc["2023-02", "eqp"] - (-0.024 - 0.0034)) < 1e-12


def test_read_excel_monthly_sheet():
    raw = pd.read_csv(pd.io.common.StringIO(GW_SAMPLE))
    with tempfile.TemporaryDirectory() as tmp:
        f = Path(tmp) / "PredictorData2025.xlsx"
        with pd.ExcelWriter(f) as xw:
            raw.head(1).to_excel(xw, sheet_name="Annual", index=False)
            raw.to_excel(xw, sheet_name="Monthly", index=False)
        out = read_goyal_welch(f)
        assert len(out) == 3 and str(out.index[-1]) == "2023-03"


def test_lagged_pairs_alignment():
    y = np.arange(10.0)
    z, _ = lagged_pairs(y, y, 1)
    assert z[0] == 1 and np.isnan(z[-1])
    z3, _ = lagged_pairs(y, y, 3)
    assert z3[0] == 1 + 2 + 3 and np.isnan(z3[-3:]).all()


def test_walk_forward_matches_direct_regression_and_mean():
    rng = np.random.default_rng(0)
    x = rng.standard_normal(300)
    y = np.r_[0, 0.2 * x[:-1]] + rng.standard_normal(300)
    z, X = lagged_pairs(y, x)
    w = walk_forward(z, X, first=150)
    t = 200
    A = np.column_stack([np.ones(t), X[:t]])
    b = np.linalg.lstsq(A, z[:t], rcond=None)[0]
    assert abs(w["model"][t] - (b[0] + b[1] * X[t])) < 1e-12
    assert abs(w["bench"][t] - z[:t].mean()) < 1e-12
    r = walk_forward(z, X, first=150, window=60)
    A = np.column_stack([np.ones(60), X[t - 60:t]])
    b = np.linalg.lstsq(A, z[t - 60:t], rcond=None)[0]
    assert abs(r["model"][t] - (b[0] + b[1] * X[t])) < 1e-12
    fast = expanding_univariate(z, X, 150)
    assert np.nanmax(np.abs(fast["model"] - w["model"])) < 1e-10


def test_no_future_data_in_forecasts():
    """Changing returns after month t must not change the forecast made at t."""
    rng = np.random.default_rng(1)
    x = rng.standard_normal(400)
    y = rng.standard_normal(400)
    for h, gap in ((1, 0), (12, 11)):
        z, X = lagged_pairs(y, x, h)
        w1 = walk_forward(z, X, 200, gap=gap)
        y2 = y.copy()
        y2[251:] += 10.0  # returns from month 251 on: unknown at the end of month 250
        z2, _ = lagged_pairs(y2, x, h)
        w2 = walk_forward(z2, X, 200, gap=gap)
        assert np.allclose(w1["model"][200:251], w2["model"][200:251], equal_nan=True)
    # Without purging, the 12-month forecast at 250 does use returns after 250: the leak the lab measures.
    z, X = lagged_pairs(y, x, 12)
    leak1 = walk_forward(z, X, 200, gap=0)["model"][250]
    z2, _ = lagged_pairs(y2, x, 12)
    leak2 = walk_forward(z2, X, 200, gap=0)["model"][250]
    assert abs(leak1 - leak2) > 1e-6


def test_campbell_thompson_restrictions():
    rng = np.random.default_rng(2)
    x = rng.standard_normal(300)
    y = np.r_[0, -0.3 * x[:-1]] + 0.1 * rng.standard_normal(300) - 0.5
    z, X = lagged_pairs(y, x)
    w = walk_forward(z, X, 150, sign=+1, nonneg=True)
    v = w["valid"]
    assert (w["model"][v] >= 0).all()
    assert np.allclose(w["model"][v], np.maximum(w["bench"][v], 0))  # wrong sign -> mean, floored at 0


def test_oos_r2_clark_west_and_dm():
    a = np.array([1.0, -1.0, 2.0, 0.0])
    assert oos_r2(a, a, np.zeros(4)) == 1.0
    assert oos_r2(a, np.zeros(4), np.zeros(4)) == 0.0
    rng = np.random.default_rng(3)
    a = rng.standard_normal(500)
    m = a * 0.3 + rng.standard_normal(500) * 0.1
    b = np.zeros(500)
    f = (a - b) ** 2 - ((a - m) ** 2 - (b - m) ** 2)
    t = f.mean() / (f.std(ddof=0) / math.sqrt(500))
    assert abs(clark_west(a, m, b)["stat"] - t) < 1e-10
    d = (a - b) ** 2 - (a - m) ** 2
    t_dm = d.mean() / (d.std(ddof=0) / math.sqrt(500)) * math.sqrt((500 + 1 - 2) / 500)
    assert abs(diebold_mariano(a, b, m)["stat"] - t_dm) < 1e-10
    # Size of Clark-West under the null with a nested model: near 5%, and DM is undersized.
    rej_cw = rej_dm = 0
    for s in range(200):
        r = np.random.default_rng(100 + s)
        x = r.standard_normal(600)
        y = r.standard_normal(600)
        z, X = lagged_pairs(y, x)
        w = expanding_univariate(z, X, 300)
        v = w["valid"]
        rej_cw += clark_west(z[v], w["model"][v], w["bench"][v])["p_value"] < 0.05
        rej_dm += diebold_mariano(z[v], w["bench"][v], w["model"][v])["p_value"] < 0.05
    assert 0.02 <= rej_cw / 200 <= 0.10 and rej_dm <= rej_cw


def test_scoring_rules():
    y, mu, s = 0.3, -0.1, 0.7
    grid = np.linspace(-10, 10, 400001)
    from fintest.stats import normal_cdf

    F = np.asarray(normal_cdf((grid - mu) / s))
    crps_num = np.trapezoid((F - (grid >= y)) ** 2, grid)
    assert abs(crps_gaussian(y, mu, s) - crps_num) < 5e-5  # grid error from the step at y
    assert abs(gaussian_log_score(0.0, 0.0, 1.0) + 0.5 * math.log(2 * math.pi)) < 1e-12
    # Propriety, in expectation: the true distribution scores best.
    rng = np.random.default_rng(4)
    ys = rng.normal(0, 1, 200_000)
    assert crps_gaussian(ys, 0, 1).mean() < crps_gaussian(ys, 0.2, 1).mean()
    assert crps_gaussian(ys, 0, 1).mean() < crps_gaussian(ys, 0, 1.3).mean()
    assert gaussian_log_score(ys, 0, 1).mean() > gaussian_log_score(ys, 0, 0.8).mean()


def test_certainty_equivalent():
    e = np.array([0.01, -0.02, 0.03, 0.00])
    rf = np.full(4, 0.002)
    w = np.ones(4)
    p = rf + e
    assert abs(certainty_equivalent(e, rf, w, 3) - 12 * (p.mean() - 1.5 * p.var(ddof=1))) < 1e-12
    assert abs(certainty_equivalent(e, rf, np.zeros(4), 3) - 12 * 0.002) < 1e-12


def test_part_e_true_predictor_beats_null():
    import lab05

    e = lab05.part_e(n_reps=60, seed=5, true_r2=0.01).get("table").set_index("truth")
    null, true = e.iloc[0], e.iloc[1]
    assert true["OOS R2 > 0"] > null["OOS R2 > 0"]
    assert null["Clark-West p < 0.05"] < 0.2
    assert true["Clark-West p < 0.05"] > null["Clark-West p < 0.05"]


def test_full_lab_runs_on_simulated_data():
    import lab05

    with tempfile.TemporaryDirectory() as tmp:
        summary = lab05.main(["--source", "sim", "--sim-reps", "30", "--out", tmp])
        out = Path(tmp)
        assert len(list(out.glob("fig5_*.png"))) == 5
        report = (out / "lab05_report.md").read_text()
        assert "Simulated predictor data" in report and "Your verdict" in report
        assert summary["simulated"] is True and len(summary["predictors"]) == 14
        lk = summary["leakage"]
        assert lk["dp, 12-month horizon, not purged"] > lk["dp, 12-month horizon, purged (gap 11)"] - 0.02


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print(f"ok  {name}")
