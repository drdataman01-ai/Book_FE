# Lab 5: Does It Forecast, or Did It Fit?

Companion lab for **Chapter 5** of *Financial Engineering and the Evidence: A Claim-Verify Approach to Quantitative Finance*.

**Claim on trial:** a predictor that fits well in-sample will forecast well out of sample.

## Quick start

1. Download the Goyal–Welch predictor data from [Amit Goyal's website](https://sites.google.com/view/agoyal145): under *A Comprehensive Look at the Empirical Performance of Equity Premium Prediction* (Goyal and Welch 2008), follow **Updated data**. Save the spreadsheet in `data/` with "predictor" or "goyal" in its file name (for example `data/PredictorData2025.xlsx`). A CSV export of its **Monthly** sheet also works.
2. Run:

```bash
pip install -r requirements.txt
python lab05.py                                   # finds the file in data/
python lab05.py --data-file data/PredictorData2025.xlsx
```

The lab runs in about 20 seconds. Open `report/lab05_report.md` for the results. For a guided version, open `lab05_walkthrough.ipynb` in Jupyter; it asks you to predict each result before you see it.

The website's links point to Google Drive, so the lab does not download the file itself.

### Testing the code without real data

```bash
python lab05.py --source sim
```

**Results from simulated data are not evidence about markets;** the report and figures are labeled. In the simulated data only `dp` has (weak) predictive power. The lab never switches to simulated data on its own.

## What the lab does

| Part | Question | Method | Output |
|---|---|---|---|
| A. Fit versus forecast | Do predictors that fit the past forecast the future? | Full-sample predictive regressions (Newey–West t) against expanding-window walk-forward forecasts from 1965; out-of-sample R² against the historical mean; Clark–West and Diebold–Mariano tests; before and after publication; kitchen sink and equal-weight combination | Figures 5.1–5.2 |
| B. Design choices | How much does the verdict depend on choices made before the test? | Expanding, 10-year and 20-year rolling windows; Campbell–Thompson restrictions | Figure 5.3 |
| C. Leakage | How much does borrowing from the future flatter results? | Full-sample coefficients; choosing the predictor with hindsight versus in real time; 12-month targets with and without purging | Figure 5.4 |
| D. Value | Does a forecast help an investor or a risk manager? | Certainty-equivalent gain of a mean-variance investor (risk aversion 3, weights 0–150%); log score, CRPS and 90% interval coverage of normal predictive densities | Table |
| E. Known truth | How often do the tests get it right? | 500 simulated histories with a persistent predictor that has no power and one with a true R² of 0.5% | Figure 5.5 |

### The predictors

The 14 monthly variables of Goyal and Welch (2008), Table 1, built from the spreadsheet's columns: dividend–price ratio (`dp`), dividend yield (`dy`), earnings–price ratio (`ep`), payout ratio (`de`), stock variance (`svar`), book-to-market (`bm`), net equity expansion (`ntis`), Treasury bill rate (`tbl`), long-term yield (`lty`), long-term bond return (`ltr`), term spread (`tms`), default yield spread (`dfy`), default return spread (`dfr`) and inflation (`infl`). See `fintest/predictors.py` for the exact formulas.

### Design notes

- **Target.** The simple monthly equity premium: the CRSP value-weighted S&P 500 return including dividends (`CRSP_SPvw`) minus the Treasury bill return (`Rfree`) for the same month. Where `CRSP_SPvw` is missing, the return is built from the index and dividends.
- **Timing.** Predictors observed at the end of month t forecast the premium in month t+1. Inflation enters with an extra month's lag, because the CPI is published with a delay. Forecasts are re-estimated every month using only pairs whose targets were known at the forecast date.
- **Benchmark.** The historical mean of the premium over the same training months.
- **Sample.** 1927 onward by default (`--start`); first forecast January 1965 (`--oos-start`); at least 20 years of training data (`--min-train 240`).
- **Clark–West versus Diebold–Mariano.** Every model here nests the historical mean, so Diebold–Mariano is undersized (it rejects too rarely) and Clark–West (2007) is the main test. Both are one-sided; Newey–West corrections are not needed for one-month forecasts.
- **Purging.** A 12-month target formed at month s is not fully observed until s + 12. When forecasting at t, the training set must stop at s = t − 12 (a gap of 11 pairs). Part C shows what happens without the gap.
- **Campbell–Thompson restrictions.** If the estimated slope has the opposite sign to the one proposed in the original paper (the signs are listed in `PREDICTORS`), use the historical mean; never forecast a negative premium.
- **Part D** uses the same 60-month volatility for both predictive densities, so the scores compare means only. Exercise 4 asks you to forecast volatility too.
- **Publication years** are those of an early paper proposing each predictor, as credited by Goyal and Welch (2008). They are approximate by nature; check them before relying on a before/after comparison.

## Options

```text
--source {goyal,sim}      real data (default) or simulated data for testing
--data-file PATH          Goyal-Welch spreadsheet or CSV export of its Monthly sheet
--start / --end YYYY-MM   sample period (default 1927-01 to the end of the file)
--oos-start YYYY-MM       first forecast month (default 1965-01)
--min-train N             minimum training months (default 240)
--focus NAME              predictor used in the leakage experiments (default dp)
--gamma G                 risk aversion in Part D (default 3)
--sim-reps N              Part E repetitions (default 500)
--sim-true-r2 R           Part E true R-squared (default 0.005)
--sim-phi P               Part E predictor persistence (default 0.985)
--sim-rho R               Part E correlation of predictor and return shocks (default -0.9)
--seed N                  random seed for Part E (default 2026)
--sim-seed N              seed for simulated predictor data (--source sim)
--out DIR                 output folder (default report/)
```

## Outputs (`report/`)

- `lab05_report.md`: all results, with a "Your verdict" prompt
- `fig5_1_fit_vs_forecast.png` to `fig5_5_known_truth.png`
- `table_fit_vs_forecast.csv`, `table_designs.csv`, `table_leakage.csv`, `table_value.csv`, `table_known_truth.csv`
- `summary.json`: headline numbers for grading or automated checks

## Files

```text
ch05-forecasting/
├── README.md
├── requirements.txt
├── lab05.py                 # the lab: parts A–E, figures, report
├── lab05_walkthrough.ipynb  # guided, step-by-step version
├── fintest/                 # the book's analysis module (Labs 1–5 subset)
│   ├── data.py              # French library download and parsing
│   ├── predictors.py        # Goyal–Welch data: reading, predictor construction, simulated version
│   ├── forecast.py          # walk-forward forecasts, OOS R², Clark–West, DM, scoring rules, CE gain
│   ├── stats.py, inference.py, multiple.py, plots.py
├── data/                    # put the Goyal–Welch file here
└── tests/test_lab05.py      # runs offline
```

Run the tests with `python tests/test_lab05.py` (or `pytest tests/`).

## Verification status

| Part | Status |
|---|---|
| Goyal–Welch reader | Tested on a CSV in the published column layout (including an index stored as text with thousands separators) and on an Excel file with a `Monthly` sheet; **confirm on the live file at first run** |
| Predictor formulas | Tested against hand calculations for `dp`, `dy`, `tms`, `dfy`, `dfr`, `infl` lag and the premium |
| Walk-forward forecasts | Tested against direct regressions (expanding and rolling) and the historical mean; fast and slow versions agree |
| No look-ahead | Tested: changing returns after month t leaves every forecast made at t unchanged, with purging; without purging, 12-month forecasts change (the leak Part C measures) |
| Campbell–Thompson restrictions | Tested |
| Clark–West and Diebold–Mariano | Tested against direct formulas; Clark–West rejects at close to 5% under the null and Diebold–Mariano less often |
| CRPS and log score | Tested against numerical integration and for propriety |
| Certainty equivalent | Tested against the formula |
| Full lab and notebook | Run end to end on simulated data |
| Real data | Not run from the build environment (network blocked) |

## Exercises

1. Move the first forecast to 1990 with `--oos-start 1990-01`. Which predictors' verdicts change? What does that say about choosing an evaluation period?
2. Part A: compare each predictor's out-of-sample R² before and after its publication year. Is the pattern consistent with McLean and Pontiff (2016)?
3. Part C: repeat the leakage experiments with `--focus tms` and `--focus ep`. Which leak matters most, and why does purging matter more for persistent predictors?
4. Part D: replace the 60-month volatility with a forecast of next month's volatility (for example from `svar`). Does the log score now favor the predictor? Why do scoring rules reward getting the spread right, not just the mean?
5. Part E: find the smallest true R² at which Clark–West rejects in at least half the simulated histories. Translate it into an annualized Sharpe-ratio gain for a market-timing investor (Campbell and Thompson 2008 give the formula).

## Data citation

Goyal, A., and Welch, I. (2008). A comprehensive look at the empirical performance of equity premium prediction. *Review of Financial Studies*, 21(4), 1455–1508. Updated data from Amit Goyal's website, https://sites.google.com/view/agoyal145.
