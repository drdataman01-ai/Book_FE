"""Lab 7: Can Valuations Time the Market?

Chapter 7 of *Financial Engineering and the Evidence: A Claim-Verify
Approach to Quantitative Finance*.

CLAIM ON TRIAL
  "Valuation ratios and macroeconomic variables forecast the equity premium."

WHAT THE LAB DOES
  Part A  Replication. Predictive regressions of 1-month, 1-year and 10-year
          log excess returns on the dividend-price ratio, CAPE, the term
          spread and the "Fed model" spread, with Newey-West and Hodrick
          (1992) t-statistics.
  Part B  Walk-forward forecasts at each horizon against the historical
          mean, with purging for overlapping targets, the Clark-West test and
          the Campbell-Thompson restrictions.
  Part C  Stress tests. A bootstrap under the null that corrects for the
          Stambaugh bias and overlap; subperiods; rolling 20-year estimates.
  Part D  What survives: ranges for 10-year real returns given today's CAPE,
          with their honest width.

DATA
  Goyal-Welch monthly predictor data (Amit Goyal's website). Optional:
  Robert Shiller's ie_data.xls, for CAPE and real returns back to 1881.

USAGE
  python lab07.py --data-file data/PredictorData2025.xlsx [--shiller-file data/ie_data.xls]
  python lab07.py --source sim             # fake data, to test the code

OUTPUT
  report/lab07_report.md, five figures (PNG), CSV tables and summary.json.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

from fintest import plots
from fintest.data import DataUnavailable
from fintest.forecast import clark_west, oos_r2, walk_forward
from fintest.inference import long_horizon_tstats
from fintest.predictors import load_predictors, simulated_predictors
from fintest.shiller import read_shiller, real_returns

ROOT = Path(__file__).resolve().parent
HORIZONS = (1, 12, 120)
H_LABEL = {1: "1 month", 12: "1 year", 120: "10 years"}
# name: (label, expected sign of the slope on future returns)
PREDICTORS = {
    "dp": ("Dividend-price ratio (log)", +1),
    "cape": ("CAPE (log, sign reversed)", +1),
    "tms": ("Term spread", +1),
    "fedspread": ("Fed model: earnings yield minus 10-year yield", +1),
}
COLORS = {"dp": plots.BLUE, "cape": plots.ORANGE, "tms": plots.AQUA, "fedspread": plots.VIOLET}


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------


def load(source: str, data_file=None, start="1927-01", end=None, sim_seed: int = 0) -> pd.DataFrame:
    raw = simulated_predictors(seed=sim_seed) if source == "sim" else load_predictors(data_file)
    sim = raw.attrs.get("simulated", False)
    df = pd.DataFrame(index=raw.index)
    df["xr"] = np.log1p(raw["ret"]) - np.log1p(raw["rf"])  # monthly log excess return
    df["real"] = np.log1p(raw["ret"]) - np.log1p(raw["infl_now"])  # monthly log real return
    df["dp"] = raw["dp"]
    df["cape"] = -np.log(raw["cape"])  # sign reversed: high values mean cheap stocks, like dp
    df["cape_level"] = raw["cape"]
    df["tms"] = raw["tms"]
    df["fedspread"] = raw["fedspread"]
    if start:
        df = df.loc[pd.Period(start, "M"):]
    if end:
        df = df.loc[:pd.Period(end, "M")]
    df = df[df["xr"].notna()].copy()
    df.attrs["simulated"] = sim
    return df


def _target(r: np.ndarray, h: int) -> np.ndarray:
    """z[t] = r[t+1] + ... + r[t+h]; NaN where not yet observed."""
    T = len(r)
    z = np.full(T, np.nan)
    c = np.concatenate([[0.0], np.cumsum(r)])
    z[:T - h] = c[1 + h:T + 1] - c[1:T - h + 1]
    return z


def _valid_span(df, name):
    x = df[name]
    first = x.first_valid_index()
    return df.loc[first:]


# ---------------------------------------------------------------------------
# Part A: replication
# ---------------------------------------------------------------------------


def part_a(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for name in PREDICTORS:
        d = _valid_span(df, name)
        r, x = d["xr"].to_numpy(), d[name].to_numpy()
        for h in HORIZONS:
            if len(d) < h + 120:
                continue
            res = long_horizon_tstats(r, x, h, nw_lags=max(h - 1, 0) if h > 1 else 0)
            rows.append({"predictor": name, "horizon": h, "slope": float(res["slope"][0]), "r2": float(res["r2"][0]),
                         "t_nw": float(res["t_newey_west"][0]), "t_hodrick": float(res["t_hodrick"][0]),
                         "t_classical": float(res["t_classical"][0]), "n_obs": int(res["n_obs"]),
                         "start": str(d.index[0])})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Part B: walk-forward
# ---------------------------------------------------------------------------


def part_b(df: pd.DataFrame, oos_start: str = "1965-01", min_train: int = 240) -> dict:
    rows, fc = [], {}
    first = int(np.searchsorted(df.index.astype(str), oos_start))
    r = df["xr"].to_numpy()
    for name, (_, sign) in PREDICTORS.items():
        x = df[name].to_numpy()
        for h in HORIZONS:
            z = _target(r, h)
            mt = min_train if h < 120 else max(min_train - 120, 120)
            w = walk_forward(z, x, first, gap=h - 1, min_train=mt)
            wc = walk_forward(z, x, first, gap=h - 1, min_train=mt, sign=sign, nonneg=True)
            v = w["valid"]
            if v.sum() < 24:
                continue
            cw = clark_west(z[v], w["model"][v], w["bench"][v], lags=h - 1)
            rows.append({"predictor": name, "horizon": h, "r2_oos": oos_r2(z[v], w["model"][v], w["bench"][v]),
                         "r2_oos_ct": oos_r2(z[wc["valid"]], wc["model"][wc["valid"]], wc["bench"][wc["valid"]]),
                         "cw_stat": cw["stat"], "cw_p": cw["p_value"], "n_forecasts": int(v.sum()),
                         "first": str(df.index[np.flatnonzero(v)[0]]), "last": str(df.index[np.flatnonzero(v)[-1]])})
            fc[(name, h)] = w
    return {"table": pd.DataFrame(rows), "forecasts": fc}


# ---------------------------------------------------------------------------
# Part C: stress tests
# ---------------------------------------------------------------------------


def stambaugh_bootstrap(r: np.ndarray, x: np.ndarray, h: int, n_boot: int = 500, seed: int = 0) -> np.ndarray:
    """Newey-West t-statistics under the null of no predictability, keeping the predictor's persistence
    and the correlation between its shocks and return shocks (Stambaugh 1999; Nelson and Kim 1993).

    The predictor is fitted as an AR(1); return shocks and predictor shocks are resampled together
    (as pairs, i.i.d.), returns are rebuilt with no predictability, the predictor is rebuilt from its
    AR(1), and the same regression is run on each artificial sample.
    """
    rng = np.random.default_rng(seed)
    T = len(r)
    A = np.column_stack([np.ones(T - 1), x[:-1]])
    a, phi = np.linalg.lstsq(A, x[1:], rcond=None)[0]
    v = x[1:] - a - phi * x[:-1]
    u = r[1:] - r[1:].mean()
    ts = np.empty(n_boot)
    for b in range(n_boot):
        idx = rng.integers(0, T - 1, T - 1)
        xs = np.empty(T)
        xs[0] = x[0]
        vs = v[idx]
        for t in range(1, T):
            xs[t] = a + phi * xs[t - 1] + vs[t - 1]
        rs = np.empty(T)
        rs[0] = r.mean()
        rs[1:] = r.mean() + u[idx]
        ts[b] = long_horizon_tstats(rs, xs, h, nw_lags=max(h - 1, 0))["t_newey_west"][0]
    return ts


def part_c(df: pd.DataFrame, a: pd.DataFrame, n_boot: int = 500, seed: int = 0) -> dict:
    boot_rows, draws = [], {}
    for name in PREDICTORS:
        d = _valid_span(df, name)
        r, x = d["xr"].to_numpy(), d[name].to_numpy()
        for h in (1, 12):
            ts = stambaugh_bootstrap(r, x, h, n_boot, seed)
            t_act = float(a[(a.predictor == name) & (a.horizon == h)]["t_nw"].iloc[0])
            sign = PREDICTORS[name][1]
            boot_rows.append({"predictor": name, "horizon": h, "t_nw": t_act,
                              "null_mean_t": float(ts.mean()), "null_95": float(np.quantile(sign * ts, 0.95) * sign),
                              "p_boot": float(np.mean(sign * ts >= sign * t_act)),
                              "p_normal": float(0.5 * math.erfc(sign * t_act / math.sqrt(2)))})
            draws[(name, h)] = ts
    # Subperiods at the 1-year horizon.
    cuts = [("1927-1964", None, "1964-12"), ("1965-1994", "1965-01", "1994-12"), ("1995-end", "1995-01", None)]
    sub_rows = []
    for name in PREDICTORS:
        for label, s, e in cuts:
            d = df.loc[pd.Period(s, "M") if s else None:pd.Period(e, "M") if e else None]
            d = d[d[name].notna()]
            if len(d) < 180:
                continue
            res = long_horizon_tstats(d["xr"].to_numpy(), d[name].to_numpy(), 12, nw_lags=11)
            sub_rows.append({"predictor": name, "period": label, "slope": float(res["slope"][0]),
                             "r2": float(res["r2"][0]), "t_nw": float(res["t_newey_west"][0])})
    # Rolling 20-year t-statistics at the 1-year horizon.
    roll = {}
    for name in PREDICTORS:
        d = _valid_span(df, name)
        r, x = d["xr"].to_numpy(), d[name].to_numpy()
        ends, tv = [], []
        for end in range(240, len(d) - 12, 6):
            res = long_horizon_tstats(r[end - 240:end + 12], x[end - 240:end + 12], 12, nw_lags=11)
            ends.append(d.index[end].to_timestamp())
            tv.append(float(res["t_newey_west"][0]))
        roll[name] = (ends, tv)
    return {"bootstrap": pd.DataFrame(boot_rows), "draws": draws, "subperiods": pd.DataFrame(sub_rows), "rolling": roll}


# ---------------------------------------------------------------------------
# Part D: 10-year ranges
# ---------------------------------------------------------------------------


def part_d(df: pd.DataFrame, shiller: pd.DataFrame | None = None, oos_start: str = "1965-01") -> dict:
    """Annualized 10-year real returns against starting CAPE: fit, honest forecast errors and today's range."""
    if shiller is not None:
        src = "Shiller"
        real = real_returns(shiller).to_numpy()
        cape = shiller["cape"].to_numpy()
        idx = shiller.index
    else:
        src = "Goyal-Welch"
        real = df["real"].to_numpy()
        cape = df["cape_level"].to_numpy()
        idx = df.index
    ok_start = np.flatnonzero(np.isfinite(cape) & np.isfinite(real))
    s0 = ok_start[0]
    real, cape, idx = real[s0:], cape[s0:], idx[s0:]
    real = np.where(np.isfinite(real), real, 0.0)
    z = _target(real, 120) / 10  # annualized log real return over the next 10 years
    x = np.log(cape)
    ok = np.isfinite(z) & np.isfinite(x)
    A = np.column_stack([np.ones(ok.sum()), x[ok]])
    b = np.linalg.lstsq(A, z[ok], rcond=None)[0]
    resid = z[ok] - A @ b
    r2 = 1 - resid.var() / z[ok].var()
    first = int(np.searchsorted(idx.astype(str), oos_start))
    w = walk_forward(z, x, first, gap=119, min_train=120)
    v = w["valid"]
    rmse_m = float(np.sqrt(np.mean((z[v] - w["model"][v]) ** 2))) if v.any() else float("nan")
    rmse_b = float(np.sqrt(np.mean((z[v] - w["bench"][v]) ** 2))) if v.any() else float("nan")
    last = np.flatnonzero(np.isfinite(x))[-1]
    point = float(b[0] + b[1] * x[last])
    return {"source": src, "slope": float(b[1]), "intercept": float(b[0]), "r2_in": float(r2),
            "rmse_model": rmse_m, "rmse_bench": rmse_b, "r2_oos": oos_r2(z[v], w["model"][v], w["bench"][v])
            if v.any() else float("nan"), "n_oos": int(v.sum()),
            "cape_now": float(cape[last]), "date_now": str(idx[last]), "point_now": point,
            "range_now": (point - 1.645 * rmse_m, point + 1.645 * rmse_m),
            "scatter": pd.DataFrame({"date": idx[ok].to_timestamp(), "cape": cape[ok], "ret10": z[ok]}),
            "sample": (str(idx[0]), str(idx[np.flatnonzero(ok)[-1]]))}


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------


def _sub(sim: bool, text: str) -> str:
    return text + ("  ·  SIMULATED DATA: tests the code only" if sim else "")


def _grouped(ax, table, value, ylabel):
    names = list(PREDICTORS)
    width = 0.2
    for j, name in enumerate(names):
        g = table[table.predictor == name].set_index("horizon")
        xs = [i + (j - 1.5) * width for i, h in enumerate(HORIZONS) if h in g.index]
        vals = [g.loc[h, value] for h in HORIZONS if h in g.index]
        ax.bar(xs, vals, width=width, color=COLORS[name], label=PREDICTORS[name][0])
    ax.set_xticks(range(len(HORIZONS)), [H_LABEL[h] for h in HORIZONS], color=plots.INK)
    ax.axhline(0, color=plots.INK_3, linewidth=1)
    plots.percent_axis(ax)
    ax.set_ylabel(ylabel)
    ax.grid(axis="x", visible=False)


def fig_in_sample(a, out, sim, period):
    fig, ax, plt = plots.new_figure(9.0, 4.8)
    _grouped(ax, a, "r2", "In-sample R²")
    for _, r in a.iterrows():
        i = HORIZONS.index(r.horizon)
        j = list(PREDICTORS).index(r.predictor)
        ax.text(i + (j - 1.5) * 0.2, max(r.r2, 0) + 0.004, f"t={r.t_nw:.1f}", ha="center", fontsize=7.5,
                color=plots.INK_2, rotation=90, va="bottom")
    ax.set_ylim(min(0, a["r2"].min() * 1.2), a["r2"].max() * 1.35 + 0.02)
    ax.legend(frameon=False, fontsize=8.5, loc="upper left")
    plots.titles(fig, "Figure 7.1  In-sample fit rises with the horizon",
                 _sub(sim, f"{period} · regressions of future log excess returns on each predictor · t: Newey–West "
                           "(lags = horizon − 1)"))
    plots.finish(fig, out / "fig7_1_in_sample.png")
    plt.close(fig)


def fig_oos(b, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 4.8)
    t = b["table"].copy()
    lo = -0.3
    t["r2_plot"] = t["r2_oos"].clip(lower=lo)
    _grouped(ax, t, "r2_plot", "Out-of-sample R² vs historical mean")
    for _, r in t.iterrows():
        if r.r2_oos < lo:
            i = HORIZONS.index(r.horizon)
            j = list(PREDICTORS).index(r.predictor)
            ax.text(i + (j - 1.5) * 0.2, lo, f"{r.r2_oos:.0%}", ha="center", va="top", fontsize=7.5, color=plots.INK)
    ax.set_ylim(lo - 0.05, max(0.1, t["r2_plot"].max() * 1.3))
    ax.legend(frameon=False, fontsize=8.5, loc="lower left")
    plots.titles(fig, "Figure 7.2  Out of sample, the fit mostly disappears",
                 _sub(sim, "Walk-forward forecasts from 1965 with expanding windows, purged for overlapping targets "
                           f"· bars below {lo:.0%} are cut off and labeled"))
    plots.finish(fig, out / "fig7_2_out_of_sample.png")
    plt.close(fig)


def fig_rolling(c, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 4.6)
    for name in PREDICTORS:
        ends, tv = c["rolling"][name]
        ax.plot(ends, tv, color=COLORS[name], linewidth=1.8, label=PREDICTORS[name][0])
    ax.axhline(1.96, color=plots.INK_3, linewidth=1, linestyle=(0, (4, 3)))
    ax.axhline(-1.96, color=plots.INK_3, linewidth=1, linestyle=(0, (4, 3)))
    ax.axhline(0, color=plots.INK_3, linewidth=1)
    ax.set_ylabel("t-statistic (Newey–West)")
    ax.legend(frameon=False, fontsize=8.5, loc="upper left", ncol=2)
    plots.titles(fig, "Figure 7.3  Evidence that comes and goes",
                 _sub(sim, "t-statistic of each predictor's slope for 1-year returns, estimated over rolling 20-year "
                           "windows (plotted at the window's end) · dashed: ±1.96"))
    plots.finish(fig, out / "fig7_3_rolling.png")
    plt.close(fig)


def fig_bootstrap(c, out, sim, name="dp", h=12):
    fig, ax, plt = plots.new_figure(8.5, 4.6)
    ts = c["draws"][(name, h)]
    row = c["bootstrap"].set_index(["predictor", "horizon"]).loc[(name, h)]
    ax.hist(ts, bins=40, color=plots.INK_3, alpha=0.7)
    ax.axvline(row.t_nw, color=plots.RED, linewidth=2)
    ax.axvline(1.645 * PREDICTORS[name][1], color=plots.INK_2, linewidth=1, linestyle=(0, (4, 3)))
    ax.axvline(row.null_95, color=plots.BLUE, linewidth=1.5, linestyle=(0, (4, 3)))
    top = ax.get_ylim()[1]
    box = {"facecolor": plots.SURFACE, "edgecolor": "none", "pad": 1.5}
    ax.text(row.t_nw, top * 0.97, f" actual t = {row.t_nw:.2f}\n bootstrap p = {row.p_boot:.3f}", color=plots.RED,
            fontsize=9, va="top", bbox=box)
    ax.text(row.null_95, top * 0.78, f" 95% under the null: {row.null_95:.2f}", color=plots.BLUE, fontsize=8.5,
            bbox=box)
    ax.text(1.645 * PREDICTORS[name][1], top * 0.88, " textbook 1.645", color=plots.INK_2, fontsize=8.5, bbox=box)
    ax.set_xlabel("Newey–West t-statistic when the predictor has no power")
    ax.set_ylabel("Bootstrap samples")
    plots.titles(fig, "Figure 7.4  A persistent predictor makes t-statistics look better than they are",
                 _sub(sim, f"{PREDICTORS[name][0]}, {H_LABEL[h]} returns · null distribution from a bootstrap that keeps "
                           "the predictor's persistence and its correlation with returns"))
    plots.finish(fig, out / "fig7_4_bootstrap.png")
    plt.close(fig)


def fig_cape(d, out, sim):
    fig, ax, plt = plots.new_figure(9.0, 5.2)
    s = d["scatter"]
    decades = (s["date"].dt.year // 20) * 20
    cmap = plt.get_cmap("viridis")
    uniq = sorted(decades.unique())
    for k, dec in enumerate(uniq):
        m = decades == dec
        ax.scatter(s["cape"][m], s["ret10"][m], s=7, color=cmap(k / max(1, len(uniq) - 1)), alpha=0.6,
                   label=f"{dec}–{dec + 19}" if len(uniq) < 9 else None, linewidths=0)
    xs = np.linspace(s["cape"].min(), max(s["cape"].max(), d["cape_now"]) * 1.02, 100)
    fit = d["intercept"] + d["slope"] * np.log(xs)
    ax.plot(xs, fit, color=plots.INK, linewidth=1.8)
    ax.fill_between(xs, fit - 1.645 * d["rmse_model"], fit + 1.645 * d["rmse_model"], color=plots.INK, alpha=0.08)
    lo, hi = d["range_now"]
    ax.errorbar([d["cape_now"]], [d["point_now"]], yerr=[[d["point_now"] - lo], [hi - d["point_now"]]], fmt="o",
                color=plots.RED, capsize=5, markersize=7, linewidth=2)
    ax.annotate(f"CAPE {d['cape_now']:.0f} ({d['date_now']}):\n{lo:.1%} to {hi:.1%} a year", (d["cape_now"], hi),
                textcoords="offset points", xytext=(-10, 12), ha="right", fontsize=9, color=plots.RED,
                bbox={"facecolor": plots.SURFACE, "edgecolor": plots.GRID, "pad": 3})
    ax.axhline(0, color=plots.INK_3, linewidth=1)
    plots.percent_axis(ax)
    ax.set_xlabel("CAPE at the start")
    ax.set_ylabel("Annualized real return, next 10 years")
    ax.legend(frameon=False, fontsize=8, loc="upper right", markerscale=2.5)
    plots.titles(fig, "Figure 7.5  CAPE sets a range for the next decade, not a forecast for next year",
                 _sub(sim, f"{d['source']} data, {d['sample'][0]} to {d['sample'][1]} start dates · band and red range: "
                           "±1.645 × the walk-forward forecast error (about a 90% range)"))
    plots.finish(fig, out / "fig7_5_cape_ranges.png")
    plt.close(fig)


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------


def _md(df: pd.DataFrame, fmt: dict) -> str:
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join("---" for _ in cols) + " |"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(fmt[c](r[c]) if c in fmt else str(r[c]) for c in cols) + " |")
    return "\n".join(lines)


def _num(spec):
    return lambda v: "" if (v is None or (isinstance(v, float) and math.isnan(v))) else format(v, spec)


def write_report(out, df, a, b, c, d, sim, period):
    md = ["# Lab 7 results: Can Valuations Time the Market?", ""]
    if sim:
        md += ["> **Simulated data.** These results test that the code runs; they say nothing about real markets. In "
               "the simulated data only the dividend–price ratio (and CAPE, which is built from it) has weak "
               "predictive power.", ""]
    md += ["**Claim on trial:** valuation ratios and macroeconomic variables forecast the equity premium.", "",
           f"Sample {period}. Returns are monthly log excess returns (total return minus the Treasury bill), summed "
           "over the horizon. CAPE enters as minus its log, so that for every predictor a high value is expected to "
           "mean high future returns.", ""]
    lab = lambda n: PREDICTORS[n][0]  # noqa: E731
    at = a.assign(predictor=a.predictor.map(lab), horizon=a.horizon.map(H_LABEL))
    md += ["## Part A: Replication (in-sample)", "",
           _md(at[["predictor", "horizon", "slope", "r2", "t_classical", "t_nw", "t_hodrick", "n_obs", "start"]].rename(
               columns={"predictor": "Predictor", "horizon": "Horizon", "slope": "Slope", "r2": "R²",
                        "t_classical": "t (OLS)", "t_nw": "t (Newey–West)", "t_hodrick": "t (Hodrick)",
                        "n_obs": "Observations", "start": "From"}),
               {"Slope": _num(".3f"), "R²": _num(".1%"), "t (OLS)": _num(".2f"), "t (Newey–West)": _num(".2f"),
                "t (Hodrick)": _num(".2f")}), "",
           "OLS t-statistics ignore the overlap in multi-month returns and are shown only to see how much it matters.",
           "", "![Figure 7.1](fig7_1_in_sample.png)", ""]
    bt = b["table"].assign(predictor=b["table"].predictor.map(lab), horizon=b["table"].horizon.map(H_LABEL))
    md += ["## Part B: Walk-forward forecasts", "",
           _md(bt[["predictor", "horizon", "r2_oos", "r2_oos_ct", "cw_p", "n_forecasts", "first", "last"]].rename(
               columns={"predictor": "Predictor", "horizon": "Horizon", "r2_oos": "OOS R²",
                        "r2_oos_ct": "OOS R², Campbell–Thompson", "cw_p": "Clark–West p", "n_forecasts": "Forecasts",
                        "first": "First", "last": "Last"}),
               {"OOS R²": _num("+.1%"), "OOS R², Campbell–Thompson": _num("+.1%"), "Clark–West p": _num(".3f")}), "",
           "Forecasts begin in 1965 and use only data available at each date; training pairs whose targets were "
           "not yet observed are purged. Clark–West uses Newey–West errors with lags = horizon − 1. Overlapping "
           "10-year forecasts are highly dependent, so their test statistics are fragile.", "",
           "![Figure 7.2](fig7_2_out_of_sample.png)", ""]
    ct = c["bootstrap"].assign(predictor=c["bootstrap"].predictor.map(lab), horizon=c["bootstrap"].horizon.map(H_LABEL))
    md += ["## Part C: Stress tests", "", "**Stambaugh bias and overlap: bootstrap under the null**", "",
           _md(ct.rename(columns={"predictor": "Predictor", "horizon": "Horizon", "t_nw": "Actual t",
                                  "null_mean_t": "Average t under the null", "null_95": "95% critical value under the null",
                                  "p_boot": "Bootstrap p", "p_normal": "Textbook p"}),
               {"Actual t": _num(".2f"), "Average t under the null": _num("+.2f"),
                "95% critical value under the null": _num(".2f"), "Bootstrap p": _num(".3f"), "Textbook p": _num(".3f")}),
           "", "One-sided p-values in the direction the original papers predicted.", "",
           "**Subperiods (1-year horizon)**", "",
           _md(c["subperiods"].assign(predictor=c["subperiods"].predictor.map(lab)).rename(columns={
               "predictor": "Predictor", "period": "Period", "slope": "Slope", "r2": "R²", "t_nw": "t (Newey–West)"}),
               {"Slope": _num(".3f"), "R²": _num(".1%"), "t (Newey–West)": _num(".2f")}), "",
           "![Figure 7.3](fig7_3_rolling.png)", "", "![Figure 7.4](fig7_4_bootstrap.png)", ""]
    lo, hi = d["range_now"]
    md += ["## Part D: Ranges for the next decade", "",
           f"- Data: {d['source']}, start dates {d['sample'][0]} to {d['sample'][1]}.",
           f"- Regression of annualized 10-year real log returns on log CAPE: slope {d['slope']:.3f}, in-sample R² "
           f"{d['r2_in']:.0%}.",
           f"- Walk-forward from 1965 ({d['n_oos']} overlapping forecasts): out-of-sample R² {d['r2_oos']:+.0%}; "
           f"forecast error (RMSE) {d['rmse_model']:.1%} a year for the CAPE model and {d['rmse_bench']:.1%} for the "
           "historical mean.",
           f"- Latest CAPE {d['cape_now']:.1f} ({d['date_now']}): point forecast {d['point_now']:.1%} a year; about a "
           f"90% range of {lo:.1%} to {hi:.1%} a year (±1.645 × the walk-forward RMSE).", "",
           "Overlapping 10-year windows mean the effective number of independent observations is small: about one "
           "per decade. Treat the range, not the point, as the result.", "",
           "![Figure 7.5](fig7_5_cape_ranges.png)", ""]
    md += ["## Your verdict", "",
           "1. Does any predictor time the market at the 1-month or 1-year horizon? Use Parts B and C.",
           "2. Does CAPE carry information about the next decade? How wide is the honest range, and is that useful?",
           "3. Which stress test did the most damage to the in-sample evidence?", ""]
    (out / "lab07_report.md").write_text("\n".join(md))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", choices=["goyal", "sim"], default="goyal")
    ap.add_argument("--data-file", default=None, help="Goyal-Welch spreadsheet or CSV export of its Monthly sheet")
    ap.add_argument("--shiller-file", default=None, help="optional: Shiller ie_data.xls for Part D")
    ap.add_argument("--start", default="1927-01")
    ap.add_argument("--end", default=None)
    ap.add_argument("--oos-start", default="1965-01")
    ap.add_argument("--n-boot", type=int, default=500, help="bootstrap samples in Part C")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--sim-seed", type=int, default=0)
    ap.add_argument("--out", default=str(ROOT / "report"))
    return ap.parse_args(argv)


def run(args) -> dict:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    try:
        df = load(args.source, args.data_file, args.start, args.end, args.sim_seed)
        shiller = read_shiller(args.shiller_file) if args.shiller_file else None
    except DataUnavailable as err:
        raise SystemExit(str(err)) from None
    sim = df.attrs.get("simulated", False)
    period = f"{df.index[0]} to {df.index[-1]}"

    a = part_a(df)
    b = part_b(df, args.oos_start)
    c = part_c(df, a, args.n_boot, args.seed)
    d = part_d(df, shiller, args.oos_start)

    fig_in_sample(a, out, sim, period)
    fig_oos(b, out, sim)
    fig_rolling(c, out, sim)
    fig_bootstrap(c, out, sim)
    fig_cape(d, out, sim)

    a.to_csv(out / "table_in_sample.csv", index=False)
    b["table"].to_csv(out / "table_out_of_sample.csv", index=False)
    c["bootstrap"].to_csv(out / "table_bootstrap.csv", index=False)
    c["subperiods"].to_csv(out / "table_subperiods.csv", index=False)
    d["scatter"].to_csv(out / "table_cape_scatter.csv", index=False)
    write_report(out, df, a, b, c, d, sim, period)

    summary = {"simulated": sim, "period": period,
               "in_sample": a.to_dict(orient="records"), "out_of_sample": b["table"].to_dict(orient="records"),
               "bootstrap": c["bootstrap"].to_dict(orient="records"),
               "cape_decade": {k: d[k] for k in ("source", "slope", "r2_in", "r2_oos", "rmse_model", "rmse_bench",
                                                 "cape_now", "date_now", "point_now", "range_now")}}
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=float))

    piv = b["table"].pivot(index="predictor", columns="horizon", values="r2_oos")
    print("OOS R2 by horizon (months):")
    print(piv.rename(columns=H_LABEL).map(lambda v: f"{v:+.1%}").to_string())
    bs = c["bootstrap"].set_index(["predictor", "horizon"])
    print(f"dp, 1 year: t = {bs.loc[('dp', 12), 't_nw']:.2f}, bootstrap p = {bs.loc[('dp', 12), 'p_boot']:.3f}, "
          f"textbook p = {bs.loc[('dp', 12), 'p_normal']:.3f}")
    lo, hi = d["range_now"]
    print(f"CAPE {d['cape_now']:.1f} ({d['date_now']}): 10-year real return {d['point_now']:.1%} a year, range "
          f"{lo:.1%} to {hi:.1%}")
    print(f"Report: {out / 'lab07_report.md'}")
    if sim:
        print("NOTE: simulated data. These results test the code only.")
    return summary


def main(argv=None):
    return run(parse_args(argv))


if __name__ == "__main__":
    main()
