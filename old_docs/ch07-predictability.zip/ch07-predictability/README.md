# Lab 7: Can Valuations Time the Market?

Companion lab for **Chapter 7** of *Financial Engineering and the Evidence: A Claim-Verify Approach to Quantitative Finance*.

**Claim on trial:** valuation ratios and macroeconomic variables forecast the equity premium.

## Quick start

1. Download the Goyal–Welch predictor data from [Amit Goyal's website](https://sites.google.com/view/agoyal145) (under Goyal and Welch 2008, **Updated data**) and save it in `data/` with "predictor" or "goyal" in the file name. This is the same file as Lab 5.
2. Optional: download `ie_data.xls` from [Robert Shiller's data page](http://www.econ.yale.edu/~shiller/data.htm) for Part D's long history (from 1881).
3. Run:

```bash
pip install -r requirements.txt
python lab07.py
python lab07.py --shiller-file data/ie_data.xls
```

The lab runs in under a minute. Open `report/lab07_report.md`. For a guided version, open `lab07_walkthrough.ipynb`.

### Testing the code without real data

```bash
python lab07.py --source sim
```

**Results from simulated data are not evidence about markets;** the report and figures are labeled. In the simulated data only the dividend–price ratio (and CAPE, built from it) has weak predictive power.

## What the lab does

| Part | Question | Method | Output |
|---|---|---|---|
| A. Replication | Do valuations predict returns in-sample? | Regressions of 1-month, 1-year and 10-year log excess returns on the dividend–price ratio, CAPE, the term spread and the Fed-model spread; OLS, Newey–West and Hodrick (1992) t-statistics | Figure 7.1 |
| B. Walk-forward | Do they forecast? | Expanding-window forecasts from 1965, purged for overlapping targets; out-of-sample R² against the historical mean; Clark–West test; Campbell–Thompson restrictions | Figure 7.2 |
| C. Stress tests | Does the evidence survive small-sample corrections and other periods? | Bootstrap under the null that keeps the predictor's persistence and its correlation with returns (Stambaugh bias); three subperiods; rolling 20-year t-statistics | Figures 7.3–7.4 |
| D. Ranges | What can valuations say about the next decade? | Annualized 10-year real returns on log CAPE; walk-forward forecast errors; a 90% range for today's CAPE | Figure 7.5 |

### Design notes

- **Returns.** Monthly log excess returns: log(1 + CRSP S&P 500 total return) − log(1 + T-bill return), summed over the horizon. Part D uses real returns: log(1 + total return) − log(1 + inflation), or Shiller's real total return index when his file is supplied.
- **Predictors.** `dp` = log(12-month dividends / price); CAPE = real price / 10-year average of real 12-month earnings, entered as −log(CAPE) so that, as for `dp`, a high value means cheap stocks; `tms` = long-term yield − T-bill yield; Fed-model spread = earnings / price − 10-year Treasury yield. CAPE is built from the Goyal–Welch index, earnings and inflation (inflation data begins in 1913, so CAPE begins in 1923). Earnings are used as dated in the file; in real time they arrive with a lag of a few months, a refinement left as an exercise.
- **Standard errors.** Newey–West lags = horizon − 1; Hodrick (1992) 1B errors computed under the null. OLS t-statistics are shown only to show how much overlap inflates them.
- **Walk-forward.** First forecast January 1965; at least 20 years of training pairs (10 for the 10-year horizon); training pairs whose targets end after the forecast date are purged (gap = horizon − 1). Overlapping 10-year forecasts are strongly dependent: treat their test statistics with caution.
- **Bootstrap.** The predictor is fitted as an AR(1); return shocks and predictor shocks are resampled as pairs; returns are rebuilt with no predictability; 500 samples. One-sided p-values in the direction the original papers predicted (Nelson and Kim 1993 and Stambaugh 1999 motivate the design).
- **Ranges.** Point forecast ± 1.645 × the walk-forward root mean squared error of the 10-year forecast. With overlapping windows there is roughly one independent observation per decade, so the range itself is uncertain.

## Options

```text
--source {goyal,sim}       real data (default) or simulated data
--data-file PATH           Goyal-Welch spreadsheet or CSV export of its Monthly sheet
--shiller-file PATH        optional Shiller ie_data.xls (or CSV export of its Data sheet) for Part D
--start / --end YYYY-MM    sample (default 1927-01 to the end of the file)
--oos-start YYYY-MM        first forecast (default 1965-01)
--n-boot N                 bootstrap samples (default 500)
--seed N                   random seed (default 2026)
--sim-seed N               seed for simulated data
--out DIR                  output folder (default report/)
```

## Outputs (`report/`)

- `lab07_report.md`: all results, with a "Your verdict" prompt
- `fig7_1_in_sample.png` to `fig7_5_cape_ranges.png`
- `table_in_sample.csv`, `table_out_of_sample.csv`, `table_bootstrap.csv`, `table_subperiods.csv`, `table_cape_scatter.csv`
- `summary.json`

## Files

```text
ch07-predictability/
├── README.md
├── requirements.txt
├── lab07.py                 # the lab: parts A–D, figures, report
├── lab07_walkthrough.ipynb  # guided version
├── fintest/                 # the book's analysis module (Labs 1–7 subset)
│   ├── predictors.py        # Goyal–Welch data, now with CAPE, the Fed-model spread and real returns
│   ├── shiller.py           # Shiller's ie_data.xls reader
│   ├── forecast.py, inference.py, stats.py, data.py, costs.py, multiple.py, plots.py
├── data/
└── tests/test_lab07.py      # runs offline
```

Run the tests with `python tests/test_lab07.py` (or `pytest tests/`).

## Verification status

| Part | Status |
|---|---|
| CAPE and Fed-model spread | Tested against direct calculations on a file in the Goyal–Welch layout; CAPE waits for 10 years of inflation and earnings data |
| Shiller reader | Tested on a sheet in Shiller's layout (header row found by name; dates like 1871.1 read as October); **confirm on the live file at first run** |
| Long-horizon regressions and walk-forward | Reuse the Lab 3 and Lab 5 code, tested there (Hodrick errors against a loop; no look-ahead with purging) |
| Bootstrap | Tested: reproduces the upward Stambaugh bias in t-statistics; the actual t exceeds the bootstrap 95% point in about 5% of null samples |
| Part D | Tested with both data sources; the range brackets the point forecast |
| Full lab and notebook | Run end to end on simulated data |
| Real data | Not run from the build environment (network blocked) |

## Exercises

1. Re-run with `--start 1950-01` and with `--end 1990-12`. How do the in-sample results change? What does that suggest about the papers published around 1988?
2. Lag CAPE by four months to allow for the delay in reported earnings. How much does the in-sample and out-of-sample evidence change?
3. Replace the 10-year horizon with 5 years. Are the ranges in Part D narrower or wider, and why?
4. Add the Campbell–Thompson restrictions to Part D's 10-year forecast. Do they help?
5. Repeat the bootstrap with `rho` forced to zero (shuffle predictor shocks independently of return shocks). How much of the bias disappears?

## Data citations

Goyal, A., and Welch, I. (2008). A comprehensive look at the empirical performance of equity premium prediction. *Review of Financial Studies*, 21(4), 1455–1508; updated data from https://sites.google.com/view/agoyal145.
Shiller, R. J. Online data: U.S. stock markets 1871–present and CAPE ratio, http://www.econ.yale.edu/~shiller/data.htm.
